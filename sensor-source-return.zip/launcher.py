#!/usr/bin/env python3
"""Stage11 Scene/sensor source capture, 2026-10-08. Standard library only.

Run: python3 -I -S /home/lx/下载/microduck-stage11-sensor-source-capture.py

Reads 14 specified mjlab sources plus at most 10 directly imported sensor
helpers. Never imports those sources, creates a simulator, or accesses a GPU.
Writes only a new directory outside the project. Prepares an independent local
Git archive; the user performs the printed SSH push. No network access here.
No tracked source, existing Stage11 file, branch, tag, or Git index is modified.
The completed contact-macro probe must NOT be rerun.
"""
from __future__ import annotations

import ast
import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import shlex
import stat
import subprocess
import sys
import uuid
import zipfile

REPO = Path('/home/lx/microduck-double-balance/workspace')
ROOT = Path('/home/lx/microduck-double-balance/artifacts/double-balance-stage11')
ORIGIN = 'git@github.com:liuxue-lab/microduck-double-balance.git'
EXPECTED_HEAD = '056eaf2b0c78261f34e3fa581858c8573cab981e'
MISSING = (
    'sensor/sensor_context.py', 'sensor/raycast_sensor.py',
    'sensor/terrain_height_sensor.py', 'sensor/contact_sensor.py',
    'sensor/camera_sensor.py', 'entity/entity_data.py',
    'terrains/terrain_entity.py',
)
PINS = {
    'scene/scene.py': 'f9ffeed16bb741a259fedfbb3b9cd6f3609a0b0cf98da3556dd16db51ec6e30c',
    'sensor/sensor.py': 'c700983150dbd74fbceec7486b842af4dc8917a251af0277436aee09a69dd077',
    'sensor/builtin_sensor.py': '401e495124fa96a89c87cd510da8f43c693db3f9110b93000dcb515171e57adf',
    'entity/entity.py': '817896ec3ce69c8ef18cb3d8e2519b85d1db25f70126af5e643c34a0b054e572',
    'sim/sim.py': '2a8561e52d019b202cf105a6512abfdd8068701dafe321f43bbae96e346b2c68',
    'sim/sim_data.py': 'bc73da4811fc44336f9016d826ef1b2044b8cb0830f2ad01a06b9b84ffa8b4c6',
    'envs/manager_based_rl_env.py': 'a381027e336d6313cd338d541230b36864657edac89708a33e7e60c0c6fb74d2',
}
MAX_FILE = 512 * 1024
MAX_TOTAL = 8 * 1024 * 1024
MAX_HELPERS = 10
FORBIDDEN = {'mujoco', 'mujoco_warp', 'warp', 'torch', 'mjlab', 'bam', 'mjlab_microduck'}
AUDIT = {
    'status': 'SOURCE_REVIEW_ONLY_RUNTIME_UNVALIDATED',
    'input_return_commit': '416a11e4e3085a5978621ba8e2719f4b523fd263',
    'input_return_sha256': '88fea5c3e4f3d2215a15f85e4aa13adc38e0ed0e492dfa2d9fd0a0cbe3666c08',
    'checks_completed_offline': {
        'outer_inventory_files': 17, 'convenience_source_provenance_matches': 5,
        'unique_nested_zip_archives_searched': 22,
        'handoff_copies_identical': True, 'outer_and_contact_zip_crc': 'PASS',
        'contact_dynamics_rerun': False, 'raw_contact_trace_recomputed_this_turn': False,
    },
    'findings': [
        'Returned initialization-scope.json lists 14 sensor objects: 11 BuiltinSensor, 2 ContactSensor, 1 TerrainHeightSensor; compiled nsensor=11 and nsensordata=28.',
        'Sensor._cache_valid and Sensor._cached_data are Python-level state outside Warp Data. reset/update invalidate only the flag in the base class.',
        'BuiltinSensor._data_view aliases a slice of sim.data.sensordata; rollback must preserve owner, offset, shape and strides, not clone-and-rebind this view.',
        'Scene.initialize initializes entities, then sensors, then constructs SensorContext for context-requiring sensors. foot_height_scan requires it.',
        'Scene.update calls Entity.update then Sensor.update; Entity.update calls actuator.update. Scene.reset also resets entity targets and actuator state. Neither is a generic rollback operation.',
        'Simulation.sense separately calls context.prepare, sensing kernels, context.finalize. set_sensor_context calls create_graph; do not use unguarded in a no-graph diagnostic.',
        'WarpBridge._wrapped_cache and TorchArray views/streams are outside copied Warp Data. Cache clearing alone does not rebind an already-held BuiltinSensor view.',
        'Existing TorchStateSnapshot roots cover selected BAM/firmware/robot targets, not sensors/context. It rejects noncontiguous tensors; single-world success cannot establish multi-world view support.',
        'Existing contact probe excludes Scene initialize/reset/update, sensor sensing, managers, action history and normalizer. Its local PASS remains valid within that scope.',
    ],
    'next_physical_diagnostic': {
        'status': 'NOT_READY_PENDING_INSTALLED_SOURCE_REVIEW',
        'first_goal': 'Inventory mutable sensor/context/EntityData state and ownership; define rollback of cold and warm caches and exact update/sense/reset order.',
        'source_capture_integration_budget': 0, 'source_capture_forward_budget': 0,
        'source_capture_graph_budget': 0, 'source_capture_cloud_hours': 0,
        'future_dynamic_budget': None,
        'reason_budget_not_set': 'Do not invent runtime allocations or safe sensing setup before inspecting the missing implementations.',
    },
    'canonical_completed_from_handoff': 34543,
    'canonical_attempted_from_handoff': 34544,
    'PPO': 0, 'estimated_progress_percent': 85,
    'progress_is_engineering_estimate': True,
    'full_scene_sensor_lifecycle_validated': False,
    'full_dynamic_macro_rollback_validated': False,
    'formal_physics_adoption': False, 'formal_task_migration': False,
    'stage11_complete': False,
    'cloud_state_from_handoff': 'OFF_CONFIRMED_BY_USER',
}


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def put(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)


def put_json(path, value):
    put(path, (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode())


def read_bounded(path, root):
    resolved = path.resolve(strict=True)
    require(resolved.is_relative_to(root.resolve()), 'Source escaped package directory: ' + str(path))
    require(not path.is_symlink(), 'Source symlink needs manual review: ' + str(path))
    require(stat.S_ISREG(resolved.stat().st_mode), 'Not a regular source: ' + str(path))
    with resolved.open('rb') as stream:
        data = stream.read(MAX_FILE + 1)
    require(len(data) <= MAX_FILE, 'Source exceeded 512 KiB: ' + str(path))
    return data


def git(repo, *args, identity=False):
    # Do not inherit repository redirects or global hooks/filters into the export.
    env = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
    env.update(GIT_OPTIONAL_LOCKS='0', GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null')
    command = ['git', '-c', 'core.hooksPath=/dev/null', '-c', 'commit.gpgsign=false',
               '-c', 'core.fsmonitor=false', '-c', 'core.attributesFile=/dev/null']
    if identity:
        command += ['-c', 'user.name=Microduck evidence export', '-c', 'user.email=evidence@local.invalid']
    result = subprocess.run(command + ['-C', str(repo), *args], env=env,
                            capture_output=True, timeout=20, check=False)
    require(result.returncode == 0, 'Git operation failed: ' + result.stderr.decode(errors='replace')[-1800:])
    return result.stdout.decode().strip()


def git_state(repo):
    return {
        'head': git(repo, 'rev-parse', 'HEAD'),
        'branch': git(repo, 'branch', '--show-current'),
        'origin': git(repo, 'config', '--get', 'remote.origin.url'),
        'status': git(repo, 'status', '--porcelain=v1', '--untracked-files=normal'),
        'tracked_diff_sha256': sha(git(repo, 'diff', '--no-ext-diff', '--no-textconv', '--binary', 'HEAD').encode()),
    }


def installed_package(repo):
    sites = sorted((repo / '.venv/lib').glob('python*/site-packages'))
    require(bool(sites), 'No project .venv/lib/python*/site-packages found; no environment changes made')
    found = [d for d in importlib.metadata.distributions(path=[str(p) for p in sites])
             if (d.metadata.get('Name') or '').lower().replace('_', '-') == 'mjlab']
    require(len(found) == 1, 'Expected exactly one mjlab distribution; found ' + str(len(found)))
    dist = found[0]
    root = Path(dist.locate_file('mjlab')).resolve()
    require(root.is_dir() and any(root.is_relative_to(p.resolve()) for p in sites),
            'Editable or external mjlab source requires explicit path review; preserved')
    direct = dist.read_text('direct_url.json')
    origin = json.loads(direct) if direct else {}
    require(not origin.get('dir_info', {}).get('editable', False),
            'Editable install requires source resolution review; no source guessed')
    return root, {'version': dist.version, 'expected_version': '1.3.0',
                  'vcs_commit': origin.get('vcs_info', {}).get('commit_id'),
                  'source_root': str(root)}


def imports_of(data, relative):
    """Resolve literal imports without executing code or evaluating expressions."""
    tree = ast.parse(data, filename=relative)
    module = ['mjlab', *Path(relative).with_suffix('').parts]
    package = module[:-1] if module[-1] != '__init__' else module[:-1]
    result = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            result.update(a.name for a in node.names)
        elif isinstance(node, ast.ImportFrom):
            if node.level:
                if node.level > len(package):
                    continue
                base = package[:len(package) - node.level + 1]
                if node.module:
                    base += node.module.split('.')
            else:
                base = node.module.split('.') if node.module else []
            if base:
                result.add('.'.join(base))
                result.update('.'.join([*base, a.name]) for a in node.names if a.name != '*')
    return sorted(result)


def capture(root, run):
    queue = list(MISSING) + list(PINS)
    requested = set(queue)
    records = {}
    errors = []
    deferred = set()
    total = 0
    helpers = 0
    for relative in queue:
        try:
            path = root / relative
            data = read_bounded(path, root)
            total += len(data)
            require(total <= MAX_TOTAL, 'Capture exceeded 8 MiB total')
            imports = imports_of(data, relative)
            put(run / 'source/mjlab' / relative, data)
            expected = PINS.get(relative)
            records[relative] = {
                'bytes': len(data), 'sha256': sha(data), 'expected_sha256': expected,
                'pin_matches': None if expected is None else sha(data) == expected,
                'literal_imports': imports,
            }
            # Only follow concrete .py modules under sensor/. Do not follow broad
            # __init__ exports, arbitrary directories, or third-party packages.
            for name in imports:
                if not name.startswith('mjlab.sensor.'):
                    continue
                child = name[len('mjlab.'):].replace('.', '/') + '.py'
                if child in requested or not (root / child).is_file():
                    continue
                if helpers >= MAX_HELPERS:
                    deferred.add(child)
                    continue
                requested.add(child)
                queue.append(child)
                helpers += 1
            if read_bounded(path, root) != data:
                errors.append('Source changed during capture: ' + relative)
        except (OSError, RuntimeError, SyntaxError, ValueError) as exc:
            errors.append(relative + ': ' + str(exc))
    for relative, record in records.items():
        try:
            require(sha(read_bounded(root / relative, root)) == record['sha256'],
                    'Source changed after capture: ' + relative)
        except (OSError, RuntimeError) as exc:
            errors.append(str(exc))
    return {'sources': records, 'errors': errors, 'deferred_sensor_helpers': sorted(deferred),
            'core_source_count': 14, 'captured_source_count': len(records),
            'helper_count': helpers, 'total_source_bytes': total,
            'dependency_scope': 'Literal sensor .py imports only; external imports listed, not claimed reviewed'}


def package_return(run, stamp):
    payload = sorted(p for p in run.rglob('*') if p.is_file())
    inventory = {str(p.relative_to(run)): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
                 for p in payload}
    put_json(run / 'evidence-inventory.json', inventory)
    archive = run / 'sensor-source-return.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
        for path in [*payload, run / 'evidence-inventory.json']:
            z.write(path, str(path.relative_to(run)))
    with zipfile.ZipFile(archive) as z:
        require(z.testzip() is None, 'Return ZIP CRC failure; keep directory')
    require(archive.stat().st_size < 49 * 1024 * 1024, 'Archive exceeded 49 MiB; keep directory')
    digest = sha(archive.read_bytes())
    print('Stage11ReturnZIP=' + str(archive), flush=True)
    print('Stage11ReturnSHA256=' + digest, flush=True)
    # Separate archive repository; do not touch project refs/index/worktree.
    transfer = run / 'transfer'
    transfer.mkdir()
    branch = 'stage11-sensor-source-transfer-' + stamp.lower()
    git(transfer, 'init', '--template=', '-b', branch)
    git(transfer, 'remote', 'add', 'origin', ORIGIN)
    put(transfer / archive.name, archive.read_bytes())
    put_json(transfer / 'return-manifest.json', {'file': archive.name, 'bytes': archive.stat().st_size,
             'sha256': digest, 'branch': branch, 'scope': 'source capture only; zero physics; never merge'})
    git(transfer, 'add', '--', archive.name, 'return-manifest.json')
    git(transfer, 'commit', '-m', 'Archive Stage11 Scene and sensor installed sources', identity=True)
    print('Stage11TransferCommit=' + git(transfer, 'rev-parse', 'HEAD'), flush=True)
    print('Stage11PushCommand=git -C ' + shlex.quote(str(transfer)) + ' push origin HEAD', flush=True)
    print('Push only the independent archive branch above; do not merge it.', flush=True)


def main():
    require(sys.flags.isolated and sys.flags.no_site, 'Use python3 -I -S; site hooks must be disabled')
    require(len(sys.argv) == 1, 'No arguments accepted; keep the printed run directory on failure')
    require(not any(n.split('.')[0] in FORBIDDEN for n in sys.modules), 'Unexpected simulator import')
    require(REPO.is_dir(), 'Local project not found: ' + str(REPO))
    require(ROOT.is_dir(), 'Existing Stage11 artifact directory not found: ' + str(ROOT))
    require(not ROOT.resolve().is_relative_to(REPO.resolve()), 'Output must be outside the project')
    before = git_state(REPO)
    require(before['origin'] == ORIGIN, 'Unexpected project origin; no files changed')
    require(before['branch'] == 'double-balance', 'Expected double-balance; no branch switched')
    root, version = installed_package(REPO)
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:6]
    run = ROOT / 'sensor-sources' / stamp
    run.mkdir(parents=True, exist_ok=False)
    print('Stage11Run=' + str(run), flush=True)
    print('Stage11Budget=14 core sources + <=10 sensor helpers; integrations=0; forwards=0; GPU=0; PPO=0', flush=True)
    put(run / 'launcher.py', Path(__file__).read_bytes())
    put_json(run / 'offline-audit.json', AUDIT)
    put_json(run / 'git-before.json', before)
    put_json(run / 'capture-start.json', {'utc': stamp, 'no_site': True, 'isolated': True,
             'max_source_bytes': MAX_TOTAL, 'max_source_files': 24})
    review = capture(root, run)
    after = git_state(REPO)
    put_json(run / 'git-after.json', after)
    review.update(installation=version, git_state_unchanged=before == after,
                  expected_head_matches=before['head'] == EXPECTED_HEAD,
                  simulator_imports=[n for n in sys.modules if n.split('.')[0] in FORBIDDEN],
                  source_complete=all(n in review['sources'] for n in [*MISSING, *PINS]),
                  new_integrations=0, new_forwards=0, new_graph_captures=0, PPO=0, cloud_hours=0,
                  stage11_complete=False, full_scene_sensor_lifecycle_validated=False)
    pins_ok = all(v['pin_matches'] is not False for v in review['sources'].values())
    ok = (not review['errors'] and review['source_complete'] and pins_ok and before == after
          and review['expected_head_matches'] and version['version'] == '1.3.0'
          and not review['simulator_imports'])
    review['status'] = 'SENSOR_SOURCES_CAPTURED_REVIEW_REQUIRED' if ok else 'SOURCE_DIFFERENCE_REVIEW_REQUIRED'
    put_json(run / 'source-review.json', review)
    put_json(run / 'capture-finished.json', {'capture_completed': True, 'status': review['status'],
             'source_copy_count': len(review['sources']), 'physics_calls': 0})
    package_return(run, stamp)
    print('Stage11Result=' + review['status'], flush=True)
    print('Stage11CanonicalCompleted=34543; Stage11CanonicalAttempted=34544; PPO=0', flush=True)
    return 0 if ok else 2


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, RuntimeError, ValueError, subprocess.SubprocessError) as exc:
        print('Stage11Stopped=' + str(exc), file=sys.stderr)
        print('Keep the printed directory and send this output. No automatic rerun or cleanup.', file=sys.stderr)
        raise SystemExit(2)
