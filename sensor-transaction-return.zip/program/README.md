# Stage11 有界传感器状态恢复诊断

## 已复核的前置证据

传感器 lifecycle R2：`8428b106e8acb4f7b4b5fd70a4350f6e5c29e5b7`，原始 ZIP SHA256 `ddc7e2303d215680dc4cbca11bdde9eb0adcf1d133ef5f6934779e3261934696`。外层 SHA256、CRC 和 54 项内容清单通过；26 项传感器输出两次刷新后精确一致，14 个缓存在 reset 后均失效。完整原始包已嵌入 previous。R2 不重跑。

R2 的受控提前读取证明：sense 更新射线字段但不会自动失效已经读出的 Sensor 缓存。RayCastSensor 重新绑定多个 Torch 输出，同时还有指向 Warp 缓冲区的视图。只恢复 qpos 或复制新张量，不能恢复这些原对象与别名。

实际 Manager 顺序为：每物理子步 scene.update，然后 termination/reward，再 forward、command/events、sense、observation。篮球任务配置移除了 air_time、foot_clearance、foot_swing_height、foot_slip 等奖励。不能将故意提前读取的受控现象等同于正式任务已经出现奖励错误；此次不实例化 Manager，不改变奖励、观测或任务验收。

## 本次只回答的恢复问题

私有单 world、现有 14 个 sensor、6 条足部射线，无活动相机。使用已复核名义初态 A，感知后保存完整 Warp Data 和所选传感器对象。直接将机器人与上球各抬高 10mm，并把私有 Data.time 从 0 设置为 2ms，构造 B。调用 forward 和一次 scene.update，故意提前读高度缓存，随后 sense 并只使缓存失效（不重复调用 update，不重复累计计时或历史）。

检查高度增加约 10mm，接触传感器在无接触条件下记录 2ms 空中时间。恢复 A 的完整 Data 和原缓存/张量视图；重新 sense 来更新 native BVH 并重新查询射线，检查所有 26 项输出回到 A。重新绑定的缓存再次恢复到原对象，确认旧引用仍可用。从完全恢复的 A 再构造一次相同 B，要求两个 B 的输出精确一致。最后再次验证恢复到 A。

这两次是**人工姿态/时钟赋值测试，积分为 0**。不能计为真实物理轨迹、真实飞行时长验收或已完成动态宏步事务。不会把 Scene.reset 当作回滚。原生 BVH 不做不可见内存快照；在当前无 flex、无活动相机的固定拓扑场景中，通过重新 refit 后的数值边界与射线输出检查恢复结果。原生句柄完整快照标记仍为 false。

## 硬预算与停止条件

| 操作 | 本次上限 |
|---|---:|
| 编译 / Scene.initialize / SensorContext | 各 1 |
| CPU forward | 2 |
| CPU 运动学 | 3：初始化 1＋名义姿态 2 |
| CPU 距离查询 | 1 |
| GPU forward | 3：A 1＋两个 B 各 1 |
| sense / BVH refit / 射线批次 | 各 5，共 30 条射线 |
| Scene.update | 3：初始 dt=0，两个 B 各 dt=2ms |
| Scene.reset | 1，仅初始化 |
| 完整 Data 恢复 / 所选 sensor owner 恢复 | 2 / 4 |
| 积分 / PPO / BAM.compute / delay.apply / 图捕获 / 图像渲染 | 全部 0 |
| 单类快照容量 | 64MiB |
| 外层时限 | 600 秒 |

所有者图拒绝内部重叠/广播写入视图、未知状态类型和布局变化；支持外部共享存储、非连续但内部不重叠的 Torch 视图。恢复前先验证全部已保存布局，再复制。记录内容 SHA256、存储地址、偏移、步幅及原对象归属。BAM 状态、实体目标、所选材料字段和 CPU/CUDA RNG 应始终不变。

任何断言失败即停止；保留实际计数、已完成阶段与回传包。不自动追加测试、不重试 GPU 清理。失败时退出私有进程释放对象，不宣称失败路径已经原地恢复。52 项固定源码执行前/后核验；额外保留实际 native refit 包装器与 `inspect.unwrap` 后实现源码，避免将装饰器文件误当作 BVH 实现。

## 本机操作

下载 `microduck-stage11-sensor-transaction.py`，运行：

```bash
python3 -I -S "/home/lx/下载/microduck-stage11-sensor-transaction.py"
```

脚本先校验已完成的 R2 原始回传，然后在 artifacts/double-balance-stage11/sensor-transaction 下新建一次性运行目录。正式仓库、旧启动记录和归档保持不动。结束后自动打印完整、可直接复制的 SSH push 命令。用户使用既有 SSH 身份执行；独立归档分支永不合并，不建立 PR、不 force push、不移动旧标签。

只有进程已退出且 execution-finished.json 已保存时，才使用该次打印的 package-only 命令恢复打包；不删除启动记录。云机承接 OFF_CONFIRMED_BY_USER，本次不用云 GPU。

累计积分完成 34543、尝试 34544，PPO=0。Stage11 约 85%、整体项目约 55% 均为粗略工程估计，不是通过率。上球撞地、长期数值/时钟、真实动态 Scene/Manager 事务、多 world/图捕获/吞吐、策略兼容、云训练和最终验收仍未关闭。

## 验证边界

助手环境执行标准库/NumPy 的共享存储、非连续视图、原对象恢复、前置检查、次数闸门及真实 Git/子进程回传夹具测试。助手环境未运行实际 Torch/MuJoCo/Warp/CUDA；本机返回后仍需独立复核。成功标记仅限 bounded synthetic sensor transaction，完整动态回滚和 Stage11 完成标记保持 false。
