"""One-world synthetic sensor state transaction; zero integration.
CPU forward=2, kinematics=3 (1 initialization + 2 nominal), distance=1.
GPU forward<=3; sense/refit/ray batches<=5, six rays each. Scene.update<=3,
Scene.reset<=1. Two identical synthetic 10mm pose / 2ms time changes.
Private diagnostic only; no policy, Manager, integration, image rendering or graph capture.
"""
from pathlib import Path
import argparse
import copy
import dataclasses
import hashlib
import importlib.metadata
import inspect
import json
import sys
import time
import traceback

sys.path.insert(0, str(Path(__file__).resolve().parent))
from lifecycle_support import Gate, inventory, delta, require


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def filehash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def guard_cpu_kinematics(gate, mujoco):
    """One put_data initialization call, then two nominal-placement calls."""
    phase = {'name': 'initialization'}
    total = gate.limited('CPU_kinematics_native', 3, mujoco.mj_kinematics)
    by_phase = {
        'initialization': gate.limited('CPU_kinematics_initialization', 1, total),
        'nominal': gate.limited('CPU_kinematics_nominal_native', 2, total),
    }
    def call(*args, **kwargs):
        require(phase['name'] in by_phase, 'CPU kinematics outside permitted phase')
        return by_phase[phase['name']](*args, **kwargs)
    gate.patch(mujoco, 'mj_kinematics', call)
    return phase


def verify_sources(repo, plan):
    paths = {repo / n: h for n, h in plan['project_source_hashes'].items()}
    for distribution, entries in plan['installed_source_hashes'].items():
        dist = importlib.metadata.distribution(distribution)
        paths.update({Path(dist.locate_file(n)): h for n, h in entries.items()})
    for path, expected in paths.items():
        require(path.is_file() and filehash(path) == expected, 'Source differs; stopped before Scene: ' + str(path))
    for name, expected in plan['versions'].items():
        require(importlib.metadata.version(name) == expected, 'Version changed: ' + name)
    return paths


def run(repo, out, plan):
    started = time.monotonic()
    counts = {n: 0 for n in ('integrations_attempted', 'integrations_completed', 'PPO',
                             'CPU_kinematics_attempted', 'CPU_kinematics_completed',
                             'CPU_geom_distance_attempted', 'CPU_geom_distance_completed',
                             'sensor_data_reads', 'sensor_reference_computes')}
    gate = None
    report = {'status': 'SENSOR_TRANSACTION_STARTED', 'counts': counts,
              'canonical_completed': 34543, 'canonical_attempted': 34544, 'PPO': 0,
              'formal_physics_adoption': False, 'formal_task_migration': False,
              'full_scene_sensor_lifecycle_validated': False,
              'full_dynamic_macro_rollback_validated': False, 'stage11_complete': False,
              'snapshot_restore_exercised': False,
              'scope': 'Synthetic pose/time A-B-restore-B replay in one private world; no integrated dynamics'}
    def persist():
        save(out / 'progress.json', {'elapsed_s': time.monotonic()-started, **counts})
    try:
        pins = verify_sources(repo, plan)
        save(out / 'source-hashes.json', {str(p): h for p, h in pins.items()})
        import numpy as np
        import mujoco
        import torch
        import warp as wp
        import mujoco_warp as mw
        from mujoco_warp._src import forward as fw
        from mjlab.scene import Scene
        from mjlab.sim import Simulation
        from mjlab.sensor import raycast_sensor as raymod
        from mjlab.sensor import sensor_context as ctxmod
        from mjlab_microduck.robot.head_contact import physics_scene_pair
        from mjlab_microduck.robot import head_reference
        from mjlab_microduck.actuator.friction_dr_bam import FrictionDRBamActuator
        from head_contact_nominal_macro_state import nominal_state, geometry_row, validate_geometry
        require(mujoco.get_mjcb_control() is None, 'Unexpected native CPU control callback')
        require(torch.__version__.split('+')[0] == '2.9.1', 'Torch version changed')
        require(torch.cuda.is_available(), 'Local CUDA required; no CPU fallback')
        device = wp.get_device('cuda:0')
        require(device.is_cuda and '5060' in device.name, 'This diagnostic is scoped to the local RTX5060')
        wp.set_device(device)
        torch.manual_seed(1106001)
        torch.cuda.manual_seed_all(1106001)
        def sync():
            wp.synchronize()
            torch.cuda.synchronize()
        gate = Gate(counts, persist, started + 600, sync)
        # Patch both public and underlying integrator entry points before constructing a Scene.
        for module, names in (
            (mujoco, ('mj_step', 'mj_step1', 'mj_step2', 'mj_Euler', 'mj_RungeKutta', 'mj_implicit')),
            (mw, ('step', 'step1', 'step2', 'euler', 'implicit', 'rungekutta4')),
            (fw, ('step', 'step1', 'step2', 'euler', 'implicit', 'rungekutta4')),
            (wp, ('ScopedCapture', 'capture_begin', 'capture_end', 'capture_launch')),
            (mw, ('render',)),
        ):
            for name in names:
                if hasattr(module, name):
                    gate.patch(module, name, gate.blocked(name))
        gate.patch(mujoco, 'mj_forward', gate.limited('CPU_forward', 2, mujoco.mj_forward))
        kinematics_phase = guard_cpu_kinematics(gate, mujoco)
        gate.patch(mujoco, 'mj_geomDistance', gate.limited('CPU_geom_distance_native', 1, mujoco.mj_geomDistance))
        forward = gate.limited('GPU_forward', 3, fw.forward)
        gate.patch(mw, 'forward', forward)
        gate.patch(fw, 'forward', forward)
        def context_check(args, kwargs):
            require(kwargs.get('nworld') == 1 and kwargs.get('cam_active') == [False],
                    'Only one-world raycast context with all cameras inactive is permitted')
        context = gate.limited('context_create', 1, mw.create_render_context, context_check)
        gate.patch(mw, 'create_render_context', context)
        native_refit = mw.refit_bvh
        gate.patch(mw, 'refit_bvh', gate.limited('BVH_refit', 5, native_refit))
        native_rays = raymod.rays
        def ray_check(args, kwargs):
            require(tuple(kwargs['pnt'].shape) == (1, 6), 'Expected two frames with three rays each')
        gate.patch(raymod, 'rays', gate.limited('ray_batch', 5, native_rays, ray_check))
        # Preserve native ray/BVH sources, now pinned from the r1 return.
        captured_native = {}
        for name, fn in [('rays', native_rays), ('refit_wrapper', native_refit), ('refit_body', inspect.unwrap(native_refit))]:
            filename = inspect.getsourcefile(fn)
            if filename:
                path = Path(filename)
                require(path.stat().st_size <= 2*1024*1024, 'Native source unexpectedly large')
                raw = path.read_bytes()
                target = out / 'native-source' / path.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(raw)
                captured_native[name] = {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(),
                                         'scope': 'Actual wrapper/body captured separately; source pins apply only to plan-listed paths'}
        save(out / 'new-native-sources.json', captured_native)

        class ZeroStepSimulation(Simulation):
            def _should_use_cuda_graph(self):
                return False
            def create_graph(self):
                counts['graph_setup_suppressed'] = counts.get('graph_setup_suppressed', 0) + 1
                self.step_graph = self.forward_graph = self.reset_graph = self.sense_graph = None
            def step(self):
                return gate.blocked('Simulation.step')()
            def reset(self, *args, **kwargs):
                return gate.blocked('Simulation.reset')()

        cfg, _, candidate = physics_scene_pair()
        require(cfg.sim.mujoco.timestep == .002 and cfg.decimation == 10, 'Formal timestep changed')
        candidate = copy.deepcopy(candidate)
        candidate.num_envs = 1
        scene = Scene(candidate, 'cuda:0')
        model = scene.compile()
        counts['model_compile_completed'] = 1
        dims = {n: int(getattr(model, n)) for n in ('nbody', 'ngeom', 'nq', 'nv', 'nu', 'nsensor', 'nsensordata', 'ncam')}
        require(dims == dict(nbody=19, ngeom=85, nq=35, nv=32, nu=14, nsensor=11, nsensordata=28, ncam=1),
                'Compiled scene dimensions changed')
        simcfg = copy.deepcopy(cfg.sim)
        simcfg.nconmax = max(simcfg.nconmax or 0, 256)
        simcfg.njmax = max(simcfg.njmax or 0, 1024)
        sim = ZeroStepSimulation(1, simcfg, model, 'cuda:0')
        require(counts.get('CPU_kinematics_initialization_completed') == 1,
                'Expected one CPU kinematics call from Simulation -> put_data')
        kinematics_phase['name'] = 'closed'
        require(all(getattr(sim.wp_model.callback, n) is None for n in
                    ('passive', 'control', 'act_dyn', 'act_gain', 'act_bias', 'sensor', 'contactfilter')),
                'Unexpected native GPU callback')
        sim.expand_model_fields(('dof_frictionloss', 'dof_damping'))
        gate.limited('Scene_initialize', 1, scene.initialize)(model, sim.model, sim.data)
        require(len(scene.sensors) == 14 and scene.sensor_context is not None, 'Sensor roster changed')
        ctx = scene.sensor_context
        require(not ctx.has_cameras and len(ctx.raycast_sensors) == 1, 'Only existing foot height scan is in scope')
        ray = scene['foot_height_scan']
        require(ray.num_frames == 2 and ray.num_rays_per_frame == 3 and ray.num_rays == 6, 'Ray pattern changed')
        require(int(ctx.render_context.nrender) == 0, 'Unexpected active camera rendering')
        sim.set_sensor_context(ctx)
        act = scene['robot'].actuators[0]
        require(len(scene['robot'].actuators) == 1 and type(act) is FrictionDRBamActuator, 'BAM type changed')
        gate.patch(act, 'compute', gate.blocked('BAM.compute'))
        gate.patch(act, 'apply_delay', gate.blocked('delay.apply'))
        scene_reset = gate.limited('Scene_reset', 1, scene.reset)
        def zero_dt(args, kwargs):
            require((args[0] if args else kwargs.get('dt')) in (0.0, .002), 'Only specified synthetic time updates permitted')
        scene_update = gate.limited('Scene_update', 3, scene.update, zero_dt)
        sense = gate.limited('sense', 5, sim.sense)
        scene_reset()
        robot = scene['robot']
        origins = scene.env_origins.detach().cpu().numpy()
        require(origins.shape == (1, 3) and not origins.any(), 'Expected one zero-origin world')
        kinematics_phase['name'] = 'nominal'
        nominal, ids, geometry = nominal_state(
            model, mujoco, robot.indexing.joint_q_adr.detach().cpu().numpy(),
            robot.data.default_joint_pos.detach().cpu().numpy(), head_reference, counts,
            persist, lambda row: save(out / 'nominal-CPU-initialization.json', row))
        kinematics_phase['name'] = 'closed'
        require(counts.get('CPU_kinematics_nominal_native_completed') == 2 and
                counts.get('CPU_kinematics_native_completed') == 3,
                'CPU kinematics phase totals differ')
        sim.data.qpos[:] = torch.as_tensor(nominal, device='cuda:0', dtype=torch.float32)[None]
        for name in ('qvel', 'ctrl', 'qacc', 'qacc_warmstart', 'time'):
            getattr(sim.data, name).zero_()
        require(not sim.data.qfrc_applied.any() and not sim.data.xfrc_applied.any(), 'External force present')
        sync()
        sim.forward()
        row = geometry_row(sim.wp_data.geom_xpos.numpy()[0], sim.wp_data.geom_xmat.numpy()[0], ids, model)
        validate_geometry(row, nominal=True, expected_top=geometry['expected_top_position'])
        save(out / 'nominal-GPU-initialization.json', row)
        from sensor_transaction_phase import exercise
        report.update(exercise(scene, sim, act, ids, model, out, counts, gate,
                               sense, scene_update, sync, np, torch, wp))
        require(all(filehash(p) == h for p, h in pins.items()), 'Source changed during probe')
        require(all(filehash(Path(row['path'])) == row['sha256'] for row in captured_native.values()),
                'Observed native source changed during probe')
        report['status'] = 'BOUNDED_SENSOR_TRANSACTION_PASS_REVIEW_REQUIRED'
    except BaseException as exc:
        report.update(status='SENSOR_TRANSACTION_STOPPED_REVIEW_REQUIRED', error=str(exc), traceback=traceback.format_exc())
    finally:
        report['snapshot_restore_exercised'] = counts.get('Data_restore_attempted', 0) > 0
        report['integrated_dynamics_exercised'] = False
        report['native_handle_snapshot_closed'] = False
        report.setdefault('cleanup', 'Private worker exits; partial failure is preserved, no further GPU cleanup retry')
        if gate is not None:
            gate.close()
        report['elapsed_s'] = time.monotonic()-started
        save(out / 'run-review.json', report)
        persist()
    print(json.dumps({'status': report['status'], 'counts': counts}, indent=2), flush=True)
    return 0 if report['status'] == 'BOUNDED_SENSOR_TRANSACTION_PASS_REVIEW_REQUIRED' else 2


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--repo', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--plan', type=Path, required=True)
    args = p.parse_args()
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(args.repo / 'src'))
    return run(args.repo, args.out, json.loads(args.plan.read_text()))


if __name__ == '__main__':
    raise SystemExit(main())
