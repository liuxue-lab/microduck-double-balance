"""Two controlled synthetic pose/time trials with selected sensor recovery."""
from pathlib import Path
import dataclasses
import hashlib
import json
from types import SimpleNamespace

from lifecycle_support import require, inventory
from sensor_state_snapshot import DataSnapshot, OwnerSnapshot, digest, sense_and_invalidate


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n')


def exercise(scene, sim, act, ids, model, out, counts, gate, sense, update, sync, np, torch, wp):
    require(int(model.nflex) == 0, 'Deformable mesh/BVH updates are outside scope')
    require(all(getattr(s.cfg, 'history_length', 0) == 0 for s in scene.sensors.values()),
            'This diagnostic is scoped to the current history_length=0 sensors')
    sensors = scene.sensors
    ray = scene['foot_height_scan']
    ctx = scene.sensor_context
    rc = ctx.render_context
    data_snapshot = sensor_snapshot = None
    report = {'snapshot_restore_exercised': True, 'native_handle_snapshot_closed': False,
              'integrated_dynamics_exercised': False, 'full_scene_sensor_lifecycle_validated': False,
              'full_dynamic_macro_rollback_validated': False,
              'recovery_scope': 'Full Data arrays + selected sensor Python/Torch/Warp owners; native BVH recomputed by sense',
              'synthetic_change': {'robot_and_top_ball_delta_z_m': .01, 'time_from_s': 0., 'time_to_s': .002}}
    stages = []
    def persist(label, **fields):
        stages.append({'label': label, **fields})
        save(out/'transaction-progress.json', {'stages': stages, 'counts': counts})

    def arrays(value, prefix):
        if isinstance(value, torch.Tensor):
            raw = value.detach().cpu().numpy().copy()
            require(np.isfinite(raw).all(), 'Nonfinite sensor output: '+prefix)
            return {prefix: raw}
        require(dataclasses.is_dataclass(value), 'Unexpected sensor result type')
        result = {}
        for field in dataclasses.fields(value):
            child = getattr(value, field.name)
            if child is not None:
                result.update(arrays(child, prefix+'.'+field.name))
        return result

    def outputs(label):
        result = {}
        for name, sensor in sensors.items():
            first, second = sensor.data, sensor.data
            counts['sensor_data_reads'] += 2
            require(first is second and sensor._cache_valid, 'Per-step cache mismatch: '+name)
            result.update(arrays(first, name))
        require(len(result) == 26, 'Pinned sensor output field count changed')
        (out/'outputs').mkdir(exist_ok=True)
        np.savez_compressed(out/'outputs'/f'{label}.npz', **result)
        return result

    def equal(a, b, label):
        require(set(a) == set(b), label+' output keys differ')
        different = [n for n in a if not np.array_equal(a[n], b[n])]
        save(out/(label+'-comparison.json'), {'different_fields': different, 'field_count': len(a)})
        require(not different, label+' differs: '+', '.join(different))

    def fresh_sense():
        # This adapter is confined to the private diagnostic, not installed mjlab.
        sense_and_invalidate(SimpleNamespace(sense=sense), sensors)
        counts['post_sense_cache_invalidations'] = counts.get('post_sense_cache_invalidations', 0) + len(sensors)
        require(not any(s._cache_valid for s in sensors.values()), 'Post-sense invalidation failed')
        sync()

    def context_fingerprint():
        numeric, handles = {}, {'ctx': id(ctx), 'render_context': id(rc), 'bvh': id(rc.bvh)}
        for name, value in vars(rc).items():
            if isinstance(value, wp.array):
                handles[name] = [id(value), value.ptr, int(value.capacity)]
                if 'Texture' not in str(value.dtype):
                    numeric[name] = digest(value.numpy())
            elif isinstance(value, (dict, list)):
                items = value.items() if isinstance(value, dict) else enumerate(value)
                handles[name] = {str(k): id(v) for k, v in items}
        return {'numeric_sha256': numeric, 'owners': handles,
                'native_handle_contents_observed': False}

    def check_guards():
        sync()
        external.assert_restored()
        require(torch.equal(torch.get_rng_state(), rng_cpu) and
                torch.equal(torch.cuda.get_rng_state('cuda:0'), rng_cuda), 'Sensing consumed RNG')
        require((float(model.opt.timestep), int(model.opt.integrator),
                 float(model.geom_solref[ids['geoms']['top'], 0])) == options, 'Formal options changed')
        require(all(np.array_equal(a, getattr(sim.wp_model, n).numpy()) for n, a in material.items()),
                'Selected Model material fields changed')

    update(0.0)
    fresh_sense()
    baseline = outputs('A-baseline')
    air = scene['feet_ground_contact']._air_time_state
    require(air is not None and not air.last_time.any(), 'Expected zero baseline contact clock')
    require(not baseline['feet_ground_contact.found'].any(), 'Expected nominal no-foot-contact state')
    data_snapshot = DataSnapshot(sim.wp_data, wp)
    sensor_snapshot = OwnerSnapshot([(name, s, tuple(vars(s))) for name, s in sensors.items()], torch, wp)
    external_roots = []
    for name, entity in scene.entities.items():
        external_roots.append(('entity:'+name, entity.data,
                               tuple(k for k, v in vars(entity.data).items() if isinstance(v, torch.Tensor))))
    fields = ('_prev_motor_torque', '_dt', '_base_kp', '_friction_fields_checked',
              '_delay_buffer', 'vin_tensor', 'vin_drop_gain', 'kp_scale', 'kd_scale',
              'default_kp_scale', 'default_kd_scale', 'friction_scale', 'default_friction_scale',
              'diagnostics_enabled', 'last_diagnostics')
    external_roots.append(('BAM', act, fields))
    external_roots.append(('BAM_firmware', act._bam_model.actuator, ('kp', 'vin')))
    external = OwnerSnapshot(external_roots, torch, wp)
    rng_cpu, rng_cuda = torch.get_rng_state().clone(), torch.cuda.get_rng_state('cuda:0').clone()
    options = (float(model.opt.timestep), int(model.opt.integrator), float(model.geom_solref[ids['geoms']['top'], 0]))
    require(options == (.002, 3, .003), 'Unexpected formal options')
    material = {n: getattr(sim.wp_model, n).numpy().copy() for n in ('dof_damping', 'dof_frictionloss')}
    context_a = context_fingerprint()
    primary_a = {n: getattr(sim.wp_data, n).numpy().copy() for n in ('qpos', 'qvel', 'time', 'ctrl')}
    np.savez_compressed(out/'primary-A.npz', **primary_a)
    save(out/'context-A.json', context_a)
    save(out/'sensor-snapshot.json', sensor_snapshot.manifest())
    save(out/'external-guard-snapshot.json', external.manifest())
    save(out/'full-data-snapshot.json', {'arrays': len(data_snapshot.arrays), 'capacity_bytes': data_snapshot.bytes,
                                        'hashes': data_snapshot.hashes, 'owners': data_snapshot.owners})
    save(out/'inventory-A.json', inventory({'sensors': sensors, 'context': ctx}, torch, wp, np))
    persist('A-captured', data_arrays=len(data_snapshot.arrays), sensor_nodes=len(sensor_snapshot.nodes))
    data_restore = gate.limited('Data_restore', 2, data_snapshot.restore)
    sensor_restore = gate.limited('Sensor_owner_restore', 4, sensor_snapshot.restore)
    results = []
    for trial in (1, 2):
        # Direct private fixture assignment, not an integrator or an accepted physical macro.
        require(float(sim.data.time[0].item()) == 0., 'Trial did not start from baseline time')
        for root in ('robot', 'top_ball'):
            adr = ids['qadr'][root]
            sim.data.qpos[0, adr+2] += .01
        sim.data.time.fill_(.002)
        sync()
        sim.forward()
        update(.002)
        # Deliberate early read models a consumer before the sense boundary.
        early = ray.data
        counts['sensor_data_reads'] += 1
        early_height = early.heights.detach().cpu().numpy().copy()
        fresh_sense()
        current = outputs('B-trial-'+str(trial))
        require(ray.data is not early, 'Post-sense read retained earlier cache object')
        counts['sensor_data_reads'] += 1
        require(np.array_equal(early_height, baseline['foot_height_scan.heights']), 'Early-read witness changed unexpectedly')
        height_delta = current['foot_height_scan.heights'] - baseline['foot_height_scan.heights']
        require(np.allclose(height_delta, .01, rtol=0., atol=3e-6), '10mm pose change not observed by height sensor')
        require(not current['feet_ground_contact.found'].any(), 'Synthetic raised feet unexpectedly contacted')
        require(np.array_equal(air.last_time.detach().cpu().numpy(), np.array([.002], dtype=np.float32)),
                'Contact tracker did not use synthetic Data.time')
        require(np.array_equal(current['feet_ground_contact.current_air_time'],
                               np.full((1, 2), .002, dtype=np.float32)), 'Synthetic air time differs')
        context_b = context_fingerprint()
        require(context_b['owners'] == context_a['owners'], 'Native/context owners changed')
        changed_bounds = [n for n in ('lower', 'upper') if context_b['numeric_sha256'][n] != context_a['numeric_sha256'][n]]
        require(changed_bounds, 'BVH bounds were not exercised by pose change')
        check_guards()
        results.append(current)
        primary_b = {n: getattr(sim.wp_data, n).numpy().copy() for n in primary_a}
        np.savez_compressed(out/('primary-B-'+str(trial)+'.npz'), **primary_b)
        save(out/('context-B-'+str(trial)+'.json'), context_b)
        persist('B-'+str(trial), height_delta_m=height_delta.tolist(), changed_bounds=changed_bounds,
                contact_last_time=air.last_time.detach().cpu().numpy().tolist())

        # No reset() substitute: restore the saved Data and every selected owner.
        data_snapshot.preflight()
        sensor_snapshot.preflight()
        data_restore()
        sensor_restore()
        data_snapshot.assert_restored()
        check_guards()
        persist('A-owner-restore-'+str(trial), owners_and_data_exact=True,
                native_BVH_recovery_pending=True)
        # Refit native BVH from restored geometry; regenerate rays and compare all outputs.
        fresh_sense()
        recovered = outputs('A-recovered-'+str(trial))
        equal(baseline, recovered, 'A-recovered-'+str(trial))
        context_recovered = context_fingerprint()
        save(out/('context-A-recovered-'+str(trial)+'.json'), context_recovered)
        require(context_recovered == context_a, 'Numeric context/owners did not recover')
        # Recompute allocated new Torch objects; restore original held references too.
        sensor_restore()
        data_snapshot.assert_restored()
        check_guards()
        equal(baseline, outputs('A-owner-final-'+str(trial)), 'A-owner-final-'+str(trial))
        save(out/('sensor-restored-'+str(trial)+'.json'), sensor_snapshot.manifest())
        save(out/('data-restored-'+str(trial)+'.json'), {'hashes': data_snapshot.fingerprint(), 'owners': data_snapshot.owners})
        persist('A-fully-checked-'+str(trial), selected_owner_bytes_exact=True,
                ray_outputs_after_native_refit_exact=True)
    equal(results[0], results[1], 'B-retry')
    require(counts.get('CPU_forward_completed') == 2 and counts.get('CPU_kinematics_native_completed') == 3 and
            counts.get('GPU_forward_completed') == 3 and counts.get('sense_completed') == 5 and
            counts.get('ray_batch_completed') == 5 and counts.get('BVH_refit_completed') == 5 and
            counts.get('Scene_update_completed') == 3 and counts.get('Scene_reset_completed') == 1 and
            counts.get('Data_restore_completed') == 2 and counts.get('Sensor_owner_restore_completed') == 4 and
            counts.get('sensor_data_reads') == 200 and counts.get('post_sense_cache_invalidations') == 70,
            'Call totals differ from the bounded plan')
    report.update(bounded_synthetic_sensor_transaction_verified=True, retry_output_fields=26,
                  retry_outputs_exact=True, restored_data_and_selected_owners_exact=True,
                  native_BVH_recomputed_output_verified=True, synthetic_time_restored_to_zero=True,
                  BAM_targets_RNG_and_selected_material_unchanged=True,
                  sensor_count=len(sensors), ray_count=ray.num_rays,
                  cleanup='Baseline A verified before private worker exit; no integrated/task-wide rollback claimed')
    save(out/'transaction-result.json', report)
    return report
