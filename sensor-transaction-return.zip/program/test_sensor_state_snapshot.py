"""CPU-only NumPy fixtures for owner/alias/metadata and native-call boundaries."""
from contextlib import nullcontext
from dataclasses import dataclass
from types import SimpleNamespace
import json
from pathlib import Path
import numpy as np

from sensor_state_snapshot import OwnerSnapshot, DataSnapshot, sense_and_invalidate


class Tensor:
    layout = 'strided'
    device = 'fixture'
    requires_grad = False
    def __init__(self, raw, storage=None):
        self.raw = np.asarray(raw)
        self.storage = self.raw if storage is None else storage
    @property
    def shape(self): return self.raw.shape
    @property
    def dtype(self): return self.raw.dtype
    def stride(self): return tuple(s//self.raw.itemsize for s in self.raw.strides)
    def numel(self): return self.raw.size
    def element_size(self): return self.raw.itemsize
    def data_ptr(self): return self.raw.ctypes.data
    def untyped_storage(self): return SimpleNamespace(data_ptr=lambda: self.storage.ctypes.data)
    def storage_offset(self): return (self.data_ptr()-self.storage.ctypes.data)//self.raw.itemsize
    def detach(self): return self
    def clone(self): return Tensor(self.raw.copy())
    def cpu(self): return self
    def numpy(self): return self.raw
    def copy_(self, other): np.copyto(self.raw, other.raw)


class Array:
    device = 'fixture'
    def __init__(self, raw): self.raw = np.asarray(raw)
    @property
    def shape(self): return self.raw.shape
    @property
    def strides(self): return self.raw.strides
    @property
    def dtype(self): return self.raw.dtype
    @property
    def size(self): return self.raw.size
    @property
    def capacity(self): return self.raw.nbytes
    @property
    def ptr(self): return self.raw.ctypes.data if self.raw.size else None
    @property
    def is_contiguous(self): return self.raw.flags.c_contiguous
    def numpy(self): return self.raw.copy()


torch = SimpleNamespace(Tensor=Tensor, strided='strided', no_grad=nullcontext)
wp = SimpleNamespace(array=Array, clone=lambda a: Array(a.raw.copy()),
                     copy=lambda dst, src: np.copyto(dst.raw, src.raw), synchronize=lambda: None)


@dataclass
class Cache:
    tensor: object
    nested: object
Cache.__module__ = 'mjlab.sensor.fixture'


def raises(fn, contains):
    try: fn()
    except (RuntimeError, ValueError) as exc: assert contains in str(exc), str(exc)
    else: raise AssertionError('Expected failure: '+contains)


def main():
    raw = np.arange(42, dtype=np.float32).reshape(6, 7)
    original = raw.copy()
    full = Tensor(raw)
    view = Tensor(raw[1:5:2, 1:6:2], raw)
    transpose = Tensor(raw.T, raw)
    warp_alias = Array(raw)
    context = object()
    cached = Cache(view, {'shared': full, 'list': [transpose, view]})
    root = SimpleNamespace(full=full, view=view, transpose=transpose, warp=warp_alias,
                           _cached_data=cached, _cache_valid=True, _ctx=context,
                           empty=Tensor(np.zeros((1, 0, 6), dtype=np.float32)))
    snap = OwnerSnapshot([('sensor', root, tuple(vars(root)))], torch, wp)
    saved_manifest = snap.manifest()
    raw[:] = -7
    root.view = Tensor(np.zeros((2, 3), dtype=np.float32))
    root._cached_data = Cache(root.view, {})
    root._cache_valid = False
    cached.nested['list'][:] = []
    cached.nested['extra'] = 'changed'
    root._ctx = object()
    snap.restore()
    assert np.array_equal(raw, original)
    assert root.view is view and root._cached_data is cached and root._ctx is context
    assert root._cached_data.tensor is view and root._cached_data.nested['list'][1] is view
    assert root.view.storage_offset() == 8 and root.view.stride() == (14, 2)
    assert snap.manifest() == saved_manifest
    # Every layout preflight runs before any copy, including a later graph node.
    raw[:] = 123
    root.empty.raw = np.zeros((2, 0, 6), dtype=np.float32)
    raises(snap.restore, 'layout/storage changed')
    assert (raw == 123).all()
    raises(lambda: OwnerSnapshot([('x', root, ('full',))], torch, wp, max_bytes=4), 'byte cap')
    broadcast = Tensor(np.broadcast_to(np.ones((1,), dtype=np.float32), (3,)))
    raises(lambda: OwnerSnapshot([('x', SimpleNamespace(x=broadcast), ('x',))], torch, wp), 'overlapping')
    raises(lambda: OwnerSnapshot([('x', SimpleNamespace(x=object()), ('x',))], torch, wp), 'Unsupported')

    @dataclass
    class Data:
        x: object
        alias: object
        zero: object
        nested: object
        nworld: int = 1
    a = Array(np.array([1., np.nan, -0.], dtype=np.float32))
    data = Data(a, a, Array(np.zeros((0,), dtype=np.float32)), {'time': Array(np.zeros(1, dtype=np.float32))})
    snapshot = DataSnapshot(data, wp)
    a.raw[:] = 4
    data.nested['time'].raw[:] = .002
    snapshot.restore()
    assert data.x is a and data.alias is a and np.isnan(a.raw[1])
    a.raw[:] = 8
    data.nworld = 2
    raises(snapshot.restore, 'topology/layout/owner')
    assert (a.raw == 8).all()
    overlapping = np.arange(5, dtype=np.float32)
    overlap_data = Data(Array(overlapping[:3]), Array(overlapping[1:4]), Array(np.zeros(0)), {})
    raises(lambda: DataSnapshot(overlap_data, wp), 'overlapping')

    class Sensor:
        def __init__(self): self.valid=True; self.history_updates=0
        def _invalidate_cache(self): self.valid=False
    sensors = {'a': Sensor(), 'b': Sensor()}
    calls=[]
    sense_and_invalidate(SimpleNamespace(sense=lambda: calls.append('sense')), sensors)
    assert calls==['sense'] and all(not s.valid and s.history_updates==0 for s in sensors.values())
    def fail(): raise RuntimeError('native sense failed')
    for s in sensors.values(): s.valid=True
    raises(lambda: sense_and_invalidate(SimpleNamespace(sense=fail), sensors), 'native sense failed')
    assert all(s.valid for s in sensors.values())
    result = {'status':'PASS','actual_GPU_execution':False,
              'checks':['shared Warp/Torch storage restores exact bytes',
                        'noncontiguous views retain offsets, strides and owners',
                        'cached dataclass, aliases and container membership restored',
                        'native context preserved as reference only',
                        'layout preflight prevents partial copying',
                        'internal overlap and snapshot capacity guards',
                        'full Data alias/NaN/empty/scalar topology checks',
                        'sense cache invalidation does not duplicate history update',
                        'failed sense propagates before invalidation']}
    Path(__file__).with_name('offline-snapshot-validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__': main()
