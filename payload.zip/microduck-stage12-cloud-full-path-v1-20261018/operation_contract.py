"""Offline exact derivation of the new owner ceilings and source-label closure."""
import ast
import sys
from pathlib import Path
from static_common import ROOT,read,require


def literal_labels(tree,methods):
    return {n.args[0].value for n in ast.walk(tree) if isinstance(n,ast.Call)
        and isinstance(n.func,ast.Attribute) and n.func.attr in methods and n.args
        and isinstance(n.args[0],ast.Constant) and isinstance(n.args[0].value,str)}


def expected_owner(candidate):
    sys.path.insert(0,str(candidate))
    from integration.planning import owner_plan
    owner=owner_plan(25,28,0);caps=owner['caps'];f=caps['GPU_forward']
    additions=dict(Contact_order_apply=f,Precise_allocation=4,Precise_module_load=1,
        Precise_geometry_kernel=f,Precise_contact_kernel=f,Kinematic_model_capture=1,
        Kinematic_allocation=2,Kinematic_module_load=1,Kinematic_pose_compute=f,Kinematic_pose_upload=f,
        Hull_allocation=2,Hull_module_load=1,Hull_vertex_pin=1,Hull_fixture_query=128,Hull_fixture_upload=128,
        Data_boundary_restore=0,Model_boundary_restore=0,RNG_bank_initialize=1,full_RL_environment=1)
    additions.update({'ContactGraph_'+k:v for k,v in owner['graph_limits'].items() if k!='device_bytes'})
    caps.update(additions)
    return owner


def validate_caps(candidate,plan):
    candidate=Path(candidate);base=candidate/'baseline/g11/accepted'
    expected=expected_owner(candidate)
    require(plan['owner_plan']==expected,'Owner ceilings differ from frozen 25-step worksheet plus declared correction')
    require(plan['caps']==expected['caps'],'Parent/owner ceilings differ')
    require(plan['graph_limits']==expected['graph_limits'] and plan['contact_layout']==expected['contact_layout'],
            'Graph or contact layout changed')
    names=('full_factory','full_runtime','full_boundary','full_kinematics','full_accounting',
           'kinematic_precision','dynamic_boundary','dynamic_graph','dynamic_accounting')
    paths=[ROOT/(n+'.py') for n in names]
    paths += [base/(n+'.py') for n in ('contact_order_contract','trajectory_candidate','solver_order_candidate',
        'native_rk4_bridge','native_state_bridge','sensor_macro_bridge','ground_pair_driver','isolation_policy')]
    paths += [candidate/'integration/refined_state.py',candidate/'integration/native_runtime.py']
    trees=[ast.parse(p.read_text(),filename=str(p)) for p in paths];required=set()
    for tree in trees:
        required |= literal_labels(tree,{'limited','run','counted'})
        required |= {x for x in literal_labels(tree,{'call'}) if x.startswith(('Solver','Reduction','Cost_','Norm_'))}
        for node in ast.walk(tree):
            if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='limit' and len(node.args)>2 and isinstance(node.args[2],ast.Constant):
                required.add(node.args[2].value)
            if isinstance(node,ast.For) and isinstance(node.target,ast.Tuple) and [getattr(x,'id',None) for x in node.target.elts]==['obj','name','label'] and isinstance(node.iter,ast.Tuple):
                required |= {ast.literal_eval(row.elts[2]) for row in node.iter.elts}
            if isinstance(node,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='roster' for x in node.targets) and isinstance(node.value,ast.Dict):
                try:
                    roster=ast.literal_eval(node.value)
                    required |= {label for entries in roster.values() for _,label in entries}
                except (ValueError,TypeError):pass
    source=ast.parse((base/'trajectory_candidate.py').read_text())
    for node in ast.walk(source):
        if isinstance(node,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='labels' for x in node.targets):
            required |= {'Solver'+k for k in ast.literal_eval(node.value)}
    required |= {'GPU_solver','SolverContext_create','RNG_sample','Precise_geometry_kernel','Hull_fixture_query'}
    required |= {'ContactGraph_'+k for k in plan['graph_limits'] if k!='device_bytes'}
    caps=plan['caps'];require(not required-set(caps),'Missing callable caps: '+repr(sorted(required-set(caps))))
    require(all(type(caps[k]) is int and caps[k]>=0 for k in required),'Callable has no integer cap')
    require(plan['tiers']==[32,64,128,256,512] and plan['maximum_trials_per_macro']==6,'Finite trials differ')
    require(plan['max_integrations']==caps['integrations']==376000 and plan['max_forward']==caps['GPU_forward']==1506254,'Finite total differs')
    require(plan['public_RL_steps']==25 and plan['rollout_steps']==24 and plan['post_explicit_reset_steps']==1,'Public schedule differs')
    require(plan['new_native_window_seconds']==85500 and plan['new_total_window_seconds']==86400 and plan['cleanup_reserve_seconds']==900,'New window differs')
    require(plan['original_deadlines']==dict(native='2026-10-17T11:23:14+08:00',total='2026-10-17T11:53:14+08:00') and not plan['deadline_reset'],'Historical deadlines changed')
    require(plan['canonical_integrations_before']==dict(completed_lower=738600,completed_upper=738601,attempted_lower=738602,attempted_upper=738602),'Historical totals changed')
    require(plan['scope']=='CLOUD_RTX5090_FULL_PATH_V1' and plan['cloud_measurement'] is True, 'Cloud measurement scope changed')
    require(plan['prior_partial_scope']['commit']=='81217fe7bdecbf2683b7706d00668b0db881c403' and not plan['prior_partial_scope']['full_owner_checkpoint'], 'Prior stopped owner identity changed')
    require(plan['latest_verified_commit']=='e256a0789ebfb0a1a35d621856e50479c4b89c8e','Latest verified result changed')
    require(plan['PPO']==plan['cloud_training']==caps['PPO']==caps['cloud']==0,'Training is not authorized')
    for key in ('automatic_push','automatic_PR','automatic_merge','automatic_power_actions','old_campaign_resume','old_windows_reusable','new_native_budget_authorized','training_ready'):
        require(not plan[key],'Forbidden permission: '+key)
    return dict(status='FULL_PATH_CALLABLE_CAP_CLOSURE_PASS',labels=sorted(required),
        integrations=376000,forward=1506254,macro_cap=250,public_steps=25,native_calls=0)
