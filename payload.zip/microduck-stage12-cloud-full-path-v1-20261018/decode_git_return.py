"""Decode immutable Git volume checkouts. No network or simulator calls."""
import argparse
import base64
import io
import json
import shutil
import tempfile
import zipfile
from pathlib import Path,PurePosixPath
from static_common import read,require,sha,write
from segmented_return import LIMIT,CHUNK,sha as bytes_sha


def safe(root,name):
    p=PurePosixPath(name)
    require(isinstance(name,str) and p.as_posix()==name and not p.is_absolute()
            and all(s not in ('','.','..') for s in p.parts) and '\\' not in name,'Unsafe segment path')
    result=root.joinpath(*p.parts)
    require(result.resolve().is_relative_to(root.resolve()) and not result.is_symlink(),'Escaping segment')
    return result


def decode(git_root,output):
    git_root=Path(git_root).resolve();output=Path(output).absolute()
    require(not output.exists(),'Decoded output already exists; preserve it')
    manifest=read(git_root/'index/MANIFEST.json')
    require(manifest['format']=='stage12-full-path-segmented-git-return-v1'
            and manifest['archive_limit_bytes']==LIMIT,'Return format or immutable limit differs')
    output.parent.mkdir(parents=True,exist_ok=True)
    staging=Path(tempfile.mkdtemp(prefix=output.name+'.decoding-',dir=output.parent));sizes={};archives=0
    try:
        for number,row in enumerate(manifest['archives']):
            require(row['number']==number and row['directory']=='volume-%03d'%number,'Volume sequence differs')
            folder=git_root/row['directory'];meta=read(folder/'MANIFEST.json')
            require(sha(folder/'MANIFEST.json')==row['manifest_sha256'] and all(meta[k]==row[k] for k in meta),'Volume manifest identity differs')
            require(meta['format']=='stage12-full-path-segment-volume-v1' and 0<meta['archive_bytes']<=LIMIT,'Oversized volume')
            buf=bytearray()
            for j,part in enumerate(meta['parts']):
                require(part['name']=='part-%04d.b64'%j and 0<part['bytes']<=524289,'Part sequence/limit differs')
                b=(folder/part['name']).read_bytes()
                require(len(b)==part['bytes'] and bytes_sha(b)==part['sha256'] and b.endswith(b'\n'),'Part bytes differ')
                buf.extend(base64.b64decode(b[:-1],validate=True))
                require(len(buf)<=LIMIT,'Decoded archive exceeds limit')
            require(len(buf)==meta['archive_bytes'] and bytes_sha(buf)==meta['archive_sha256'],'Archive identity differs')
            with zipfile.ZipFile(io.BytesIO(buf)) as z:
                require(len(z.namelist())==len(set(z.namelist())),'Duplicate archive member')
                require(z.getinfo('segments.json').file_size<2*1024**2,'Oversized segment index')
                segments=json.loads(z.read('segments.json'))
                require(set(z.namelist())=={'segments.json',*(r['member'] for r in segments)},'Archive member roster differs')
                for segment in segments:
                    target=segment['target'];f=safe(staging,target)
                    require(PurePosixPath(target).parts[0] in ('evidence','diagnostic-package'),'Unknown return section')
                    require(type(segment['offset']) is int and segment['offset']==sizes.get(target,0)
                            and type(segment['bytes']) is int and 0<=segment['bytes']<=CHUNK,'Segment offset/size differs')
                    require(z.getinfo(segment['member']).file_size==segment['bytes'],'Segment ZIP size differs')
                    b=z.read(segment['member']);require(bytes_sha(b)==segment['sha256'],'Segment identity differs')
                    f.parent.mkdir(parents=True,exist_ok=True)
                    with f.open('ab' if target in sizes else 'xb') as stream:stream.write(b)
                    sizes[target]=sizes.get(target,0)+len(b)
            archives+=1
        index=staging/'evidence/evidence-index.json'
        require(sha(index)==manifest['evidence_index_sha256'],'Evidence index identity differs')
        roster={'evidence/evidence-index.json'}
        for name,pin in read(index)['files'].items():
            f=safe(staging/'evidence',name);roster.add('evidence/'+name)
            require(f.stat().st_size==pin['bytes'] and sha(f)==pin['sha256'],'Reconstructed evidence differs: '+name)
        package=staging/'diagnostic-package';m=package/'MANIFEST.json'
        require(sha(m)==manifest['package_manifest_sha256'],'Package manifest identity differs')
        roster.add('diagnostic-package/MANIFEST.json')
        for name,pin in read(m)['files'].items():
            if name=='frozen-inputs.zip':
                require(pin['sha256']==manifest['omitted_frozen_inputs']['sha256'],'Omitted frozen payload differs');continue
            f=safe(package,name);roster.add('diagnostic-package/'+name)
            require(f.stat().st_size==pin['bytes'] and sha(f)==pin['sha256'],'Reconstructed package differs: '+name)
        require(set(sizes)==roster,'Unexpected or missing reconstructed files')
        (staging/'transport').mkdir();shutil.copyfile(git_root/'index/MANIFEST.json',staging/'transport/MANIFEST.json')
        review=dict(status='SEGMENTED_RETURN_DECODE_VERIFIED',archives=archives,files=len(sizes),bytes=sum(sizes.values()),native_calls=0)
        write(staging/'transport/decode-review.json',review,exclusive=True)
        staging.rename(output);return review
    except BaseException as exc:
        write(staging/'decode-failure.json',dict(error=repr(exc),preserved=True));raise


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--git-root',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();print(json.dumps(decode(a.git_root,a.output),indent=2))
