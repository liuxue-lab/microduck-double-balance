"""Offline MJCF/topology reconstruction, accepted only on exact archived Model SHA256s."""
import hashlib
from pathlib import Path
import xml.etree.ElementTree as ET
import numpy as np
from static_common import ROOT,read,require

def reconstruct(project):
    x=ET.parse(Path(project)/'src/mjlab_microduck/robot/microduck/robot_allcollisions.xml')
    bodies=list(x.getroot().find('worldbody').iter('body'));require(len(bodies)==15,'Robot body roster differs')
    ids={id(b):i+2 for i,b in enumerate(bodies)}
    parentmap={id(child):ids[id(b)] for b in bodies for child in b.findall('body')}
    parents=[0,0]+[parentmap.get(id(b),0) for b in bodies]+[0,0]
    def vec(b,name,default):return list(map(float,b.get(name,default).split()))
    pos=np.array([[0,0,0]]*2+[vec(b,'pos','0 0 0') for b in bodies]+[[0,0,.12],[0,0,.02]],np.float32)[None]
    quat=np.array([[1,0,0,0]]*2+[vec(b,'quat','1 0 0 0') for b in bodies]+[[1,0,0,0]]*2,float)
    quat=(quat/np.linalg.norm(quat,axis=1)[:,None]).astype(np.float32)[None]
    for b in bodies[1:]:
        j=b.find('joint');require(j is not None and j.get('type')=='hinge' and j.get('ref') is None and j.get('pos') is None,'Unreviewed joint')
        require(vec(j,'axis','0 0 1')==[0,0,1],'Joint axis differs')
    ints=dict(body_parentid=parents,body_mocapid=[-1]*19,body_jntnum=[0,0]+[1]*17,
        body_jntadr=[-1,-1]+list(range(17)),jnt_type=[0]+[3]*14+[0,0],jnt_qposadr=[0]+list(range(7,21))+[21,28])
    raw={n:np.array(v,np.int32) for n,v in ints.items()}
    qpos0=np.zeros((1,35),np.float32);qpos0[0,[2,23,30]]=[.12,.12,.02];qpos0[0,[3,24,31]]=1
    raw.update(body_pos=pos,body_quat=quat,qpos0=qpos0,jnt_pos=np.zeros((1,17,3),np.float32),
        jnt_axis=np.tile(np.array([0,0,1],np.float32),(1,17,1)))
    with np.load(ROOT/'source-reference/compiled-geom-pose.npz',allow_pickle=False) as z:raw.update({n:z[n].copy() for n in z.files})
    pins=read(ROOT/'origin/macro-68/raw/record-00001-snapshot.json')['model_hashes']
    hashes={n:hashlib.sha256(v.tobytes()).hexdigest() for n,v in raw.items()}
    require(len(raw)==14 and all(h==pins['Model.'+n] for n,h in hashes.items()),'Kinematic reconstruction differs from archived model')
    from kinematic_precision import reference_model
    reference_model(raw,pins)
    return raw,dict(status='KINEMATIC_MODEL_14_ARRAYS_EXACT',hashes=hashes,native_calls=0)
