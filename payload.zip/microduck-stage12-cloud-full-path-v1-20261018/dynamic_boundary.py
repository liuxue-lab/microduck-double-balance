"""Fresh certified collision on every live RK/endpoint pose, before contact sorting.

Only one declared macro, fixed trial roster, single world and the pinned pair.
Every pose must pass the exact convex-vertex certificate. No fallback to the
old narrowphase, no invented edge/face distance, no epsilon or fixed vertex ID.
"""
import gzip
import hashlib
import json
import numpy as np
from static_common import ROOT, read, require, write
from kernel_layout import MATERIALS, CONTACT_FIELDS

def target_mask(raw,n):
    g=raw['geom'][:n]
    return (raw['worldid'][:n]==0)&(((g[:,0]==84)&(g[:,1]==49))|((g[:,0]==49)&(g[:,1]==84)))

def validate_replacement(before,after,old_n,new_n,result):
    old=target_mask(before,old_n); new=target_mask(after,new_n); active=result[3]<0
    require(new.sum()==int(active) and new_n==old_n-int(old.sum())+int(active),'Target/count mismatch')
    other={}
    for name in CONTACT_FIELDS:
        a=before[name][:old_n][~old].tobytes(); b=after[name][:new_n][~new].tobytes()
        require(a==b,'Unrelated contact changed: '+name)
        other[name]=hashlib.sha256(a).hexdigest()
    target=None
    if active:
        i=int(np.flatnonzero(new)[0]); normal=after['frame'][i,0].astype(np.float64)
        require(after['dist'][i]==np.float32(result[3]) and np.linalg.norm(normal-result[4:7])<1e-6,'Published geometry differs')
        require(np.isfinite(after['frame'][i]).all() and np.all(after['efc_address'][i]==-1),'Invalid frame/address')
        require(after['geomcollisionid'][i]==0 and after['type'][i]==1 and after['includemargin'][i]==0,'Contact semantics differ')
        target={n:after[n][i].tolist() for n in CONTACT_FIELDS}
    return dict(old_contacts=old_n,new_contacts=new_n,old_target=int(old.sum()),new_target=int(new.sum()),
                other_contact_fields_byte_identical=len(CONTACT_FIELDS),other_fields_sha256=other,target=target)

class DynamicBoundary:
    def __init__(self,m,d,wp,gate,out,plan):
        import precise_contact_kernel as kernels
        self.m,self.d,self.wp,self.gate,self.out,self.plan=m,d,wp,gate,out,plan
        self.kernels=kernels; self.calls=0; self.attempts=0; self.phase='idle'; self.trial=0
        from kinematic_precision import KinematicPrecision
        self.kinematics=KinematicPrecision(m,d,wp,gate,out,plan)
        self.trial_proofs=[];self.pose_digest=None
        self.trial_calls=0; self.resolution=None; self.raw_bytes=0; self.closed=False
        self.stream=gzip.open(out/'geometry-witness.jsonl.gz','xb')
        self.digest=hashlib.sha256(); self.contract=read(ROOT/'geometry-contract.json')
        require(d.nworld==1 and d.naconmax==256,'Single-world capacity differs')
        require(int(m.geom_type.numpy()[84])==2 and int(m.geom_type.numpy()[49])==7,'Sphere/mesh type differs')
        require(int(m.geom_dataid.numpy()[0,49])==16,'Mesh identity differs')
        require(int(m.mesh_vertadr.numpy()[16])==100264 and int(m.mesh_vertnum.numpy()[16])==8062,'Mesh layout differs')
        require(float(m.geom_size.numpy()[0,84,0])==self.contract['radius'],'Sphere radius differs')
        require(m.sensor_collision_start_adr.size==0 and np.all(m.collision_sensor_adr.numpy()==-1),'Collision-distance sensor outside scope')
        require(m.pair_dim.size==0,'Explicit contact pair override outside scope')
        for n in ('geom_margin','geom_gap'): require(np.all(getattr(m,n).numpy()[:,[84,49]]==0),'Margin/gap changed')
        require(m.opt.ccd_tolerance.numpy().shape==(1,) and float(m.opt.ccd_tolerance.numpy()[0])==9.999999974752427e-7 and int(m.opt.ccd_iterations)==50,'CCD configuration changed')
        self.geometry=gate.limited('Precise_allocation',4,lambda:wp.zeros((1,11),dtype=wp.float64,device=d.qpos.device))()
        self.pair=gate.limited('Precise_allocation',4,lambda:wp.array([[84,49]],dtype=wp.vec2i,device=d.qpos.device))()
        self.pairid=gate.limited('Precise_allocation',4,lambda:wp.array([[-1,-1]],dtype=wp.vec2i,device=d.qpos.device))()
        self.status=gate.limited('Precise_allocation',4,lambda:wp.zeros(1,dtype=int,device=d.qpos.device))()
        require(sum(a.numpy().nbytes for a in (self.geometry,self.pair,self.pairid,self.status))==108,'Correction allocation differs')
        gate.limited('Precise_module_load',1,lambda:wp.load_module(kernels,device=d.qpos.device))()
    def begin_trial(self,resolution,role,serial):
        require(self.phase=='idle' and resolution in (32,64,128,256,512) and serial==self.trial+1 and serial<=6,'Unscheduled collision trial')
        self.phase='trial';self.resolution=resolution;self.role=role;self.trial=serial;self.trial_calls=0
        self.pose_digest=hashlib.sha256()
    def end_trial(self):
        require(self.phase=='trial' and self.trial_calls==4*self.resolution+1,'Incomplete trial forward coverage')
        proof=dict(trial=self.trial,resolution=self.resolution,role=self.role,
                   forwards=self.trial_calls,kinematic_sha256=self.pose_digest.hexdigest())
        if self.role=='replay':
            previous=self.trial_proofs[-1]
            require(previous['resolution']==self.resolution and previous['role']!='replay'
                    and previous['kinematic_sha256']==proof['kinematic_sha256'],
                    'Exact kinematic replay failed; no publication')
        self.trial_proofs.append(proof)
        write(self.out/'kinematic-trials.json',dict(trials=self.trial_proofs))
        self.phase='idle'
    def begin_commit(self):
        require(self.phase=='idle' and self.role=='replay','Publication requires completed replay')
        self.phase='commit';self.trial_calls=0
    def append(self,row):
        raw=(json.dumps(row,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
        require(self.raw_bytes+len(raw)<=self.plan['geometry_uncompressed_bytes'],'Geometry evidence cap reached')
        self.stream.write(raw);self.stream.flush();self.digest.update(raw);self.raw_bytes+=len(raw)
    def wrap(self,native):
        def call(m,d):
            require(m is self.m and d is self.d and not self.closed,'Unexpected owner or closed correction')
            require(self.phase in ('trial','commit'),'Collision outside declared dynamic forward')
            cap=4*self.resolution+1 if self.phase=='trial' else 1
            require(self.trial_calls<cap and self.calls<self.plan['caps']['GPU_forward'],'Dynamic collision budget exhausted')
            require(self.gate.counts['GPU_forward_attempted']==self.gate.counts.get('GPU_forward_completed',0)+1==self.calls+1,'Collision/forward coverage mismatch')
            value=native(m,d);self.attempts+=1
            native_position=d.geom_xpos.numpy()[0,[84,49]];native_rotation=d.geom_xmat.numpy()[0,[84,49]]
            position,rotation,kinematic=self.gate.limited('Kinematic_pose_compute',self.plan['caps']['GPU_forward'],lambda:self.kinematics.compute(self))()
            require(np.isfinite(position).all() and np.isfinite(rotation).all(),'Nonfinite dynamic geometry')
            args=[m.mesh_vert,self.kinematics.positions,self.kinematics.rotations,100264,8062,0,1,self.contract['radius'],self.geometry]
            self.gate.limited('Precise_geometry_kernel',self.plan['caps']['GPU_forward'],lambda:self.wp.launch(self.kinematics.kernels.certified_geometry,dim=1,inputs=args,device=d.qpos.device))()
            result=self.geometry.numpy()[0]
            row=dict(serial=self.attempts,phase=self.phase,trial=self.trial,resolution=self.resolution,role=self.role,
                trial_forward=self.trial_calls,position=position.tolist(),rotation=rotation.tolist(),
                native_position=native_position.tolist(),native_rotation=native_rotation.tolist(),kinematics=kinematic,
                values=result.tolist() if np.isfinite(result).all() else None,
                primary_sha256={n:hashlib.sha256(getattr(d,n).numpy().tobytes()).hexdigest() for n in ('qpos','qvel','time','ctrl')})
            if not (np.isfinite(result).all() and result[10]==1):
                row['certificate_failed_before_mutation']=True;self.append(row)
                raise RuntimeError('Dynamic convex-vertex certificate failed; no fallback or contact mutation')
            before={n:getattr(d.contact,n).numpy().copy() for n in CONTACT_FIELDS}
            old_n=int(d.nacon.numpy()[0]);require(0<=old_n<=256,'Original contact overflow')
            count=int(target_mask(before,old_n).sum());require(count<=1,'Unexpected target multiplicity')
            require(old_n-count+int(result[3]<0)<=256,'Corrected contact overflow')
            args=[getattr(m,n) for n in MATERIALS]+[self.pair,self.pairid,self.geometry,d.naconmax,d.nacon]+[getattr(d.contact,n) for n in CONTACT_FIELDS]+[self.status]
            self.gate.limited('Precise_contact_kernel',self.plan['caps']['GPU_forward'],lambda:self.wp.launch(self.kernels.replace_target,dim=1,inputs=args,device=d.qpos.device))()
            after={n:getattr(d.contact,n).numpy().copy() for n in CONTACT_FIELDS}
            row['mutation']=validate_replacement(before,after,old_n,int(d.nacon.numpy()[0]),result)
            require(int(self.status.numpy()[0])==int(result[3]<0),'Mutation status differs')
            if self.phase=='trial':
                physical={k:row[k] for k in ('position','rotation','kinematics','values','mutation','primary_sha256')}
                self.pose_digest.update(json.dumps(physical,sort_keys=True,separators=(',',':'),allow_nan=False).encode()+b'\n')
            self.append(row);self.calls+=1;self.trial_calls+=1
            return value
        return call
    def close(self):
        if not self.closed:self.stream.close();self.closed=True
        return dict(attempts=self.attempts,completed=self.calls,raw_bytes=self.raw_bytes,sha256=self.digest.hexdigest(),closed=self.closed,
                    kinematic_trial_proofs=self.trial_proofs)
