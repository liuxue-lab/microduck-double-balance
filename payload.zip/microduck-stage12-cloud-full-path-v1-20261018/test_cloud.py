"""Cloud transport/lifecycle regressions with zero network and zero native calls."""
import argparse
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch
import zipfile

ROOT=Path(__file__).resolve().parent

class CloudTests(unittest.TestCase):
    def test_old_uncertainty_survives_new_interrupted_run(self):
        import run_full
        ledger=dict(integration_attempted_lower=10,integration_attempted_upper=10,
            integration_completed_lower=9,integration_completed_upper=10,exact=False,pending={'integrations':10})
        with tempfile.TemporaryDirectory() as td:
            run=Path(td);(run/'native/owner-0').mkdir(parents=True);(run/'native/owner-0/native-ledger.jsonl').write_text('')
            plan=json.loads((ROOT/'plan.json').read_text())
            with patch('runtime_accounting.review_ledger',return_value=ledger):r=run_full.collect(run,plan,{},error='test interrupted')
            self.assertEqual(r['canonical_after_interval'],dict(attempted_lower=738612,attempted_upper=738612,completed_lower=738609,completed_upper=738611))
            self.assertEqual(r['status'],'FULL_PATH_STOPPED_PRESERVE')
            self.assertEqual(r['ledger']['pending'],{'integrations':10})
    def test_cloud_reentry_never_launches_second_native_owner(self):
        import cloud_remote as m
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);control=root/'control';control.mkdir();run=root/'run';run.mkdir()
            (control/'DAEMON-INTENT.json').write_text('{}')
            with patch.object(m,'CONTROL',control),patch.object(m,'RUN',run),patch.object(m,'preflight') as pre,patch.object(m,'status'):
                m.launch();pre.assert_not_called()
    def test_collection_refuses_running_daemon(self):
        import cloud_remote as m
        with patch.object(m,'daemon_active',return_value=True):
            with self.assertRaisesRegex(RuntimeError,'still active'):m.prepare_transfer()
    def test_stop_is_idempotent_request_without_signal_or_launch(self):
        import cloud_remote as m
        with tempfile.TemporaryDirectory() as td,patch.object(m,'RUN',Path(td)),patch('subprocess.Popen') as popen:
            run=Path(td);(run/'started.json').write_text('{}')
            m.stop();first=(run/'STOP_REQUEST.json').read_bytes();m.stop()
            self.assertEqual(first,(run/'STOP_REQUEST.json').read_bytes());popen.assert_not_called()
            (run/'evidence-index.json').write_text('{}')
            with self.assertRaisesRegex(RuntimeError,'No active'):m.stop()
    def test_stop_checked_before_new_macro_mutations(self):
        from full_runtime import FullRuntime
        with tempfile.TemporaryDirectory() as td,patch.dict(os.environ,MD12_FULL_RUN_DIRECTORY=td):
            (Path(td)/'STOP_REQUEST.json').write_text('{}')
            obj=FullRuntime.__new__(FullRuntime);obj.gate=NS(boundary=lambda:None)
            with self.assertRaisesRegex(RuntimeError,'macro boundary'):obj.advance(object())
    def test_missing_cloned_runtime_does_not_install_or_launch(self):
        import cloud_remote as m
        plan={**m.PLAN,'deployment':{**m.PLAN['deployment'],'runtime_candidates':['/missing-runtime-for-offline-fixture/bin/python']}}
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);run=root/'run';control=root/'control';control.mkdir()
            with patch.object(m,'BASE',root),patch.object(m,'RUN',run),patch.object(m,'CONTROL',control),patch.object(m,'PLAN',plan),\
                 patch.object(m,'verify_package'),patch.object(m,'identity_environment',return_value=root),patch.object(m,'prepare',return_value={}),\
                 patch.object(m.shutil,'disk_usage',return_value=NS(free=100*1024**3)),patch('subprocess.run') as sub:
                with self.assertRaisesRegex(RuntimeError,'No cloned runtime'):m.preflight()
                sub.assert_not_called();self.assertFalse((run/'started.json').exists())
                self.assertEqual(len(list(control.glob('runtime-check-*'))),1)
    def test_cloud_input_commit_mismatch_refused_before_checkout(self):
        import cloud_bootstrap as m
        desc=dict(input_commit='1'*40,zip_sha256='2'*64,package_manifest_sha256='3'*64,
            package='microduck-stage12-cloud-full-path-v1-20261018',branch='stage12-cloud-full-path-v1-input-fixture')
        calls=[]
        def fake(repo,*args,**kw):
            calls.append(args)
            if args==('remote',):return ''
            if args==('rev-parse','FETCH_HEAD'):return '4'*40
            return ''
        with tempfile.TemporaryDirectory() as td,patch.object(m,'BASE',Path(td)),patch.object(m,'git',side_effect=fake),patch.object(m,'ssh_command',return_value='ssh'):
            with self.assertRaisesRegex(RuntimeError,'no longer matches'):m.execute('launch',desc)
        self.assertFalse(any(x[0]=='checkout' for x in calls))
    def test_cloud_zip_escaping_path_refused(self):
        import cloud_bootstrap as m
        with tempfile.TemporaryDirectory() as td,patch.object(m,'BASE',Path(td)):
            root=Path(td);archive=root/'evil.zip'
            with zipfile.ZipFile(archive,'w') as z:z.writestr('microduck-stage12-cloud-full-path-v1-20261018/../escape','x')
            with self.assertRaisesRegex(RuntimeError,'Unsafe'):m.unpack(archive,'microduck-stage12-cloud-full-path-v1-20261018','0'*64)
            self.assertFalse((root/'escape').exists())
    def test_input_commit_is_reused_and_does_not_publish(self):
        m=CLIENT
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);repo=root/'canonical';repo.mkdir();state=root/'state';state.mkdir()
            subprocess.run(['git','init',str(repo)],check=True,capture_output=True)
            for key,value in [('user.name','Offline fixture'),('user.email','offline@example.invalid'),('remote.origin.url',m.REMOTE)]:
                subprocess.run(['git','-C',str(repo),'config',key,value],check=True)
            archive=root/'payload.zip';archive.write_bytes(b'fixed offline fixture')
            with patch.object(m,'CANONICAL',repo),patch.object(m,'STATE',state),patch.object(m,'ZIP_SHA',m.sha(archive)):
                _,a=m.prepare_input(archive);_,b=m.prepare_input(archive)
                self.assertEqual(a,b);self.assertFalse((repo/'.git/refs/heads/double-balance').exists())
                self.assertEqual(subprocess.check_output(['git','-C',str(state/'input-git'),'rev-list','--count','HEAD'],text=True).strip(),'1')
                (state/'input-git/payload.zip').write_bytes(b'modified')
                with self.assertRaisesRegex(RuntimeError,'ZIP differs'):m.prepare_input(archive)
    def test_client_disconnect_only_terminates_ssh(self):
        m=CLIENT
        class Input:
            def write(self,value):pass
            def close(self):pass
        class Output:
            def __iter__(self):raise KeyboardInterrupt
        process=NS(stdin=Input(),stdout=Output(),terminate=lambda:None,wait=lambda:130)
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);(root/'cloud_bootstrap.py').write_text('pass')
            with patch.object(m,'descriptor',return_value={}),patch.object(m.subprocess,'Popen',return_value=process) as start:
                code,info=m.remote(root,'status')
                self.assertEqual(code,130);self.assertIsNone(info)
                args=start.call_args.args[0];self.assertEqual(args[0],'ssh');self.assertIn('36138',args);self.assertNotIn('stop',args[-1])

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--candidate',type=Path,required=True);p.add_argument('--client',type=Path,required=True);a,other=p.parse_known_args()
    c=a.candidate.resolve();sys.path[:0]=[str(ROOT),str(c),str(c/'baseline/g11'),str(c/'baseline/g11/accepted'),str(c/'baseline/g11/host-candidate')]
    spec=importlib.util.spec_from_file_location('cloud_client',a.client);CLIENT=importlib.util.module_from_spec(spec);spec.loader.exec_module(CLIENT)
    unittest.main(argv=[sys.argv[0],*other])
