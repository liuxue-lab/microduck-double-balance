"""Scoped convex vertex certificate and contact replacement; Warp 1.12.0/MW 3.8.1.
No acceptance epsilon. Fail-closed host gate precedes contact mutation.
This is a static candidate, not a general sphere-mesh collision implementation.
"""
import warp as wp
from mujoco_warp._src.types import vec5
from mujoco_warp._src.math import make_frame
from mujoco_warp._src.collision_core import contact_params, write_contact
wp.set_module_options({"enable_backward": False, "fast_math": False, "fuse_fp": False})

@wp.func
def relative_vertex(v:wp.vec3, r:wp.mat33, p:wp.vec3, s:wp.vec3):
    result=wp.vec3d()
    for k in range(3):
        result[k]=(wp.float64(r[k,0])*wp.float64(v[0])+wp.float64(r[k,1])*wp.float64(v[1])+wp.float64(r[k,2])*wp.float64(v[2]))+(wp.float64(p[k])-wp.float64(s[k]))
    return result

@wp.kernel
def certified_geometry(vertices:wp.array[wp.vec3],positions:wp.array2d[wp.vec3],rotations:wp.array2d[wp.mat33],
                       vertex_start:int,vertex_count:int,sphere_id:int,mesh_id:int,radius:float,
                       result:wp.array2d[wp.float64]):
    w=wp.tid()
    r=rotations[w,mesh_id];p=positions[w,mesh_id];s=positions[w,sphere_id]
    best=wp.float64(1.0e300);best_id=int(-1);v_best=wp.vec3d()
    for j in range(vertex_count):
        v=relative_vertex(vertices[vertex_start+j],r,p,s)
        q=wp.dot(v,v)
        if q<best:
            best=q;best_id=j;v_best=v
    min_dot=wp.float64(1.0e300)
    for j in range(vertex_count):
        v=relative_vertex(vertices[vertex_start+j],r,p,s)
        min_dot=wp.min(min_dot,wp.dot(v-v_best,v_best))
    length=wp.sqrt(best)
    result[w,0]=wp.float64(best_id);result[w,1]=min_dot;result[w,2]=length
    result[w,3]=length-wp.float64(radius)
    valid=int(0)
    if best_id>=0 and min_dot>=wp.float64(0.0) and length>wp.float64(0.0):
        valid=1
        normal=v_best/length
        for k in range(3):
            result[w,4+k]=normal[k]
            result[w,7+k]=wp.float64(s[k])+(normal[k]*wp.float64(radius)+v_best[k])*wp.float64(0.5)
    result[w,10]=wp.float64(valid)

@wp.kernel
def replace_target(
    geom_condim:wp.array[int],
    geom_priority:wp.array[int],
    geom_solmix:wp.array2d[float],
    geom_solref:wp.array2d[wp.vec2],
    geom_solimp:wp.array2d[vec5],
    geom_friction:wp.array2d[wp.vec3],
    geom_margin:wp.array2d[float],
    geom_gap:wp.array2d[float],
    pair_dim:wp.array[int],
    pair_solref:wp.array2d[wp.vec2],
    pair_solreffriction:wp.array2d[wp.vec2],
    pair_solimp:wp.array2d[vec5],
    pair_margin:wp.array2d[float],
    pair_gap:wp.array2d[float],
    pair_friction:wp.array2d[vec5],
    pair:wp.array[wp.vec2i],pairid:wp.array[wp.vec2i],geometry:wp.array2d[wp.float64],naconmax:int,nacon:wp.array[int],
    c_dim:wp.array[int],
    c_dist:wp.array[float],
    c_efc_address:wp.array2d[int],
    c_flex:wp.array[wp.vec2i],
    c_frame:wp.array[wp.mat33],
    c_friction:wp.array[vec5],
    c_geom:wp.array[wp.vec2i],
    c_geomcollisionid:wp.array[int],
    c_includemargin:wp.array[float],
    c_pos:wp.array[wp.vec3],
    c_solimp:wp.array[vec5],
    c_solref:wp.array[wp.vec2],
    c_solreffriction:wp.array[wp.vec2],
    c_type:wp.array[int],
    c_vert:wp.array[wp.vec2i],
    c_worldid:wp.array[int],
    mutation_status:wp.array[int]):
    # One world, one thread. The host validates shape/certificate/capacity first.
    if geometry[0,10]!=wp.float64(1.0):
        mutation_status[0]=-1
        return
    count=nacon[0];dest=int(0)
    for src in range(count):
        g=c_geom[src]
        target=c_worldid[src]==0 and ((g[0]==pair[0][0] and g[1]==pair[0][1]) or (g[1]==pair[0][0] and g[0]==pair[0][1]))
        if not target:
            if dest!=src:
                c_dim[dest]=c_dim[src]
                c_dist[dest]=c_dist[src]
                for k in range(c_efc_address.shape[1]):
                    c_efc_address[dest,k]=c_efc_address[src,k]
                c_flex[dest]=c_flex[src]
                c_frame[dest]=c_frame[src]
                c_friction[dest]=c_friction[src]
                c_geom[dest]=c_geom[src]
                c_geomcollisionid[dest]=c_geomcollisionid[src]
                c_includemargin[dest]=c_includemargin[src]
                c_pos[dest]=c_pos[src]
                c_solimp[dest]=c_solimp[src]
                c_solref[dest]=c_solref[src]
                c_solreffriction[dest]=c_solreffriction[src]
                c_type[dest]=c_type[src]
                c_vert[dest]=c_vert[src]
                c_worldid[dest]=c_worldid[src]
            dest+=1
    nacon[0]=dest
    geoms,margin,gap,condim,friction,solref,solreffriction,solimp=contact_params(
        geom_condim,geom_priority,geom_solmix,geom_solref,geom_solimp,geom_friction,geom_margin,geom_gap,pair_dim,pair_solref,pair_solreffriction,pair_solimp,pair_margin,pair_gap,pair_friction,pair,pairid,0,0)
    distance=float(geometry[0,3])
    pos=wp.vec3(float(geometry[0,7]),float(geometry[0,8]),float(geometry[0,9]))
    normal=wp.vec3(float(geometry[0,4]),float(geometry[0,5]),float(geometry[0,6]))
    active=write_contact(naconmax,0,distance,pos,make_frame(normal),margin,gap,condim,friction,solref,solreffriction,solimp,geoms,pairid[0],0,
        c_dist,c_pos,c_frame,c_includemargin,c_friction,c_solref,c_solreffriction,c_solimp,c_dim,c_geom,c_efc_address,c_worldid,c_type,c_geomcollisionid,nacon)
    if active==1 and dest<naconmax:
        c_flex[dest]=wp.vec2i(-1,-1);c_vert[dest]=wp.vec2i(-1,-1)
    mutation_status[0]=active
