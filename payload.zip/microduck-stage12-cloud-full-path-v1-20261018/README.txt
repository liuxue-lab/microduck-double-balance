microduck-double-balance Stage12 / 5090 云端完整路径 v1 / 2026-10-18

当前需要用户执行：在本机上传这个新输入包，再通过 SSH 启动云端后台验证。
本机新增积分=0；新云端批次 PPO=0、cloud_training=0、training_ready=false。
云 GPU 用于本轮物理验证。正式 PPO 训练仍未授权、未准备、未启动。

一、下载与执行
把同名 PY 与 ZIP 放到 /home/lx/下载，无需手动解压。
第一条：用户明确执行 Git SSH 输入包推送（独立分支，不改变 double-balance）：
python3 "/home/lx/下载/microduck-stage12-cloud-full-path-v1-20261018.py" --push-inputs

第二条：检查克隆环境并启动一次新的云端后台 N1 验证，不进行 Git push：
python3 "/home/lx/下载/microduck-stage12-cloud-full-path-v1-20261018.py" --launch

目标 SSH：ssh -p 36138 root@connect.bjb2.seetacloud.com
用户已报告克隆实例并开机；未进行平台电源复查，脚本不操作云电源。
助手环境不能解析此云主机地址，因此尚未验证 SSH 登录或克隆实例的实际环境；
以上命令将从用户本机连接，使用既有 SSH 密钥或终端密码提示，不保存密码。
源文件及运行证据通过 Git SSH；不通过 SCP 传输大文件，不使用 PAT/网页登录。
下载、Git 上传、SSH 控制和结果取回需要联网；云端仿真本身不需要持续联网。
出现 CLOUD_BACKGROUND_STARTED 后程序已脱离 SSH 会话；断网、关闭终端不停止仿真。
--launch 再次执行只显示既有槽位状态，不重启、续期或创建第二个 native owner。

二、查看、停止、回传
随时只读查询（显示 macro/250、public step/25、积分预算和实际状态）：
python3 "/home/lx/下载/microduck-stage12-cloud-full-path-v1-20261018.py" --status

如确需主动停止，在另一终端执行；当前 macro 完成后停止并保留部分结果：
python3 "/home/lx/下载/microduck-stage12-cloud-full-path-v1-20261018.py" --stop
这不是暂停/可恢复检查点。停止后的原槽位不能重新开始。
停止请求仍需等待当前 macro 收尾；避免 kill/kill -9 强杀计算进程。

仅收集已退出批次并准备分卷（不重新仿真）：
python3 "/home/lx/下载/microduck-stage12-cloud-full-path-v1-20261018.py" --collect

结束且 return_prepared=true 后，用户明确执行 Git SSH 回传并取回本机、校验 SHA256：
python3 "/home/lx/下载/microduck-stage12-cloud-full-path-v1-20261018.py" --push-return
它先手动推送每个证据分卷，再推送总索引，随后固定提交取回全部文件。
看到 CLOUD_RETURN_LOCAL_VERIFIED 后回复“已推送”，助手直接从 Git 独立复核。
如果只有本机下载失败，以下命令只重取文件，不重跑实验、不重新推送：
python3 "/home/lx/下载/microduck-stage12-cloud-full-path-v1-20261018.py" --fetch-return

可选：只校验下载包 --verify-only；只部署并检查环境但不运行 --preflight。
没有任何默认自动 push、PR、merge、force push 或云电源命令。

三、本次范围与预算
单独新建 RTX5090 N1 owner；零动作连续 24 public step，随后显式 reset、empty reset
及 1 post-reset step；共 25 public step、250 macro、0.5 秒累计仿真时间。
使用原 tiers 32/64/128/256/512，首次通过档必须进行精确回放。
每个 macro 的原状态、接触积分、事件判据和几何参数均不放宽。
最多 376000 次积分、1506254 次 GPU forward；最多 28 reset、1 world。
GPU 上仍先运行本机已经通过的 98 个相同几何样本，以检查迁移到 5090 的执行；
不重跑旧静态/IVP/pilot 批次，不使用其旧 started 标记或截止。
新的 native 上限 85500 秒，含清理总上限 86400 秒；预留 900 秒清理。
24 小时是停止上限，不是预计耗时，也不是 24 小时 PPO 预算。
开始需 32 GiB 可用空间，运行中保留 8 GiB；每个回传压缩卷不超过 49 MiB。
原截止 2026-10-17T11:23:14+08:00 / 11:53:14+08:00 及各旧窗口不变、不续期。
仍待后续：完整 N2 rollout、500 步回合、必要生命周期/吞吐结论与最终归档，
之后另定云 PPO 预算和检查点端到端验收。本包不会顺带启动这些额外批次。

四、已完成的本机部分回传核验
总索引分支 stage12-full-path-v2-return-20261018t072825z-e7e2161b8b
总索引 commit 81217fe7bdecbf2683b7706d00668b0db881c403
证据索引 SHA256 e7e2161b8be4ee5e1056f2fd1d763f860455e2b9606be5fdbaa185f30a9e9ee0
6 个分卷，1443 个执行包/证据文件，204584743 字节，逐文件完整校验。
98 GPU 几何样本通过；19 个 committed macro 独立重算原判据和精确回放通过。
其中已提交轨迹积分 3232 次、forward 13005 次；另外 3 次外部 forward。
public step 完整返回 1 次，第 2 次 public step 的第 10 个 macro 中断。
总 WAL 747669 行：积分 attempted=3249；completed 属于 [3248,3249]；
integrations、RK4_integrator、GPU_forward 各有一个未闭合调用，不伪造完成。
几何流可读 13074 条完整 JSON，gzip 尾部没有完成；旧字节原样保存。
旧 batch 状态 FULL_PATH_STOPPED_PRESERVE；没有最终 native-report/完整清理回执，
不宣称正常清理或整批通过；原 native 验收仍为 2/5。
累计历史积分区间：attempted=[738602,738602]；completed=[738600,738601]。
新的云端聚合保持这个不确定区间，不把上界或下界擅自改成精确值。
旧批次没有完整的可序列化 opaque owner 检查点，不能把 saved 数字数组移入
5090 后宣称原进程接续；本包从新的环境开始，旧部分结果不计成云端进度。
已完成的 dynamic-ivp-v2、静态与 n1/n2 pilot 不重跑。

五、环境与固定目录
本机源码 /home/lx/microduck-double-balance/workspace，分支 double-balance。
本机客户端记录：
/home/lx/microduck-double-balance/artifacts/double-balance-stage12/cloud-full-path-v1/client-20261018-v1
云端本批根目录：
/root/autodl-tmp/microduck-double-balance/artifacts/double-balance-stage12/cloud-full-path-v1
运行子目录 cloud-20261018-v1；控制子目录 control-cloud-20261018-v1；
回传子目录 transfer-cloud-20261018-v1；输入 Git 独立目录 input-git。
云端首选原已恢复 Python：
/root/md12-runtime-20261016t050751z-900769/venv/bin/python
兼容查找旧 cloud-execution-v1 工作目录的 .venv 与云项目 .venv；逐个检查固定
219 个源文件及锁定版本，只有完全通过才选用；不联网安装、升级或重建环境。
固定版本 Torch 2.9.1、MuJoCo 3.10.0、mujoco-warp 3.8.1、Warp 1.12.0、
mjlab 1.3.0、BAM 1.0.1。包内 951 个冻结输入未改。
原接触/位姿 CUDA 内核、积分器及阈值字节保持不变；继承实际 CPU 编译、
compute_120 PTX 编译以及本机 GPU 样本证据，不能写成新的 5090 已验证。

六、失败、恢复与电源
输入推送失败：重复 --push-inputs，仅传输固定输入，不启动仿真。
克隆环境丢失或 source pin 不符：停止并保留 runtime-check 日志，不自动重装。
SSH 主机密钥变化：核对平台实例身份，不关闭主机校验、不清空 known_hosts。
Git 权限失败：复用既有 Git SSH 配置；云端可复用已存在的 Stage09 专用密钥，
不创建、复制或上传私钥，不把云密码写入命令。non-fast-forward 时保留两边，不 force。
已有 DAEMON-INTENT/started 时不再启动 native；查询、停止和收集是不同操作。
云端 RETURN 已准备后再 --push-return；失败只重试传输，禁止重跑仿真修复传输。
本批计算、必要打包和本机回传 SHA256 核验完成后，会提醒手动关机并保留数据；
提醒不代表实例已关机。旧 Stage09 全 trace 未完整回传，不可删除实例/云盘。
本轮用户报告 ON；助手未操作电源；最终关机确认 UNCONFIRMED。

七、保留材料
history/full-path-v2-local/ 包含原计划、Git 总索引和独立部分复核报告。
更早失败、动态 v1/v2 和静态证据来源沿用包内 history/、origin/。
完整旧回传仍由固定 Git 提交及 6 分卷保存，本包只附索引/审查而非复制 200 MB。
长期规范全文保留于：
docs/handoffs/microduck-local-ssh-push-protocol.md
docs/handoffs/microduck-cloud-gpu-and-transfer-protocol.md
本交付是隔离验证候选，不覆盖源码分支，也不建立 Stage12 完成标签。
