"""Recover exact immutable inputs without reading or changing the old download package."""
import shutil
import stat
import zipfile
from pathlib import Path, PurePosixPath
from static_common import ROOT, read, require, sha


def tree_differences(root, files):
    root = Path(root)
    missing, changed, unsafe = [], [], []
    if root.is_symlink():
        return dict(missing=[], changed=[], extra=[], unsafe=['<input-root>'])
    for name, pin in files.items():
        path = root / name
        if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):
            unsafe.append(name)
        elif not path.is_file():
            missing.append(name)
        elif path.stat().st_size != pin['bytes'] or sha(path) != pin['sha256']:
            changed.append(name)
    actual = set()
    if root.is_dir():
        for path in root.rglob('*'):
            name = path.relative_to(root).as_posix()
            if path.is_symlink():
                unsafe.append(name)
            if path.is_file():
                actual.add(name)
    return dict(missing=sorted(missing), changed=sorted(changed),
                extra=sorted(actual - set(files)), unsafe=sorted(set(unsafe)))


def exact(root, files):
    differences = tree_differences(root, files)
    require(not any(differences.values()), 'Frozen inputs differ: ' + repr(differences))


def checked_archive(bundle_root, manifest):
    archive = bundle_root / 'frozen-inputs.zip'
    require(archive.is_file() and not archive.is_symlink()
            and archive.stat().st_size == manifest['archive_bytes']
            and sha(archive) == manifest['archive_sha256'], 'Bundled frozen archive differs')
    z = zipfile.ZipFile(archive)
    try:
        members = z.infolist()
        names = [item.filename for item in members]
        require(len(names) == len(set(names)) and set(names) == set(manifest['files']),
                'Bundled frozen archive roster differs')
        require(sum(item.file_size for item in members) <= 128 * 1024**2, 'Frozen archive size exceeds cap')
        for item in members:
            path = PurePosixPath(item.filename)
            require(not item.is_dir() and not path.is_absolute() and '..' not in path.parts
                    and path.parts[0] in ('candidate', 'project')
                    and not stat.S_ISLNK(item.external_attr >> 16)
                    and item.file_size == manifest['files'][item.filename]['bytes'], 'Unsafe frozen archive member')
        return z
    except BaseException:
        z.close()
        raise


def materialize(previous_inputs, destination, *, bundle_root=ROOT):
    previous_inputs, destination = Path(previous_inputs), Path(destination)
    manifest = read(bundle_root / 'frozen-inputs-manifest.json')
    require(manifest['frozen_candidate_files'] == 586 and manifest['frozen_project_files'] == 365
            and len(manifest['files']) == 951, 'Frozen input manifest roster differs')
    require(not destination.exists(), 'Input destination must be new')
    differences = tree_differences(previous_inputs, manifest['files'])
    if not any(differences.values()):
        shutil.copytree(previous_inputs, destination, symlinks=True)
        source = 'VERIFIED_PREVIOUS_RUN_INPUTS'
    else:
        with checked_archive(bundle_root, manifest) as z:
            destination.mkdir()
            for item in z.infolist():
                dest = destination / item.filename
                dest.parent.mkdir(parents=True, exist_ok=True)
                with z.open(item) as src, dest.open('xb') as dst:
                    shutil.copyfileobj(src, dst)
        source = 'PINNED_BUNDLED_INPUTS'
    exact(destination, manifest['files'])
    return dict(status='FROZEN_INPUTS_VERIFIED', source=source, files=951,
                candidate_files=586, project_files=365,
                previous_input_differences=differences,
                old_files_modified=0, old_download_package_required=False)
