"""New cloud 86400s window. Historical deadlines and attempted counts are immutable."""
import argparse
import datetime
import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from static_common import ROOT,SCOPE,load_run,read,require,write,sha

def admission(plan,scope,new_window,now):
    require(scope==SCOPE and new_window is True,'Explicit new full-path scope/window required')
    require(plan['new_native_window_seconds']==85500 and plan['new_total_window_seconds']==86400,'Declared window differs')
    return dict(started_utc=now,native_stop_utc=now+85500,stop_utc=now+86400,
        original_deadlines=plan['original_deadlines'],deadline_reset=False,
        separately_authorized=True,new_native_seconds=85500,new_total_seconds=86400,
        cleanup_reserve_seconds=900,old_campaign_resume=False,old_windows_reused=False)

def process_identity(pid):
    try:
        raw=Path('/proc/%d/stat'%pid).read_text();fields=raw[raw.rfind(')')+2:].split()
        return dict(pid=pid,start_ticks=fields[19],boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip())
    except (OSError,IndexError):return None

def child_is_gone(child):
    """Unreadable process metadata is not evidence that a child has stopped."""
    try:os.kill(child['pid'],0)
    except ProcessLookupError:return True
    except PermissionError:return False
    live=process_identity(child['pid'])
    return live is not None and child.get('identity') is not None and live!=child['identity']

def stop_child(proc):
    if proc is not None and proc.poll() is None:
        os.killpg(proc.pid,signal.SIGTERM)
        try:proc.wait(timeout=10)
        except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()

def process_group_gone(pgid):
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():continue
        try:
            raw=(entry/'stat').read_text();fields=raw[raw.rfind(')')+2:].split()
            if int(fields[2])==pgid and fields[0]!='Z':return False
        except (FileNotFoundError,ProcessLookupError):continue
        except (PermissionError,IndexError,ValueError):return False
    return True

def collect(run,plan,started,*,returncode=None,forced=False,error=None):
    require(not (run/'evidence-index.json').exists(),'Already finalized; preserve existing index')
    if (run/'child.json').is_file():
        child=read(run/'child.json')
        require(child_is_gone(child) and process_group_gone(child['pid']),
                'Child still alive or identity uncertain; do not collect or rerun')
    elif (run/'child-launch.json').exists() and not (run/'child-launch-failed.json').exists():
        closed=read(run/'native/owner-0-bootstrap/bootstrap-report.json') if (run/'native/owner-0-bootstrap/bootstrap-report.json').is_file() else {}
        require(closed.get('status') in ('GUARDED_BOOTSTRAP_CLOSED','BOOTSTRAP_OR_SESSION_STOPPED_PRESERVE'),
                'Child launch interrupted before PID receipt; preserve and establish process exit before collection')
    campaign=read(run/'full-path-report.json') if (run/'full-path-report.json').is_file() else {}
    native=read(run/'native/owner-0/native-report.json') if (run/'native/owner-0/native-report.json').is_file() else {}
    bootstrap=read(run/'native/owner-0-bootstrap/bootstrap-report.json') if (run/'native/owner-0-bootstrap/bootstrap-report.json').is_file() else {}
    progress=read(run/'native/owner-0/progress.json') if (run/'native/owner-0/progress.json').is_file() else {}
    # Always recompute the final WAL, including after a killed child. No inferred
    # completion from stale progress, and no erasure of an in-flight attempt.
    sys.path.insert(0,str(run/'inputs/candidate/baseline/g11'))
    from runtime_accounting import review_ledger
    ledger=review_ledger(run/'native/owner-0/native-ledger.jsonl') if (run/'native/owner-0/native-ledger.jsonl').is_file() else None
    complete=(returncode==0 and not forced and error is None and campaign.get('status')=='FULL_PATH_COMPLETE_REVIEW_REQUIRED' and native.get('status')=='STAGE12_NATIVE_CANDIDATE_FINISHED_REVIEW_REQUIRED'
              and native.get('native_ledger')==ledger and ledger is not None and ledger['exact']
              and bootstrap.get('status')=='GUARDED_BOOTSTRAP_CLOSED' and not bootstrap.get('cleanup_errors'))
    before=plan['canonical_integrations_before']
    aggregate=None if ledger is None else dict(
        attempted_lower=before['attempted_lower']+ledger['integration_attempted_lower'],
        attempted_upper=before['attempted_upper']+ledger['integration_attempted_upper'],
        completed_lower=before['completed_lower']+ledger['integration_completed_lower'],
        completed_upper=before['completed_upper']+ledger['integration_completed_upper'])
    result=dict(status='FULL_PATH_COMPLETE_REVIEW_REQUIRED' if complete else 'FULL_PATH_STOPPED_PRESERVE',
        returncode=returncode,forced_timeout=forced,error=error,counts=native.get('counts',progress.get('counts',{})),
        counts_final='counts' in native,ledger=ledger,canonical_before=before,canonical_after_interval=aggregate,
        original_deadlines=plan['original_deadlines'],new_window=started,original_deadline_reset=False,
        full_path_result=campaign,full_path_independent_review_pending=True,
        full_dynamic_rollout_validated=False,native_points_accepted=2,native_points_total=5,
        training_ready=False,PPO=0,cloud_training=0,automatic_push=False,automatic_PR=False,automatic_merge=False,
        automatic_power_actions=0,no_automatic_retry=True,old_campaign_resume=False)
    if (run/'result.json').exists():
        result=read(run/'result.json')  # Recovery finishes indexing the same immutable outcome.
    else:write(run/'result.json',result,exclusive=True)
    files={p.relative_to(run).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p)) for p in run.rglob('*')
           if p.is_file() and not p.is_relative_to(run/'inputs') and p.name!='evidence-index.json'}
    write(run/'evidence-index.json',dict(files=files,source_return_commit=plan['source_return_commit'],
        latest_verified_commit=plan['latest_verified_commit'],status=result['status']),exclusive=True)
    print(result['status']+' | 原验收仍 2/5 | PPO=0 | cloud_training=0',flush=True)
    if not complete and (run/'console.log').is_file():
        print('\n'.join((run/'console.log').read_text(errors='replace').splitlines()[-35:]),flush=True)
    return result

def launch(run_dir,scope,new_window):
    plan=read(ROOT/'plan.json');admission(plan,scope,new_window,time.time())
    run,receipt,plan=load_run(run_dir)
    from preflight_runtime import verify
    runtime=verify(run/'inputs/candidate',run/'inputs/project')
    from prepare import refuse_started
    refuse_started(run)
    window=admission(plan,scope,new_window,time.time())
    started=dict(window,explicit_cli_scope=scope,plan_sha256=receipt['plan_sha256'],parent_pid=os.getpid(),
                 runtime_preflight=runtime,PPO=0,cloud_training=0)
    write(run/'started.json',started,exclusive=True)
    proc=None;forced=False;error=None;began=time.monotonic();last_print=-10
    try:
        with (run/'console.log').open('xb',buffering=0) as log:
            write(run/'child-launch.json',dict(intent_utc=time.time(),native_retry=False),exclusive=True)
            try:
                proc=subprocess.Popen([sys.executable,'-B',str(ROOT/'full_worker.py'),'--run-dir',str(run)],
                    stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,
                    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
            except OSError as exc:
                write(run/'child-launch-failed.json',dict(error=repr(exc),child_created=False),exclusive=True)
                raise
            write(run/'child.json',dict(pid=proc.pid,identity=process_identity(proc.pid)),exclusive=True)
            print('新完整路径：24步连续rollout + reset后1步；250个macro；最多376000积分；新总窗口24小时，停止native后预留15分钟清理。',flush=True)
            while proc.poll() is None:
                elapsed=time.monotonic()-began
                if time.time()>=window['stop_utc'] or elapsed>=86400:
                    forced=True;stop_child(proc);break
                if elapsed-last_print>=10:
                    p=read(run/'native/owner-0/progress.json') if (run/'native/owner-0/progress.json').is_file() else {}
                    done=p.get('macro_completed',0)
                    print('%s | 新macro %d/250 (%.2f%%) | 积分预算已用 %d/376000 | %.0fs/86400s | 原验收2/5'%
                        (p.get('phase','startup'),done,100*done/250,p.get('integration_budget_used',0),elapsed),flush=True)
                    last_print=elapsed
                time.sleep(1)
    except BaseException as exc:
        error=repr(exc);stop_child(proc)
    if proc is not None and proc.poll() is not None:
        drain_until=time.monotonic()+10
        while not process_group_gone(proc.pid) and time.monotonic()<drain_until:time.sleep(.05)
    result=collect(run,plan,started,returncode=None if proc is None else proc.returncode,forced=forced,error=error)
    return 0 if result['status']=='FULL_PATH_COMPLETE_REVIEW_REQUIRED' else 2

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run-dir',type=Path,required=True)
    p.add_argument('--authorize-scope',choices=[SCOPE],required=True)
    p.add_argument('--authorize-new-cloud-window-86400s',action='store_true',required=True)
    a=p.parse_args();sys.exit(launch(a.run_dir,a.authorize_scope,a.authorize_new_cloud_window_86400s))
