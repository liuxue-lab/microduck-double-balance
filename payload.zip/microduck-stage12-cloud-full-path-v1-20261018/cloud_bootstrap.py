"""Small stdin bootstrap. Large package bytes use the existing Git SSH route."""
import base64
import fcntl
import hashlib
import json
import os
from pathlib import Path,PurePosixPath
import re
import shlex
import subprocess
import sys
import tempfile
import zipfile

BASE=Path('/root/autodl-tmp/microduck-double-balance/artifacts/double-balance-stage12/cloud-full-path-v1')
REMOTE='git@github.com:liuxue-lab/microduck-double-balance.git'

def require(ok,message):
    if not ok:raise RuntimeError(message)
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024**2),b''):h.update(b)
    return h.hexdigest()
def write(path,row):
    raw=(json.dumps(row,sort_keys=True,indent=2)+'\n').encode()
    if path.exists():require(path.read_bytes()==raw,'Existing deployment identity differs');return
    with path.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
def git(repo,*args,capture=False):
    cmd=['git','-C',str(repo),'-c','core.hooksPath=/dev/null',*args]
    if capture:return subprocess.check_output(cmd,text=True).strip()
    subprocess.run(cmd,check=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0'))

def verify(root,expected_manifest):
    require(root.is_dir() and root.resolve()==root and sha(root/'MANIFEST.json')==expected_manifest,'Package manifest differs')
    pins=json.loads((root/'MANIFEST.json').read_bytes())['files']
    # Historical manifests are themselves pinned package members.
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and p!=root/'MANIFEST.json'}
    require(actual==set(pins),'Package member roster differs')
    for name,pin in pins.items():
        f=root/name
        require(f.resolve().is_relative_to(root) and not f.is_symlink() and f.stat().st_size==pin['bytes'] and sha(f)==pin['sha256'],'Package member differs: '+name)

def unpack(archive,package,manifest):
    destination=BASE/package
    if destination.exists():verify(destination,manifest);return destination
    tmp=Path(tempfile.mkdtemp(prefix=package+'.extracting-',dir=BASE))
    with zipfile.ZipFile(archive) as z:
        names=z.namelist()
        require(len(names)==len(set(names))<1000 and sum(i.file_size for i in z.infolist())<300*1024**2,'Unexpected ZIP roster or size')
        for info in z.infolist():
            p=PurePosixPath(info.filename)
            require(p.as_posix()==info.filename and not p.is_absolute() and '..' not in p.parts and len(p.parts)>1 and p.parts[0]==package
                and not info.is_dir() and '\\' not in info.filename and (info.external_attr>>16)&0o170000!=0o120000,'Unsafe ZIP member')
            f=tmp.joinpath(*p.parts);f.parent.mkdir(parents=True,exist_ok=True)
            with f.open('xb') as stream:stream.write(z.read(info))
    verify(tmp/package,manifest);(tmp/package).rename(destination);tmp.rmdir();return destination

def ssh_command():
    canonical=Path('/root/autodl-tmp/microduck-double-balance')
    r=subprocess.run(['git','-C',str(canonical),'config','--get','core.sshCommand'],capture_output=True,text=True)
    if r.returncode==0 and r.stdout.strip():return r.stdout.strip()
    known=Path('/root/.ssh/id_ed25519_microduck_stage09')
    if known.is_file():return 'ssh -o BatchMode=yes -o ConnectTimeout=20 -i '+shlex.quote(str(known))+' -o IdentitiesOnly=yes'
    return 'ssh -o BatchMode=yes -o ConnectTimeout=20'

def execute(mode,desc):
    require(mode in ('preflight','launch','status','collect','stop','push-return','return-info'),'Unknown cloud action')
    require(re.fullmatch(r'[0-9a-f]{40}',desc['input_commit']) and re.fullmatch(r'[0-9a-f]{64}',desc['zip_sha256'])
        and re.fullmatch(r'[0-9a-f]{64}',desc['package_manifest_sha256']),'Malformed input pins')
    require(desc['package']=='microduck-stage12-cloud-full-path-v1-20261018' and desc['branch'].startswith('stage12-cloud-full-path-v1-input-'),'Input scope differs')
    BASE.mkdir(parents=True,exist_ok=True)
    for p in [BASE,*BASE.parents]:require(not p.is_symlink(),'Symlink deployment path refused')
    with (BASE/'deployment.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        root=BASE/desc['package'];repo=BASE/'input-git'
        if not root.exists():
            require(mode in ('launch','preflight'),'Cloud package has not been deployed yet')
            repo.mkdir(exist_ok=True)
            if not (repo/'.git').exists():git(repo,'init')
            git(repo,'config','core.sshCommand',ssh_command())
            remotes=git(repo,'remote',capture=True).splitlines()
            if 'origin' in remotes:require(git(repo,'remote','get-url','origin',capture=True)==REMOTE,'Input remote differs')
            else:git(repo,'remote','add','origin',REMOTE)
            git(repo,'fetch','--depth=1','origin',desc['branch'])
            require(git(repo,'rev-parse','FETCH_HEAD',capture=True)==desc['input_commit'],'Remote input branch no longer matches the published commit; preserve and stop')
            git(repo,'checkout','--detach',desc['input_commit'])
            for key in ('user.name','user.email'):git(repo,'config',key,desc['identity'][key])
            archive=repo/'payload.zip'
            require(archive.stat().st_size==desc['zip_bytes']<=49*1024**2 and sha(archive)==desc['zip_sha256'],'Git input archive SHA/size differs')
            root=unpack(archive,desc['package'],desc['package_manifest_sha256'])
        else:verify(root,desc['package_manifest_sha256'])
        write(BASE/'DEPLOYMENT.json',dict(input_repository=str(repo),input_commit=desc['input_commit'],
            package_manifest_sha256=desc['package_manifest_sha256'],zip_sha256=desc['zip_sha256'],branch=desc['branch']))
    control=BASE/'control-cloud-20261018-v1'
    python=sys.executable
    if (control/'READY.json').is_file():
        ready=json.loads((control/'READY.json').read_bytes());python=ready['python']
        require(Path(python).is_file(),'Selected cloned runtime missing; do not rebuild it automatically')
    return subprocess.run([python,'-u','-B',str(root/'cloud_remote.py'),'--mode',mode],env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')).returncode

if __name__=='__main__':
    try:
        mode=sys.argv[1];desc=json.loads(base64.b64decode(sys.argv[2],validate=True));sys.exit(execute(mode,desc))
    except (OSError,RuntimeError,ValueError,subprocess.SubprocessError) as exc:
        print('CLOUD_DEPLOYMENT_STOPPED_PRESERVE: '+str(exc),file=sys.stderr);sys.exit(2)
