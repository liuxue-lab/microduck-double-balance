"""NumPy oracle over every face of the exactly certified convex hull."""
import numpy as np


def closest(point, vertices, facets):
    p=np.asarray(point,np.float64)
    a,b,c=np.moveaxis(np.asarray(vertices,np.float64)[facets]-p,1,0)
    ab,ac=b-a,c-a
    n=np.cross(ab,ac);den=np.einsum('ij,ij->i',n,n)
    if not np.all(den>0):raise RuntimeError('Degenerate hull face')
    u=np.einsum('ij,ij->i',np.cross(-a,ac),n)/den
    w=np.einsum('ij,ij->i',np.cross(ab,-a),n)/den
    projected=a+u[:,None]*ab+w[:,None]*ac
    face=(u>=0)&(w>=0)&(u+w<=1)
    candidates=[projected];d2=[np.where(face,np.einsum('ij,ij->i',projected,projected),np.inf)]
    bary=[np.stack((u,w),axis=1)];features=[np.full(len(facets),2)]
    for index,(start,end) in enumerate(((a,b),(b,c),(c,a))):
        edge=end-start;length2=np.einsum('ij,ij->i',edge,edge)
        if not np.all(length2>0):raise RuntimeError('Degenerate hull edge')
        t=np.clip(-np.einsum('ij,ij->i',start,edge)/length2,0,1)
        q=start+t[:,None]*edge
        candidates.append(q);d2.append(np.einsum('ij,ij->i',q,q))
        bary.append((np.stack((t,np.zeros_like(t)),axis=1),
                     np.stack((1-t,t),axis=1),
                     np.stack((np.zeros_like(t),1-t),axis=1))[index])
        features.append(np.where((t==0)|(t==1),0,1))
    distances=np.stack(d2,axis=1);i,j=np.unravel_index(distances.argmin(),distances.shape)
    q=candidates[j][i];length=float(np.sqrt(distances[i,j]));inside=bool(np.all(np.einsum('ij,ij->i',n,-a)<=0))
    if length==0:raise RuntimeError('Sphere center exactly on hull: normal not uniquely released')
    sign=-1 if inside else 1
    return dict(point=q+p,relative=q,distance=sign*length,normal=sign*q/length,
                facet=int(i),feature=int(features[j][i]),barycentric=bary[j][i],inside=inside)


def geometry(vertices,facets,positions,rotations,radius):
    v=vertices.astype(np.float64)@rotations[1].T+(positions[1]-positions[0])
    j=int(np.argmin(np.einsum('ij,ij->i',v,v)))
    dot=float(np.min((v-v[j])@v[j]));length=float(np.linalg.norm(v[j]))
    if dot>=0 and length>0:
        q=v[j];normal=q/length
        values=np.r_[j,dot,length,length-radius,normal,
                     positions[0]+(normal*radius+q)*.5,1.,-1.,0.,0.,0.,0.]
    else:
        r=closest(np.zeros(3),v,facets);q=r['relative'];normal=r['normal']
        values=np.r_[-1.,float(np.min((v-q)@q)),abs(r['distance']),r['distance']-radius,
                     normal,positions[0]+(normal*radius+q)*.5,
                     1.,r['facet'],r['feature'],float(r['inside']),r['barycentric']]
    if values.shape!=(16,) or not np.isfinite(values).all():raise RuntimeError('Invalid convex geometry')
    return values
