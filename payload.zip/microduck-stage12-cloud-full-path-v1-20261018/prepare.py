"""Immutable preparation only; no installed dependency imports or native calls."""
import datetime
import tempfile
from pathlib import Path
from static_common import ROOT, plain, read, require, sha, verify_package, write, load_run
from frozen_inputs import materialize
from operation_contract import validate_caps

MARKERS=('started.json','child-launch.json','child-launch-failed.json','child.json','native','native-bootstrap','result.json','evidence-index.json')
def refuse_started(output):
    for name in MARKERS:
        require(not (output/name).exists() and not (output/name).is_symlink(),'Existing execution is preserved; no native retry: '+str(output/name))

def prepare(output):
    output=plain(output);identity=verify_package();plan=read(ROOT/'plan.json')
    require(str(output)==plan['run_directory'],'Only the declared new slot is allowed')
    refuse_started(output)
    if output.exists():
        _,receipt,_=load_run(output)
        return dict(status=receipt['status'],prepared_only_reused=True,run_directory=str(output),native_calls=0)
    output.parent.mkdir(parents=True,exist_ok=True)
    staging=Path(tempfile.mkdtemp(prefix=output.name+'.preparing-',dir=output.parent))
    try:
        selection=materialize(Path(plan['previous_run_directory'])/'inputs',staging/'inputs')
        closure=validate_caps(staging/'inputs/candidate',plan)
        receipt=dict(status='FULL_PATH_PREPARED_NOT_RUN',run_directory=str(output),
            prepared_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),package_sha256=identity,
            plan_sha256=sha(ROOT/'plan.json'),frozen_inputs=selection,callable_contract=closure,
            latest_verified_commit=plan['latest_verified_commit'],native_calls=0,PPO=0,cloud_training=0)
        write(staging/'prepared.json',receipt,exclusive=True)
        require(not output.exists(),'Another preparation exists; preserve both')
        staging.rename(output)
    except BaseException as exc:
        write(staging/'preparation-failure.json',dict(error=repr(exc),native_calls=0,target=str(output)))
        raise
    return dict(status=receipt['status'],run_directory=str(output),input_source=selection['source'],native_calls=0)
