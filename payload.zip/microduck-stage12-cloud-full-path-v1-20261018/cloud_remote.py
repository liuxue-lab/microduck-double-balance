"""User-invoked cloud preparation, one detached run, read-only status and collection."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback
from static_common import ROOT,SCOPE,read,write,require,sha,verify_package,load_run
from prepare import prepare
from run_full import child_is_gone,process_identity,process_group_gone

PLAN=read(ROOT/'plan.json')
RUN=Path(PLAN['run_directory'])
BASE=RUN.parent
CONTROL=BASE/'control-cloud-20261018-v1'
TRANSFER=BASE/'transfer-cloud-20261018-v1'

def identity_environment():
    receipt=read(ROOT.parent/'DEPLOYMENT.json')
    require(receipt['package_manifest_sha256']==sha(ROOT/'MANIFEST.json'),'Deployment/package differs')
    repo=Path(receipt['input_repository'])
    require(repo.is_dir() and subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==receipt['input_commit'],'Pinned input Git HEAD differs')
    return repo

def preflight():
    verify_package();canonical=identity_environment()
    require(not (RUN/'started.json').exists(),'Batch already started; use status or collect, never relaunch')
    require(shutil.disk_usage(BASE).free>=PLAN['required_start_free_bytes'],'Need 32 GiB free before new cloud scope')
    print(json.dumps(prepare(RUN),ensure_ascii=False),flush=True)
    checks=[];selected=None
    code="import sys,json;from pathlib import Path;sys.path.insert(0,sys.argv[1]);from preflight_runtime import verify;print(json.dumps(verify(Path(sys.argv[2]),Path(sys.argv[3]))))"
    for name in PLAN['deployment']['runtime_candidates']:
        exe=Path(name)
        if not exe.is_file():
            checks.append(dict(python=name,status='missing'));continue
        result=subprocess.run([name,'-B','-c',code,str(ROOT),str(RUN/'inputs/candidate'),str(RUN/'inputs/project')],
            capture_output=True,text=True,timeout=180,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
        checks.append(dict(python=name,returncode=result.returncode,stdout=result.stdout[-6000:],stderr=result.stderr[-6000:]))
        if result.returncode==0:selected=name;break
    report=dict(checks=checks,selected_python=selected,imports_native=False,integrations=0,PPO=0,cloud_training=0)
    stamp=str(time.time_ns());write(CONTROL/('runtime-check-'+stamp+'.json'),report,exclusive=True)
    require(selected is not None,'No cloned runtime passed 219 fixed source pins; nothing installed or upgraded. Inspect runtime-check report.')
    gpu=subprocess.run(['nvidia-smi','--query-gpu=name,uuid,memory.total,driver_version','--format=csv,noheader'],capture_output=True,text=True,timeout=30)
    write(CONTROL/('gpu-check-'+stamp+'.json'),dict(returncode=gpu.returncode,stdout=gpu.stdout,stderr=gpu.stderr),exclusive=True)
    require(gpu.returncode==0 and len(gpu.stdout.strip().splitlines())==1 and '5090' in gpu.stdout,'Exactly one RTX5090 must be visible')
    receipt=dict(python=selected,canonical=str(canonical),package_sha256=sha(ROOT/'MANIFEST.json'),run_directory=str(RUN),
        runtime_check='runtime-check-'+stamp+'.json',gpu_check='gpu-check-'+stamp+'.json',native_started=False)
    write(CONTROL/'READY.json',receipt)
    print('CLOUD_PREFLIGHT_PASS | existing runtime reused | 219 pinned sources | RTX5090 | PPO=0',flush=True)
    return receipt

def daemon_active():
    f=CONTROL/'DAEMON.json'
    if not f.is_file():return False
    row=read(f)
    try:
        raw=Path('/proc/%d/stat'%row['pid']).read_text()
        if raw[raw.rfind(')')+2:].split()[0]=='Z':return False
    except FileNotFoundError:return False
    except (PermissionError,IndexError):return True
    return not child_is_gone(row)

def status():
    result=read(RUN/'result.json') if (RUN/'result.json').is_file() else None
    p=read(RUN/'native/owner-0/progress.json') if (RUN/'native/owner-0/progress.json').is_file() else {}
    row=dict(status=result['status'] if result else ('RUNNING' if daemon_active() else 'NOT_RUNNING'),
        completed_macros=p.get('macro_completed',0),total_macros=250,
        completed_public_steps=p.get('public_steps_completed',0),total_public_steps=25,
        integration_attempts=p.get('integration_budget_used',0),phase=p.get('phase','not-started'),
        elapsed_seconds=p.get('elapsed_s'),PPO=0,cloud_training=0,
        return_prepared=(TRANSFER/'LOCAL-RETURN.json').is_file(),daemon_exit=read(CONTROL/'EXIT.json') if (CONTROL/'EXIT.json').is_file() else None,
        launcher_log=str(CONTROL/'launcher.log'),native_log=str(RUN/'console.log'),
        stop_requested=(RUN/'STOP_REQUEST.json').is_file(),original_native_acceptance='2/5')
    print(json.dumps(row,ensure_ascii=False,indent=2),flush=True)
    if result and not row['return_prepared']:print('Native finished; use --collect to prepare existing evidence. No new simulation.',flush=True)
    return row

def launch():
    if (CONTROL/'DAEMON-INTENT.json').exists() or (RUN/'started.json').exists():
        print('EXISTING_SLOT_PRESERVED_NO_RELAUNCH',flush=True);status();return
    ready=preflight()
    token=sha(ROOT/'MANIFEST.json')+':'+str(time.time_ns())
    write(CONTROL/'DAEMON-INTENT.json',dict(token=token,utc=time.time(),no_retry=True),exclusive=True)
    try:
        with (CONTROL/'launcher.log').open('xb',buffering=0) as log:
            proc=subprocess.Popen([ready['python'],'-u','-B',str(ROOT/'cloud_remote.py'),'--mode','daemon','--token',token],
                stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,
                env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
        write(CONTROL/'DAEMON.json',dict(pid=proc.pid,identity=process_identity(proc.pid)),exclusive=True)
    except BaseException as exc:
        write(CONTROL/'DAEMON-LAUNCH-ERROR.json',dict(error=repr(exc),no_automatic_retry=True),exclusive=True);raise
    print('CLOUD_BACKGROUND_STARTED | pid=%d | disconnecting SSH will not stop it | PPO=0'%proc.pid,flush=True)
    # Only observe admission; this never waits for the long native run.
    end=time.monotonic()+20
    while time.monotonic()<end:
        if (RUN/'started.json').exists() or (CONTROL/'EXIT.json').exists():break
        time.sleep(.25)
    status()

def prepare_transfer():
    require(not daemon_active(),'Background runner still active; use status, do not collect live evidence')
    require((RUN/'started.json').exists(),'No native batch has started; preserve preparation logs')
    if not (RUN/'evidence-index.json').exists():
        load_run(RUN)
        from run_full import collect
        collect(RUN,PLAN,read(RUN/'started.json'),error='User collection of stopped cloud parent; no native restart')
    from prepare_git_return import prepare as transfer
    return transfer(RUN,TRANSFER,identity_environment())

def daemon(token):
    intent=read(CONTROL/'DAEMON-INTENT.json');ready=read(CONTROL/'READY.json')
    require(token==intent['token'] and ready['package_sha256']==sha(ROOT/'MANIFEST.json'),'Detached runner identity differs')
    require(not (CONTROL/'DAEMON-ENTERED.json').exists(),'Detached runner is single-use')
    write(CONTROL/'DAEMON-ENTERED.json',dict(pid=os.getpid(),utc=time.time()),exclusive=True)
    error=None;code=2
    try:
        load_run(RUN)
        from run_full import launch as execute
        code=execute(RUN,SCOPE,True)
        if (RUN/'evidence-index.json').is_file():
            from prepare_git_return import prepare as transfer
            transfer(RUN,TRANSFER,identity_environment())
    except BaseException as exc:
        error=dict(error=repr(exc),traceback=traceback.format_exc());traceback.print_exc()
    finally:
        write(CONTROL/'EXIT.json',dict(returncode=code,error=error,utc=time.time(),
            return_prepared=(TRANSFER/'LOCAL-RETURN.json').is_file(),PPO=0,cloud_training=0),exclusive=True)
        print('CLOUD_BACKGROUND_FINISHED | no automatic Git push or power action',flush=True)
    return code

def stop():
    require((RUN/'started.json').exists() and not (RUN/'evidence-index.json').exists(),'No active unfinished native batch')
    if not (RUN/'STOP_REQUEST.json').exists():
        write(RUN/'STOP_REQUEST.json',dict(request='USER_STOP_AT_NEXT_MACRO_BOUNDARY',utc=time.time(),no_resume=True),exclusive=True)
    print('STOP_REQUESTED | finishes current macro, then preserves partial evidence; check --status',flush=True)

def main():
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['preflight','launch','status','collect','stop','push-return','return-info','daemon'],required=True);p.add_argument('--token')
    a=p.parse_args();verify_package();BASE.mkdir(parents=True,exist_ok=True);CONTROL.mkdir(exist_ok=True)
    if a.mode=='daemon':return daemon(a.token)
    if a.mode=='status':status();return 0
    if a.mode=='return-info':
        require((TRANSFER/'LOCAL-RETURN.json').is_file(),'Return not prepared yet')
        print('RETURN_INDEX_JSON='+json.dumps(read(TRANSFER/'LOCAL-RETURN.json'),sort_keys=True),flush=True);return 0
    with (CONTROL/'command.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if a.mode=='preflight':preflight()
        elif a.mode=='launch':launch()
        elif a.mode=='stop':stop()
        else:
            prepare_transfer()
            if a.mode=='push-return':
                code=subprocess.run([sys.executable,str(TRANSFER/'manual_push.py'),'--push']).returncode
                if code==0:print('RETURN_INDEX_JSON='+json.dumps(read(TRANSFER/'LOCAL-RETURN.json'),sort_keys=True),flush=True)
                return code
    return 0

if __name__=='__main__':
    try:sys.exit(main())
    except (OSError,RuntimeError,subprocess.SubprocessError) as exc:
        print('CLOUD_STOPPED_PRESERVE: '+str(exc),file=sys.stderr);sys.exit(2)
