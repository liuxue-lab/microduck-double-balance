"""Recompute geometry on 3973 archived poses; never simulate a new trajectory."""
import argparse
import hashlib
import json
import sys
from pathlib import Path
if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--candidate",type=Path,required=True);a=parser.parse_args()
    sys.path.insert(0,str(a.candidate.resolve()/"baseline/g11/accepted"))
import numpy as np
from static_common import ROOT,read,require
from kinematic_precision import fk,pose_input,Q

def matrix_reference(q,ref):
    # Independent rotation composition via Rodrigues matrices and homogeneous
    # transforms; norm factors retain the compiled float32 local quaternion data.
    def rotation(u):
        n2=float(u@u);w,x,y,z=u/np.sqrt(n2)
        cross=np.array([[0,-z,y],[z,0,-x],[-y,x,0]])
        return n2*(np.eye(3)+2*w*cross+2*cross@cross)
    r=rotation(q[3:7]/np.linalg.norm(q[3:7]));p=q[:3].copy()
    for k,adr in enumerate((12,13,14,15)):
        p=p+r@ref['body_pos'][k]
        r=r@rotation(ref['body_quat'][k])
        axis=ref['jnt_axis'][k];x,y,z=axis
        cross=np.array([[0,-z,y],[z,0,-x],[-y,x,0]])
        angle=q[adr];r=r@(np.eye(3)+np.sin(angle)*cross+(1-np.cos(angle))*cross@cross)
        r=r/np.cbrt(np.linalg.det(r))
    return np.array([q[28:31],p+r@ref['geom_pos'][1]]),np.array([
        rotation(q[31:35]/np.linalg.norm(q[31:35])),r@rotation(ref['geom_quat'][1])])

def certificate(p,r,vertices,radius):
    v=(vertices[:,0,None]*r[1,:,0]+vertices[:,1,None]*r[1,:,1]+vertices[:,2,None]*r[1,:,2])+(p[1]-p[0])
    d=np.einsum('ij,ij->i',v,v);j=int(d.argmin());vb=v[j]
    minimum=float(np.min((v-vb)@vb));length=float(np.sqrt(d[j]))
    require(minimum>=0 and length>0,'Convex-vertex certificate failed; no fallback')
    return dict(vertex=j,min_dot=minimum,gap=length-radius)

def analyze():
    provenance=read(ROOT/'source-reference/previous-poses-provenance.json')
    file=ROOT/'source-reference/previous-poses.npz'
    require(hashlib.sha256(file.read_bytes()).hexdigest()==provenance['fixture_sha256'],'Archived pose fixture differs')
    with np.load(file,allow_pickle=False) as z:data={k:z[k].copy() for k in z.files}
    with np.load(ROOT/'source-reference/kinematics-reference.npz',allow_pickle=False) as z:ref={k:z[k].astype(float) for k in z.files}
    radius=read(ROOT/'geometry-contract.json')['radius'];n=len(data['trial'])
    require(n==3973,'Archived pose roster differs')
    gaps=np.empty((n,3));gaps[:,0]=data['original_gap'];max_position=max_rotation=max_gap_delta=0.
    for i in range(n):
        stage=int(data['stage'][i]);stage=None if stage<0 else stage
        q,proof=pose_input(data['qpos'][i:i+1],data['accumulator'][i:i+1],float(data['dt'][i]),stage,
            data['previous_velocity'][i:i+1] if stage not in (None,0) else None)
        p,r=fk(q,ref);p2,r2=matrix_reference(q,ref)
        max_position=max(max_position,float(np.max(abs(p-p2))));max_rotation=max(max_rotation,float(np.max(abs(r-r2))))
        require(np.max(abs(p-p2))<1e-15 and np.max(abs(r-r2))<3e-15,'Independent FK reference differs')
        original=certificate(data['native_position'][i],data['native_rotation'][i],ref['vertices'],radius)
        require(abs(original['gap']-gaps[i,0])<1e-15,'Original GPU geometry differs from reference')
        gaps[i,1]=certificate(*fk(data['qpos'][i].astype(float),ref),ref['vertices'],radius)['gap']
        gaps[i,2]=certificate(p,r,ref['vertices'],radius)['gap']
        max_gap_delta=max(max_gap_delta,abs(gaps[i,2]-gaps[i,0]))
    rows=[]
    for t in range(1,6):
        mask=(data['trial']==t)&((data['stage']==0)|(data['stage']==-1));g=gaps[mask];res=int(data['resolution'][mask][0])
        events=np.count_nonzero(np.diff(g<0,axis=0),axis=0).tolist()
        rows.append(dict(resolution=res,samples=len(g),event_counts=dict(original=events[0],double_FK_native_qpos=events[1],double_FK_compensated_qpos=events[2]),
            original_to_compensated_max_abs_gap_nm=float(np.max(abs(g[:,0]-g[:,2]))*1e9)))
    require([r['event_counts']['original'] for r in rows]==[2,6,10,16,34],'Archived event reproduction differs')
    require([r['event_counts']['double_FK_compensated_qpos'] for r in rows]==[2]*5,'Compensated counterfactual differs')
    return dict(status='ARCHIVED_POSE_COUNTERFACTUAL_REVIEW_PASS',poses=n,certificates_checked=3*n,
        original_stage_roundoff_bounds_preserved=True,independent_matrix_FK_max_position_delta_m=max_position,
        independent_matrix_FK_max_rotation_delta=max_rotation,max_original_to_compensated_gap_delta_nm=max_gap_delta*1e9,
        tiers=rows,new_trajectory_simulated=False,dynamic_acceptance=False,native_calls=0,PPO=0,cloud_training=0)

if __name__=='__main__':
    # This entry needs the frozen arithmetic imports on PYTHONPATH; check_offline
    # and test_offline set it explicitly before importing this module.
    print(json.dumps(analyze(),indent=2,ensure_ascii=False))
