"""Exercise the new offline macro reviewer on the already-verified v2 bytes.

Only the geometry-vector schema is adapted in memory for the new oracle call.
No historical files, thresholds, decisions or original replay hashes are changed.
This is an audit-code regression, not a new physics run or full-path acceptance.
"""
import argparse
import gzip
import hashlib
import json
import sys
from pathlib import Path
import numpy as np
from static_common import ROOT,read,require,sha


def verify(return_root,candidate):
    candidate=Path(candidate).resolve();root=Path(return_root).resolve();n=root/'evidence/native'
    require(sha(root/'evidence/evidence-index.json')=='f78c68a9283941b1463ae512a4c314683947f313efb178627299d3e096fc8e2b',
            'Use the verified e256a07 return, never execute the old batch')
    for name,pin in read(root/'evidence/evidence-index.json')['files'].items():
        require((root/'evidence'/name).stat().st_size==pin['bytes'] and sha(root/'evidence'/name)==pin['sha256'],
                'Historical fixture bytes differ: '+name)
    sys.path[:0]=[str(candidate),str(candidate/'baseline/g11'),str(candidate/'baseline/g11/accepted'),str(candidate/'baseline/g11/host-candidate')]
    from kinematic_precision import reference_model
    import review_macro
    with np.load(n/'kinematic-model.npz',allow_pickle=False) as z:kmodel={k:z[k].copy() for k in z.files}
    kref=reference_model(kmodel,read(n/'model-array-hashes.json'))
    with np.load(ROOT/'source-reference/head-geometry.npz',allow_pickle=False) as z:vertices=z['vertices'].copy()
    with np.load(ROOT/'source-reference/convex-hull.npz',allow_pickle=False) as z:facets=z['facets'].copy()
    radius=read(ROOT/'geometry-contract.json')['radius'];original=review_macro.geometry_check
    def legacy_schema(row,*args):
        require(len(row['values'])==11 and row['values'][0]>=0,'Historical vertex schema differs')
        return original({**row,'values':row['values']+[-1.,0.,0.,0.,0.]},*args)
    review_macro.geometry_check=legacy_schema
    try:
        with gzip.open(n/'geometry-witness.jsonl.gz','rt') as stream:
            result=review_macro.audit_macro(n,(json.loads(line) for line in stream),kref,vertices,facets,radius,
                read(n/'kinematic-trials.json')['trials'],read(n/'ivp-result.json'))
    finally:review_macro.geometry_check=original
    require(result['integrations']==352 and result['forwards']==1413 and result['RK_stages']==1408
        and result['snapshots']==13 and result['accepted_resolution']==128,'Historical reviewer regression differs')
    return dict(status='NEW_MACRO_REVIEWER_VERIFIED_ON_IMMUTABLE_V2_RETURN',result=result,
        historical_commit='e256a0789ebfb0a1a35d621856e50479c4b89c8e',old_batch_rerun=False,
        historical_files_modified=False,assistant_native_calls=0,full_path_GPU_validated=False)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--return-root',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True)
    a=p.parse_args();print(json.dumps(verify(a.return_root,a.candidate),indent=2))
