"""Local artifact commits; per-volume SSH pushes are performed only by the user."""
import datetime
import json
import shlex
import shutil
import subprocess
from pathlib import Path
from segmented_return import volumes,encode_parts,LIMIT,sha as bytes_sha
from static_common import ROOT,REMOTE,plain,read,require,sha,write,verify_package


def git(root,*args):
    return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()


def init(folder,branch,identity):
    folder.mkdir(exist_ok=True)
    git(folder,'init','--initial-branch='+branch)
    for name,value in identity.items():git(folder,'config',name,value)
    git(folder,'config','core.hooksPath','/dev/null')
    git(folder,'config','commit.gpgsign','false')
    remotes=git(folder,'remote').splitlines()
    if 'origin' in remotes:require(git(folder,'remote','get-url','origin')==REMOTE,'Transfer remote changed')
    else:git(folder,'remote','add','origin',REMOTE)


def pinned_bytes(path,data):
    if path.exists():require(path.read_bytes()==data,'Existing transfer bytes differ: '+str(path));return
    temporary=path.with_name(path.name+'.writing')
    temporary.write_bytes(data);temporary.replace(path)


def pinned_json(path,value):
    pinned_bytes(path,(json.dumps(value,ensure_ascii=False,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())


def commit_if_needed(folder,paths,message):
    git(folder,'add','--',*paths)
    changed=git(folder,'diff','--cached','--name-only')
    if changed:git(folder,'commit','-m',message)
    require(not git(folder,'diff','HEAD','--exit-code'),'Local artifact has modified tracked files')


def prepare(run_dir,output,canonical):
    run,output,canonical=plain(run_dir),plain(output),plain(canonical)
    require(not output.is_relative_to(run) and not output.is_relative_to(canonical),'Transfer must be outside source and run')
    require(git(canonical,'remote','get-url','origin')==REMOTE,'Canonical Git SSH remote differs')
    verify_package();index=read(run/'evidence-index.json');index_hash=sha(run/'evidence-index.json')
    for name,pin in index['files'].items():
        p=run/name
        require(p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(run)
                and p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256'],'Evidence changed: '+name)
    identity={k:git(canonical,'config',k) for k in ('user.name','user.email')}
    require(all(identity.values()),'Existing local Git identity required')
    ssh_config=subprocess.run(['git','-C',str(canonical),'config','--get','core.sshCommand'],text=True,capture_output=True)
    if ssh_config.returncode==0 and ssh_config.stdout.strip():identity['core.sshCommand']=ssh_config.stdout.strip()
    if (output/'LOCAL-RETURN.json').exists():
        result=read(output/'LOCAL-RETURN.json');push=read(output/'PUSH-PLAN.json')
        require(result['evidence_index_sha256']==index_hash,'Return evidence identity differs')
        for row in [*push['volumes'],push['index']]:
            require(git(output/row['directory'],'rev-parse','HEAD')==row['commit'],'Existing return commit changed')
            require(not git(output/row['directory'],'diff','HEAD','--exit-code'),'Existing tracked return bytes changed')
        print(json.dumps(result,ensure_ascii=False,indent=2));return result
    if output.exists():
        marker=output/'TRANSFER-IDENTITY.json'
        require(marker.is_file() and read(marker)['evidence_index_sha256']==index_hash
                and read(marker)['directory']==str(output)
                and read(marker)['package_sha256']==sha(ROOT/'MANIFEST.json'),
                'Unrelated transfer directory; nothing replaced')
        stem=read(marker)['branch_stem']
    else:
        output.mkdir(parents=True)
        stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ').lower()
        stem='stage12-cloud-full-path-v1-return-'+stamp+'-'+index_hash[:10]
        write(output/'TRANSFER-IDENTITY.json',dict(evidence_index_sha256=index_hash,directory=str(output),
            package_sha256=sha(ROOT/'MANIFEST.json'),branch_stem=stem),exclusive=True)
    entries=[(run/'evidence-index.json','evidence/evidence-index.json')]
    entries.extend((run/n,'evidence/'+n) for n in sorted(index['files']))
    entries.extend((p,'diagnostic-package/'+p.relative_to(ROOT).as_posix()) for p in sorted(ROOT.rglob('*'))
                   if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and p.name!='frozen-inputs.zip')
    rows=[]
    for v,raw in enumerate(volumes(entries)):
        branch=stem+'-vol%03d'%v;directory='volume-%03d'%v;folder=output/directory
        parts=[]
        needed=3*len(raw)+64*1024**2
        if not (folder/'MANIFEST.json').exists():
            require(shutil.disk_usage(output).free>=needed,'Insufficient transfer disk; preserve native and prepared volumes, free space then collect again')
        init(folder,branch,identity)
        for j,b in encode_parts(raw):
            name='part-%04d.b64'%j;pinned_bytes(folder/name,b)
            parts.append(dict(name=name,bytes=len(b),sha256=bytes_sha(b)))
        meta=dict(format='stage12-full-path-segment-volume-v1',number=v,archive_bytes=len(raw),
                  archive_sha256=bytes_sha(raw),archive_limit_bytes=LIMIT,parts=parts)
        pinned_json(folder/'MANIFEST.json',meta)
        commit_if_needed(folder,['MANIFEST.json',*[r['name'] for r in parts]],'Stage12 full-path immutable evidence volume %d'%v)
        rows.append(dict(directory=directory,branch=branch,commit=git(folder,'rev-parse','HEAD'),
                         manifest_sha256=sha(folder/'MANIFEST.json'),**meta))
        print('EvidenceVolumePrepared=%d; bytes=%d; NOT_PUSHED'%(v,len(raw)),flush=True)
    branch=stem;folder=output/'index';init(folder,branch,identity)
    manifest=dict(format='stage12-full-path-segmented-git-return-v1',branch=branch,
        evidence_index_sha256=index_hash,result=read(run/'result.json'),archives=rows,
        package_manifest_sha256=sha(ROOT/'MANIFEST.json'),
        omitted_frozen_inputs=dict(sha256=sha(ROOT/'frozen-inputs.zip'),reason='Already delivered; unchanged 951-file frozen payload'),
        archive_limit_bytes=LIMIT,original_evidence_unchanged=True,automatic_push=False)
    pinned_json(folder/'MANIFEST.json',manifest)
    pinned_bytes(folder/'README.txt',b'Read each volume from its fixed commit in MANIFEST.json. Decode segments, then verify every evidence-index file. Never merge artifact branches.\n')
    commit_if_needed(folder,['MANIFEST.json','README.txt'],'Stage12 full-path evidence index; independent review required')
    index_row=dict(directory='index',branch=branch,commit=git(folder,'rev-parse','HEAD'))
    pinned_json(output/'PUSH-PLAN.json',dict(volumes=[{k:r[k] for k in ('directory','branch','commit')} for r in rows],index=index_row))
    pinned_bytes(output/'manual_push.py',(ROOT/'manual_push.py').read_bytes())
    command='python3 '+shlex.quote(str(output/'manual_push.py'))+' --push'
    result=dict(status='LOCAL_GIT_RETURN_PREPARED_NOT_PUSHED',directory=str(output),branch=branch,
        commit=index_row['commit'],evidence_index_sha256=index_hash,push_command=command,volumes=len(rows),
        all_original_files_included=True,maximum_archive_bytes=LIMIT,PPO=0,cloud_training=0,automatic_push=False)
    write(output/'LOCAL-RETURN.json',result,exclusive=True)
    print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
    print('\n手动 Git SSH 回传命令（分卷后总索引，失败可重复此命令，绝不重跑仿真）：\n'+command,flush=True)
    return result
