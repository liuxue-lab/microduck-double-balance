"""Durable compact RK stages plus complete raw Data/owners at trial boundaries."""
import gzip
import hashlib
from evidence_journal import EvidenceJournal, encoded, require
from runtime_accounting import save

class DynamicEvidence(EvidenceJournal):
    def __init__(self,path,bridge,precise,journal,contact,plan):
        super().__init__(path,bridge,byte_limit=48*1024**2,file_limit=256,record_limit=1700)
        self.precise,self.journal,self.contact,self.plan=precise,journal,contact,plan
        self.micro_stream=gzip.open(path.parent/'rk-stages.jsonl.gz','xb')
        self.micro_bytes=0;self.micro_records=0;self.micro_digest=hashlib.sha256();self.micro_closed=False
    def __call__(self,kind,row):
        if kind=='trial_start':
            self.precise.begin_trial(row['resolution'],row['role'],row['trial'])
            self.contact.archive.sample_next=True
            self.journal.resolution=row['resolution'];self.journal.micro_done=0
            self.journal.phase='trial-%d/%s/%d'%(row['trial'],row['role'],row['resolution'])
        if kind=='microstep':
            require(not self.stopped and not self.closed,'Evidence closed')
            self.attempted_records+=1
            require(self.attempted_records<=self.record_limit,'Evidence record cap')
            # Keep all stage inputs, qacc, contacts and 114 Data digests. Contact
            # ordering runs full checks online; its large proofs stay summarized.
            compact={k:row[k] for k in ('trial','resolution','micro_index','micro_dt_s','post_integrator','stages','stage_sha256','velocity_bounds','correction')}
            compact['ordering_serials']=[p['serial'] for p in row['contact_ordering']]
            raw=encoded(compact)
            require(self.micro_bytes+len(raw)<=self.plan['rk_uncompressed_bytes'],'RK evidence cap; no silent truncation')
            self.micro_stream.write(raw);self.micro_stream.flush()
            self.micro_digest.update(raw);self.micro_bytes+=len(raw);self.micro_records+=1
            self.journal.micro_done=row['micro_index']+1;self.journal.progress()
            return
        # Base journal retains full Data/owner snapshots for all trial endpoints,
        # rollbacks and publication, including failed-candidate records.
        super().__call__(kind,row)
        if kind=='trial_complete':
            self.precise.end_trial();self.journal.trials+=1;self.journal.progress(True)
        elif kind=='exact_replay':self.precise.begin_commit()
    def close_stream(self):
        if not self.micro_closed:self.micro_stream.close();self.micro_closed=True
        save(self.path.parent/'rk-stream-index.json',dict(records=self.micro_records,uncompressed_bytes=self.micro_bytes,
            uncompressed_sha256=self.micro_digest.hexdigest(),closed=self.micro_closed,raw_all_114_arrays_each_stage=False,
            every_stage_primary_qacc_contacts_and_114_hashes=True),durable=True)
    def finalize(self):
        self.close_stream();return super().finalize()
