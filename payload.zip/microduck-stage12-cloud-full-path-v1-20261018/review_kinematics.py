"""Offline binding of recorded target poses to the independently rebuilt RK accumulator."""
import hashlib
import json
import numpy as np
from kinematic_precision import fk,pose_input
from static_common import require

def expected_pose(native,acc,dt,stage,previous,micro):
    q,proof=pose_input(native,acc,dt,stage,previous)
    proof['micro_index']=micro
    return q,proof

def verify_pose(row,expected,reference):
    q,proof=expected
    require(row['kinematics']==proof,'Recorded accumulator/RK binding differs')
    p,r=fk(q,reference)
    require(np.max(abs(p-np.asarray(row['position'])))<1e-15
            and np.max(abs(r-np.asarray(row['rotation'])))<3e-15,'Target FK differs')
    require(hashlib.sha256(np.asarray(proof['qpos_native'],np.float32).tobytes()).hexdigest()==row['primary_sha256']['qpos'],'Kinematic primary qpos identity differs')
    return {k:row[k] for k in ('position','rotation','kinematics','values','mutation','primary_sha256')}

def encoded_physical(row):
    return json.dumps(row,sort_keys=True,separators=(',',':'),allow_nan=False).encode()+b'\n'
