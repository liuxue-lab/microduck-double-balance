"""Focused regression fixtures for gates, criteria, exact recovery and delivery.
These tests do NOT emulate or certify physics, native owner construction or CUDA.
"""
import argparse
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch
import zipfile
import numpy as np

ROOT=Path(__file__).resolve().parent
def setup(candidate):
    candidate=Path(candidate).resolve()
    sys.path[:0]=[str(ROOT),str(candidate),str(candidate/'baseline/g11'),str(candidate/'baseline/g11/accepted'),str(candidate/'baseline/g11/host-candidate')]

class SafetyAndIdentity(unittest.TestCase):
    def test_exact_bam_reconstruction_and_reject_changed_input(self):
        from reconstruct_model import reconstruct,load_reconstructed
        arrays,report=reconstruct();self.assertEqual(report['status'],'ARCHIVED_BAM_MODEL_BYTES_RECONSTRUCTED_EXACT')
        saved,_=load_reconstructed();self.assertEqual({k:v.tobytes() for k,v in arrays.items()},{k:v.tobytes() for k,v in saved.items()})
        with tempfile.TemporaryDirectory() as td:
            import shutil
            root=Path(td);shutil.copytree(ROOT/'origin',root/'origin');shutil.copytree(ROOT/'source-reference',root/'source-reference')
            p=root/'origin/macro-68/raw/record-00001-data.npz'
            with np.load(p) as z:raw={k:z[k].copy() for k in z.files}
            raw['Data.ctrl'][0,0]+=np.float32(.01);np.savez(p,**raw)
            with self.assertRaisesRegex(RuntimeError,'Boundary Data bytes'):reconstruct(root)
    def test_source_call_closure_catches_missing_cap(self):
        from operation_contract import validate_caps
        plan=json.loads((ROOT/'plan.json').read_text());validate_caps(CANDIDATE,plan)
        del plan['caps']['Contact_order_apply']
        with self.assertRaisesRegex(RuntimeError,'ceilings differ'):validate_caps(CANDIDATE,plan)
    def test_explicit_window_and_old_deadline_preserved(self):
        from run_full import admission
        from static_common import SCOPE
        plan=json.loads((ROOT/'plan.json').read_text());now=1800000000
        for scope,window in [(None,False),(SCOPE,False),('OLD_STATIC',True)]:
            with self.assertRaises(RuntimeError):admission(plan,scope,window,now)
        r=admission(plan,SCOPE,True,now)
        self.assertEqual((r['native_stop_utc']-now,r['stop_utc']-now),(85500,86400));self.assertFalse(r['deadline_reset'])
    def test_started_markers_cannot_be_reused(self):
        from prepare import refuse_started,MARKERS
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            for marker in MARKERS:
                p=root/marker;p.touch()
                with self.assertRaisesRegex(RuntimeError,'no native retry'):refuse_started(root)
                p.unlink()
    def test_dead_child_identity_collection(self):
        from run_full import child_is_gone
        child={'pid':123,'identity':{'pid':123,'start_ticks':'100','boot_id':'fixture'}}
        with patch('run_full.os.kill',side_effect=ProcessLookupError):self.assertTrue(child_is_gone(child))
        with patch('run_full.os.kill',return_value=None):
            with patch('run_full.process_identity',return_value=None):self.assertFalse(child_is_gone(child))
            with patch('run_full.process_identity',return_value=child['identity']):self.assertFalse(child_is_gone(child))
            with patch('run_full.process_identity',return_value={**child['identity'],'start_ticks':'101'}):self.assertTrue(child_is_gone(child))
        with patch('run_full.os.kill',side_effect=PermissionError):self.assertFalse(child_is_gone(child))
    def test_paired_nested_wal_and_budget_denials(self):
        from dynamic_accounting import Gate,Journal,Budget
        from runtime_accounting import review_ledger
        from macro_state_bridge import MACRO_LIMITS
        with tempfile.TemporaryDirectory() as td:
            counts={};caps={**{k:0 for k in MACRO_LIMITS},'outer':1,'inner':1};plan=json.loads((ROOT/'plan.json').read_text())
            j=Journal(Path(td),counts,caps,plan);g=Gate(counts,j,lambda:None,caps,native_stop_utc=time.time()+100,total_stop_utc=time.time()+200)
            self.assertEqual(g.limited('outer',1,lambda:g.limited('inner',1,lambda:7)())(),7)
            with self.assertRaisesRegex(RuntimeError,'cap reached'):g.limited('inner',1,lambda:None)()
            with self.assertRaisesRegex(RuntimeError,'Undeclared'):g.limited('missing',9,lambda:None)
            j.close();r=review_ledger(Path(td)/'native-ledger.jsonl');self.assertTrue(r['exact']);self.assertEqual(r['rows'],4)
    def test_failed_operation_keeps_attempt_pending(self):
        from dynamic_accounting import Gate,Journal
        from runtime_accounting import review_ledger
        with tempfile.TemporaryDirectory() as td:
            counts={};caps={'integrations':1};j=Journal(Path(td),counts,caps,json.loads((ROOT/'plan.json').read_text()))
            g=Gate(counts,j,lambda:None,caps,native_stop_utc=time.time()+100,total_stop_utc=time.time()+200)
            def fail():raise ValueError('native fixture failure')
            with self.assertRaises(ValueError):g.limited('integrations',1,fail)()
            j.close();r=review_ledger(Path(td)/'native-ledger.jsonl')
            self.assertEqual(r['pending'],{'integrations':1});self.assertFalse(r['exact']);self.assertEqual(r['integration_completed_lower'],0)
    def test_geometry_certificate_fails_before_contact_write(self):
        from dynamic_boundary import DynamicBoundary
        class A:
            def __init__(self,value):self.value=np.asarray(value)
            def numpy(self):return self.value.copy()
        class Gate:
            counts={'GPU_forward_attempted':1,'GPU_forward_completed':0}
            def limited(self,name,cap,fn):
                self.label=name;return fn
        b=DynamicBoundary.__new__(DynamicBoundary);b.closed=False;b.phase='trial';b.resolution=32;b.trial_calls=0;b.calls=0;b.attempts=0;b.trial=1;b.role='estimate'
        b.plan={'caps':{'GPU_forward':6023}};b.contract={'radius':.02};b.gate=Gate();b.kernels=NS(certified_geometry=object())
        pos=np.zeros((1,85,3),np.float32);rot=np.tile(np.eye(3,dtype=np.float32),(1,85,1,1))
        b.d=NS(geom_xpos=A(pos),geom_xmat=A(rot),qpos=A(np.zeros((1,35))),qvel=A(np.zeros((1,32))),time=A([0]),ctrl=A(np.zeros((1,14))))
        b.d.qpos.device='fake';b.m=NS(mesh_vert=object());b.geometry=A(np.zeros((1,11)));b.wp=NS(launch=lambda *a,**k:None)
        b.kinematics=NS(positions=object(),rotations=object(),kernels=b.kernels,compute=lambda boundary:(pos[0,[84,49]],rot[0,[84,49]],{}))
        records=[];b.append=records.append
        with self.assertRaisesRegex(RuntimeError,'certificate failed'):b.wrap(lambda m,d:None)(b.m,b.d)
        self.assertEqual(b.gate.label,'Precise_geometry_kernel');self.assertEqual(b.calls,0);self.assertTrue(records[0]['certificate_failed_before_mutation'])

def world(res=32):
    from convergence_contract import ContactIntegral,PAIRS
    from ground_scalar_contract import brackets
    q=np.zeros(35);q[[3,24,31]]=1
    samples=[{p:False for p in PAIRS} for _ in range(res+1)]
    integral=ContactIntegral();integral.stages=4*res;integral.duration=.002
    return dict(resolution=res,endpoint=dict(qpos=q.tolist(),qvel=np.zeros(32).tolist()),event_samples=samples,brackets=brackets(samples,res),integral=integral.result())

class OriginalCriteria(unittest.TestCase):
    def test_local_state_limit_and_event_direction_are_enforced(self):
        from dynamic_driver import assess_ivp
        a,b=world(),world(64);self.assertTrue(assess_ivp(a,b)['accepted'])
        b['endpoint']['qpos'][0]=2.6e-5;self.assertFalse(assess_ivp(a,b)['accepted'])
        b=world(64);b['brackets']=[dict(pair='upper_head',direction='enter',left_s=0.,right_s=.002/64,width_s=.002/64)]
        self.assertFalse(assess_ivp(a,b)['accepted'])
    def test_original_contact_integral_limit_is_not_omitted(self):
        from dynamic_driver import assess_ivp
        a,b=world(),world(64);b['integral']['pairs']['upper_head']['peak_overlap_m']=1.1e-5
        self.assertIn('original_state_contact_integral_limits',assess_ivp(a,b)['reasons'])
    def run_driver(self,fail=False,mismatch=False):
        from full_adaptive import FullAdaptive
        from cohort_contract import CohortTransaction
        class Array:
            def numpy(self):return np.array([.136],np.float32)
        budget=NS(counts={},reserve=lambda **kw:None)
        bridge=NS(phase='idle',budget=budget,sim=NS(wp_data=NS(time=Array()),wp_model=object()))
        bridge.checkpoint=lambda:setattr(bridge,'phase','trial') or setattr(bridge,'saved',NS(data=NS(fingerprint=lambda:{})))
        bridge.close=lambda:setattr(bridge,'phase','idle')
        engine=NS(budget=budget,data=bridge.sim.wp_data,model=bridge.sim.wp_model)
        d=FullAdaptive(bridge,engine,(68,),lambda *a:None,5000);calls=[]
        def trial(n,role):
            d.trial_serial+=1;calls.append((n,role));tx=d.transaction;tx.invalidate();tx.forward_complete(tx.state_generation);tx.sense_complete(tx.state_generation)
            w=world(n)
            if fail:w['endpoint']['qpos'][0]=float(n)*.001
            endpoint=b'{"data":"same"}' if not (mismatch and role=='replay') else b'{"data":"different"}'
            return dict(id=d.trial_serial,resolution=n,worlds=[w],endpoint=endpoint,stage_sha256='a'*64)
        def rollback(reason):
            tx=d.transaction
            if tx.phase not in ('restore_required','restore_for_replay','abort_required'):tx.abort()
            tx.restored(data_exact=True,owners_exact=True,rng_exact=True,model_exact=True,bindings_exact=True);return {'data_exact':True}
        def commit(ticket,replay,decision):
            d.transaction.publish(ticket);d.commits+=1;d.ticks=(69,);bridge.close();return dict(accepted_resolution=replay['resolution'])
        d._trial=trial;d._rollback=rollback;d._commit=commit
        return d,calls
    def test_accepted_path_mandatory_exact_replay(self):
        d,calls=self.run_driver();r=d.advance();self.assertEqual(calls,[(32,'estimate'),(64,'candidate'),(64,'replay')]);self.assertEqual(r['actual_integrations'],160)
        with self.assertRaises(RuntimeError):d.advance()
    def test_max_tier_stops_without_extra_grid(self):
        d,calls=self.run_driver(fail=True)
        with self.assertRaisesRegex(RuntimeError,'tier512 failed'):d.advance()
        self.assertEqual([n for n,_ in calls],[32,64,128,256,512]);self.assertEqual(d.commits,0);self.assertEqual(d.phase,'stopped')
    def test_replay_mismatch_blocks_publication(self):
        d,calls=self.run_driver(mismatch=True)
        with self.assertRaisesRegex(RuntimeError,'Exact endpoint replay failed'):d.advance()
        self.assertEqual(d.commits,0)

class KinematicPrecisionTests(unittest.TestCase):
    def fixture(self):
        with np.load(ROOT/'source-reference/previous-poses.npz') as z:return {k:z[k].copy() for k in z.files}
    def test_all_archived_poses_with_independent_matrix_oracle(self):
        from offline_kinematics import analyze
        result=analyze();self.assertEqual(result['poses'],3973)
        self.assertFalse(result['dynamic_acceptance']);self.assertEqual(result['native_calls'],0)
    def test_full_model_arrays_reconstructed_exact_and_tamper_rejected(self):
        from reconstruct_kinematics import reconstruct
        from kinematic_precision import reference_model
        raw,report=reconstruct(CANDIDATE.parent/'project');self.assertEqual(len(raw),14)
        pins=json.loads((ROOT/'origin/macro-68/raw/record-00001-snapshot.json').read_text())['model_hashes']
        raw['body_pos'][0,8,0]+=np.float32(.001)
        with self.assertRaisesRegex(RuntimeError,'Model pin differs'):reference_model(raw,pins)
    def test_no_primary_mutation_and_bad_accumulator_or_stage_is_rejected(self):
        from kinematic_precision import pose_input,Q
        f=self.fixture();native=f['qpos'][0:1];acc=f['accumulator'][0:1];before=native.tobytes()
        q,proof=pose_input(native,acc,float(f['dt'][0]),0)
        self.assertEqual(native.tobytes(),before);self.assertFalse(proof['native_qpos_written'])
        self.assertTrue(np.array_equal(q[np.setdiff1d(np.arange(35),Q)],native[0,np.setdiff1d(np.arange(35),Q)].astype(float)))
        wrong=acc.copy();wrong[0,0]+=.01
        with self.assertRaisesRegex(RuntimeError,'boundary/native mismatch'):pose_input(native,wrong,float(f['dt'][0]),0)
        with self.assertRaisesRegex(RuntimeError,'stage differs'):pose_input(native,acc,float(f['dt'][0]),4)
        with self.assertRaisesRegex(RuntimeError,'original bound'):pose_input(f['qpos'][1:2],wrong,float(f['dt'][1]),1,f['previous_velocity'][1:2])
    def test_target_pose_auditor_binds_accumulator_and_fk(self):
        from review_kinematics import expected_pose,verify_pose
        from kinematic_precision import fk
        f=self.fixture()
        with np.load(ROOT/'source-reference/kinematics-reference.npz') as z:ref={k:z[k].astype(float) for k in z.files}
        exp=expected_pose(f['qpos'][1:2],f['accumulator'][1:2],float(f['dt'][1]),1,f['previous_velocity'][1:2],0)
        p,r=fk(exp[0],ref)
        row=dict(position=p.tolist(),rotation=r.tolist(),kinematics=exp[1],values=[],mutation={},primary_sha256={'qpos':hashlib.sha256(f['qpos'][1:2].tobytes()).hexdigest()})
        verify_pose(row,exp,ref)
        bad=copy.deepcopy(row);bad['kinematics']['accumulator'][0][0]+=.001
        with self.assertRaisesRegex(RuntimeError,'RK binding'):verify_pose(bad,exp,ref)
        bad=copy.deepcopy(row);bad['position'][1][2]+=1e-8
        with self.assertRaisesRegex(RuntimeError,'Target FK'):verify_pose(bad,exp,ref)
    def test_live_adapter_covers_all_rk_stages_endpoint_and_commit(self):
        from kinematic_precision import KinematicPrecision,pose_input,fk,Q
        f=self.fixture()
        with np.load(ROOT/'source-reference/kinematics-reference.npz') as z:ref={k:z[k].astype(float) for k in z.files}
        class Array:
            def __init__(self,a):self.a=a.copy()
            def numpy(self):return self.a.copy()
            def assign(self,a):self.a=a.copy()
        for i in (0,1,2,3,128,132,133,134,135,3972):
            stage=int(f['stage'][i]);stage=None if stage<0 else stage;micro=int(f['micro_index'][i]);res=int(f['resolution'][i])
            k=KinematicPrecision.__new__(KinematicPrecision);k.reference=ref;k.m=object();k.d=NS(qpos=Array(f['qpos'][i:i+1]));k.plan={'caps':{'GPU_forward':6023}}
            k.gate=NS(limited=lambda label,cap,fn:fn);k.positions=Array(np.zeros((1,2,3)));k.rotations=Array(np.zeros((1,2,3,3)))
            acc=f['accumulator'][i:i+1];start=f['qpos'][i:i+1].copy();start[:,Q]=acc.astype(np.float32)
            stages=[] if stage is None else [dict(qvel=f['previous_velocity'][i:i+1]) for _ in range(stage)]
            k.engine=NS(data=k.d,model=k.m,phase=None if stage is None else 'micro',acc=NS(value=acc,expected=acc.astype(np.float32),enabled=np.array([True]),steps=np.array([micro])),stages=stages,start=start,dt=float(f['dt'][i]))
            boundary=NS(resolution=res,phase='trial',trial_calls=4*micro+(0 if stage is None else stage))
            p,r,proof=k.compute(boundary);self.assertFalse(proof['native_qpos_written'])
            self.assertEqual(k.positions.numpy().tobytes(),p[None].tobytes())
            if stage is None:
                boundary.phase='commit';boundary.trial_calls=0
                p2,r2,_=k.compute(boundary);self.assertEqual(p.tobytes(),p2.tobytes());self.assertEqual(r.tobytes(),r2.tobytes())
            else:
                boundary.trial_calls+=1
                with self.assertRaisesRegex(RuntimeError,'stage sequence'):k.compute(boundary)
    def test_new_kernel_algorithm_is_unchanged_apart_from_pose_types(self):
        import ast
        old=ast.parse((ROOT/'precise_contact_kernel.py').read_text());new=ast.parse((ROOT/'precise_pose_kernel.py').read_text())
        for name in ('relative_vertex','certified_geometry'):
            a=next(n for n in old.body if isinstance(n,ast.FunctionDef) and n.name==name)
            b=next(n for n in new.body if isinstance(n,ast.FunctionDef) and n.name==name)
            self.assertEqual([ast.dump(n) for n in a.body],[ast.dump(n) for n in b.body])
    def test_kinematic_replay_mismatch_stops_before_publication(self):
        from dynamic_boundary import DynamicBoundary
        with tempfile.TemporaryDirectory() as td:
            b=DynamicBoundary.__new__(DynamicBoundary);b.phase='trial';b.trial_calls=257;b.resolution=64;b.role='replay';b.trial=3;b.out=Path(td)
            b.pose_digest=hashlib.sha256(b'new');b.trial_proofs=[dict(resolution=64,role='candidate',kinematic_sha256=hashlib.sha256(b'old').hexdigest())]
            with self.assertRaisesRegex(RuntimeError,'kinematic replay failed'):b.end_trial()
            self.assertFalse((Path(td)/'kinematic-trials.json').exists())
            b.pose_digest=hashlib.sha256(b'old');b.end_trial();self.assertEqual(b.phase,'idle')

class FullPathRegressions(unittest.TestCase):
    def test_partial_boundary_constructor_always_closes_evidence(self):
        import gzip
        from full_boundary import FullBoundary
        from dynamic_boundary import DynamicBoundary
        for point in ('before_stream','after_stream','Hull_module_load'):
            with self.subTest(point=point),tempfile.TemporaryDirectory() as td:
                path=Path(td)/'geometry-witness.jsonl.gz';calls=[]
                def base_init(obj,*args):
                    if point=='before_stream':raise RuntimeError('injected before stream')
                    obj.stream=gzip.open(path,'xb')
                    if point=='after_stream':raise RuntimeError('injected after stream')
                class Array:
                    def __init__(self,a):self.a=a
                    def numpy(self):return self.a.copy()
                class Gate:
                    def limited(self,label,cap,fn):
                        def call():
                            calls.append(label)
                            if label=='Hull_module_load':raise RuntimeError('injected module compiler')
                            return fn()
                        return call
                with np.load(ROOT/'source-reference/head-geometry.npz') as z:
                    vertices=np.zeros((108326,3),np.float32);vertices[100264:]=z['vertices']
                wp=NS(vec3i=object(),float64=object(),array=lambda a,**k:Array(a),zeros=lambda s,**k:Array(np.zeros(s)))
                boundary=FullBoundary.__new__(FullBoundary)
                with patch.object(DynamicBoundary,'__init__',base_init),patch.dict(sys.modules,{'convex_pose_kernel':NS()}):
                    with self.assertRaisesRegex(RuntimeError,'injected'):
                        boundary.__init__(NS(mesh_vert=Array(vertices)),NS(qpos=NS(device='fake')),wp,Gate(),Path(td),{})
                result=boundary.close();self.assertTrue(result['closed'])
                self.assertEqual((result['attempts'],result['completed'],result['completed_macros']),(0,0,0))
                self.assertFalse(result['gpu_fixture_verified']);self.assertEqual(boundary.close(),result)
                if path.exists():
                    with gzip.open(path,'rb') as stream:self.assertEqual(stream.read(),b'')
                self.assertEqual('Hull_module_load' in calls,point=='Hull_module_load')

    def test_uncertified_full_hull_stops_before_contact_mutation(self):
        from full_boundary import FullBoundary
        class Array:
            def __init__(self,value):self.value=np.asarray(value)
            def numpy(self):return self.value.copy()
        b=FullBoundary.__new__(FullBoundary);b.closed=False;b.fixture_verified=True;b.phase='external'
        b.role='external';b.resolution=0;b.macro_index=None;b.trial=0;b.trial_calls=0;b.calls=0;b.attempts=0;b.external_calls=0
        b.plan={'caps':{'GPU_forward':1},'owner_plan':{'external_forward_reservation':1}}
        b.gate=NS(counts={'GPU_forward_attempted':1,'GPU_forward_completed':0},limited=lambda label,cap,fn:fn)
        pos=np.zeros((1,85,3),np.float32);rot=np.tile(np.eye(3,dtype=np.float32),(1,85,1,1))
        b.d=NS(geom_xpos=Array(pos),geom_xmat=Array(rot),qpos=Array(np.zeros((1,35))),
               qvel=Array(np.zeros((1,32))),time=Array([0]),ctrl=Array(np.zeros((1,14))))
        b.m=object();b.kinematics=NS(compute=lambda boundary:(pos[0,[84,49]],rot[0,[84,49]],{}))
        b.geometry_call=lambda label:np.zeros(16);records=[];b.append=records.append
        with self.assertRaisesRegex(RuntimeError,'no original narrowphase fallback'):b.wrap(lambda m,d:None)(b.m,b.d)
        self.assertEqual(b.calls,0);self.assertEqual(b.attempts,1);self.assertTrue(records[0]['certificate_failed_before_mutation'])

    def test_owner_cannot_renew_its_window(self):
        from static_common import SCOPE
        from full_plan import fingerprint
        with tempfile.TemporaryDirectory() as td,patch.dict(os.environ,MD12_FULL_RUN_DIRECTORY=td):
            from full_factory import admission
            plan=json.loads((ROOT/'plan.json').read_bytes())['owner_plan']
            started=dict(explicit_cli_scope=SCOPE,separately_authorized=True,started_utc=1000,
                         native_stop_utc=86500,stop_utc=87400)
            (Path(td)/'started.json').write_text(json.dumps(started))
            auth=dict(scope=SCOPE,authorization='USER_AUTHORIZED_NATIVE_MEASUREMENT',owner_plan_sha256=fingerprint(plan),
                PPO=0,cloud_training=0,canonical_before=json.loads((ROOT/'plan.json').read_text())['canonical_integrations_before'],
                native_stop_utc=86500,stop_utc=87400)
            with patch('full_factory.time.time',return_value=1001):admission(plan,auth)
            with patch('full_factory.time.time',return_value=86500):
                with self.assertRaisesRegex(RuntimeError,'outside'):admission(plan,auth)
            auth['stop_utc']+=1
            with self.assertRaisesRegex(RuntimeError,'renew'):admission(plan,auth)

    def test_full_boundary_macro_phase_and_replay(self):
        from full_boundary import FullBoundary
        with tempfile.TemporaryDirectory() as td:
            b=FullBoundary.__new__(FullBoundary);b.fixture_verified=False;b.phase='external';b.macros=0;b.kinematics=NS(engine=None)
            b.out=Path(td);b.trial_proofs=[]
            with self.assertRaises(RuntimeError):b.begin_macro(0,0,object())
            b.fixture_verified=True
            for i in (0,1):
                b.begin_macro(i,i,object());b.begin_trial(32,'estimate',1);b.trial_calls=129
                b.pose_digest=hashlib.sha256(b'estimator');b.end_trial()
                b.begin_trial(64,'candidate',2);b.trial_calls=257;b.pose_digest=hashlib.sha256(b'accepted');b.end_trial()
                b.begin_trial(64,'replay',3);b.trial_calls=257;b.pose_digest=hashlib.sha256(b'wrong')
                with self.assertRaisesRegex(RuntimeError,'replay failed'):b.end_trial()
                b.pose_digest=hashlib.sha256(b'accepted');b.end_trial();b.begin_commit();b.trial_calls=1;b.end_macro()
                self.assertIsNone(b.kinematics.engine);self.assertEqual(b.phase,'external')
            self.assertEqual(b.macros,2);self.assertEqual(len(b.trial_proofs),6)
            with self.assertRaises(RuntimeError):b.begin_macro(0,0,object())

    def test_external_fk_does_not_write_qpos_or_reuse_trial_accumulator(self):
        from full_kinematics import FullKinematics
        class Array:
            def __init__(self,a):self.a=np.asarray(a).copy()
            def numpy(self):return self.a.copy()
            def assign(self,a):self.a=np.asarray(a).copy()
        with np.load(ROOT/'source-reference/previous-poses.npz') as z:q=z['qpos'][0:1].copy()
        with np.load(ROOT/'source-reference/kinematics-reference.npz') as z:ref={k:z[k].copy() for k in z.files}
        k=FullKinematics.__new__(FullKinematics);k.engine=None;k.d=NS(qpos=Array(q));k.reference=ref
        k.gate=NS(limited=lambda label,limit,fn:fn);k.plan={'caps':{'GPU_forward':1}}
        k.positions=Array(np.zeros((1,2,3)));k.rotations=Array(np.zeros((1,2,3,3)))
        _,_,proof=k.compute(NS(phase='external'));self.assertEqual(k.d.qpos.numpy().tobytes(),q.tobytes())
        self.assertEqual(proof['mode'],'external_native_pose');k.engine=object()
        with self.assertRaisesRegex(RuntimeError,'active trial'):k.compute(NS(phase='external'))

    def test_every_started_slot_refuses_live_process_collection(self):
        from run_full import collect
        with tempfile.TemporaryDirectory() as td:
            run=Path(td);(run/'child.json').write_text(json.dumps({'pid':123,'identity':None}))
            with patch('run_full.child_is_gone',return_value=False):
                with self.assertRaisesRegex(RuntimeError,'still alive'):collect(run,{}, {})
            with patch('run_full.child_is_gone',return_value=True),patch('run_full.process_group_gone',return_value=False):
                with self.assertRaisesRegex(RuntimeError,'still alive'):collect(run,{}, {})
            self.assertFalse((run/'evidence-index.json').exists())

class Transport(unittest.TestCase):
    def test_many_small_files_split_metadata_before_decoder_limit(self):
        from segmented_return import volumes
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);entries=[]
            for i in range(40):
                path=root/str(i);path.write_bytes(b'x');entries.append((path,'evidence/'+str(i)))
            with patch('segmented_return.MAX_SEGMENTS',16):out=list(volumes(entries))
            self.assertEqual(len(out),3);targets=[]
            for raw in out:
                with zipfile.ZipFile(io.BytesIO(raw)) as z:
                    rows=json.loads(z.read('segments.json'));self.assertLessEqual(len(rows),16)
                    targets.extend(r['target'] for r in rows)
            self.assertEqual(targets,[name for _,name in entries])

    def test_large_file_segmentation_resume_decode_and_tamper(self):
        import prepare_git_return as transfer
        from decode_git_return import decode
        from static_common import REMOTE,write,sha
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);canonical=root/'canonical';canonical.mkdir();run=root/'run';run.mkdir();package=root/'package';package.mkdir()
            def git(*args):return subprocess.check_output(['git','-C',str(canonical),*args],stderr=subprocess.DEVNULL,text=True).strip()
            git('init');git('config','user.name','Offline Fixture');git('config','user.email','fixture@example.invalid');git('remote','add','origin',REMOTE)
            write(run/'result.json',dict(status='FULL_PATH_STOPPED_PRESERVE',PPO=0,cloud_training=0))
            # One file exceeds a volume; use small temporary volume limits to
            # exercise the exact production streaming code without a giant fixture.
            (run/'large.wal').write_bytes(os.urandom(70*1024));(run/'empty.bin').touch()
            files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in run.iterdir()}
            write(run/'evidence-index.json',dict(files=files))
            (package/'frozen-inputs.zip').write_bytes(b'fixture');(package/'code.py').write_text('# fixture\n')
            (package/'manual_push.py').write_bytes((ROOT/'manual_push.py').read_bytes())
            pins={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in package.iterdir()}
            write(package/'MANIFEST.json',dict(files=pins))
            original=transfer.commit_if_needed;calls=[]
            def fail_once(folder,paths,message):
                original(folder,paths,message);calls.append(folder.name)
                if len(calls)==1:raise RuntimeError('fixture interrupted after immutable first volume')
            with patch('segmented_return.CHUNK',8192),patch('segmented_return.VOLUME_RAW',32768),patch.object(transfer,'ROOT',package),patch.object(transfer,'verify_package',return_value='fixture'):
                with patch.object(transfer,'commit_if_needed',side_effect=fail_once):
                    with self.assertRaisesRegex(RuntimeError,'fixture interrupted'):transfer.prepare(run,root/'return',canonical)
                original_head=transfer.git(root/'return/volume-000','rev-parse','HEAD')
                receipt=transfer.prepare(run,root/'return',canonical)
                self.assertEqual(original_head,transfer.git(root/'return/volume-000','rev-parse','HEAD'))
                self.assertEqual(receipt,transfer.prepare(run,root/'return',canonical))
            self.assertFalse(receipt['automatic_push']);self.assertGreaterEqual(receipt['volumes'],3)
            self.assertEqual(decode(root/'return',root/'decoded')['status'],'SEGMENTED_RETURN_DECODE_VERIFIED')
            self.assertEqual((root/'decoded/evidence/large.wal').read_bytes(),(run/'large.wal').read_bytes())
            self.assertEqual((root/'decoded/evidence/empty.bin').stat().st_size,0)
            # Default invocation must not contact the network.
            text=subprocess.check_output([sys.executable,str(root/'return/manual_push.py')],text=True)
            self.assertIn('显式 --push',text)
            part=next((root/'return/volume-000').glob('*.b64'));part.write_bytes(part.read_bytes()+b'x')
            with self.assertRaisesRegex(RuntimeError,'Part bytes'):decode(root/'return',root/'bad')
            self.assertFalse((root/'bad').exists());self.assertTrue(list(root.glob('bad.decoding-*/decode-failure.json')))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--candidate',type=Path,required=True);args,rest=parser.parse_known_args()
    CANDIDATE=args.candidate.resolve();setup(CANDIDATE)
    program=unittest.main(argv=[sys.argv[0],*rest],exit=False,verbosity=2)
    if any(n in sys.modules for n in ('torch','warp','mujoco','mujoco_warp','mjlab','bam')):
        raise RuntimeError('Offline tests imported a native simulator package')
    sys.exit(0 if program.result.wasSuccessful() else 1)

