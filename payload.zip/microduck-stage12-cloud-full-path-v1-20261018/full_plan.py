"""The new full-path proposal is separate from every expired/completed batch."""
import hashlib
import json
from static_common import ROOT, read, require


def fingerprint(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def validate_owner(plan):
    require(plan==read(ROOT/'plan.json')['owner_plan'],'Owner plan differs from this fixed new proposal')
    require(plan['public_steps']==25 and plan['max_macros']==250 and plan['logical_world']==0,
            'Exactly one new corrected 24-step rollout and one post-reset step')
    return plan
