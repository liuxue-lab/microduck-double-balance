"""Same v2 durable per-operation WAL, now with full-environment progress."""
import shutil
import time
from dynamic_accounting import Journal as PriorJournal, Gate as PriorGate, Budget
from runtime_accounting import save, require


class Journal(PriorJournal):
    def progress(self,force=False):
        now=time.monotonic()
        if not force and now-self.last_progress<2:return
        if self.phase!='cleanup' and not force:
            require(shutil.disk_usage(self.out).free>=self.plan['minimum_remaining_disk_bytes'],
                    'Evidence reserve reached; preserve work, no retry')
        save(self.out/'progress.json',dict(phase=self.phase,elapsed_s=now-self.start,
            macro_completed=self.macros,macro_cap=250,public_steps_completed=self.formal_steps,
            public_steps_cap=25,macro_percent=100*self.macros/250,
            trials_completed=self.trials,resolution=self.resolution,trial_microsteps_completed=self.micro_done,
            integration_budget_used=self.counts.get('integrations_attempted',0),
            integration_budget_cap=self.caps['integrations'],counts=self.counts,pending=dict(self.pending),
            percentage_scope='250 new full-path macros; not overall Stage12 completion',
            original_deadlines=self.plan['original_deadlines'],deadline_reset=False,
            original_native_points='2/5',PPO=0,cloud_training=0),durable=True)
        self.last_progress=now


class Gate(PriorGate):
    def limited(self,label,limit,native,check=None):
        require(label in self.caps,'Undeclared callable operation: '+label)
        def call(*args,**kwargs):
            if check is not None:check(args,kwargs)
            return self.counted(label,lambda:native(*args,**kwargs),cleanup=label=='Recorder_close')
        return call
