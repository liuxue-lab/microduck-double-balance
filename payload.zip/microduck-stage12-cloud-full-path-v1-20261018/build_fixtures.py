"""Offline fixture construction. No simulator import or runtime invocation."""
import argparse
import hashlib
import json
import sys
from pathlib import Path
import numpy as np
from convex_reference import geometry

ROOT=Path(__file__).resolve().parent


def build(candidate,static_inputs,history):
    sys.path.insert(0,str(candidate/'baseline/g11/accepted'))
    from kinematic_precision import fk
    with np.load(ROOT/'source-reference/head-geometry.npz') as z:vertices=z['vertices']
    with np.load(ROOT/'source-reference/convex-hull.npz') as z:facets=z['facets']
    with np.load(ROOT/'source-reference/kinematics-reference.npz') as z:reference={k:z[k] for k in z.files}
    poses=[];meta=[]
    with np.load(static_inputs) as z:
        for i,(p,r) in enumerate(zip(z['position'],z['rotation'],strict=True)):
            poses.append((p.astype(float),r.astype(float)));meta.append(dict(kind='previous_static70',index=i))
    for path in sorted(history.rglob('record-00001-data.npz')):
        with np.load(path,allow_pickle=False) as z:q=z['Data.qpos'][0].astype(float)
        poses.append(fk(q,reference));meta.append(dict(kind='historical_initial_path',path=str(path.relative_to(history)),source_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    for face in (100,798,1500,3000):
        a,b,c=vertices[facets[face]].astype(float)
        normal=np.cross(b-a,c-a);normal/=np.linalg.norm(normal)
        for gap in (1e-6,-1e-6,1e-10):
            center=(a+b+c)/3+normal*(.019999999552965164+gap)
            poses.append((np.array([center,[0.,0.,0.]]),np.array([np.eye(3),np.eye(3)])))
            meta.append(dict(kind='constructed_face_query',facet=face,requested_offset_from_radius=gap))
    center=vertices.astype(float).mean(0)
    poses.append((np.array([center,[0.,0.,0.]]),np.array([np.eye(3),np.eye(3)])))
    meta.append(dict(kind='interior_query'))
    require_count=len(poses)
    assert 70<require_count<=128
    values=np.array([geometry(vertices,facets,p,r,.019999999552965164) for p,r in poses])
    np.savez_compressed(ROOT/'source-reference/hull-fixtures.npz',positions=np.array([p for p,r in poses]),
        rotations=np.array([r for p,r in poses]),expected=values)
    report=dict(count=require_count,fixtures=meta,vertex_fast_path=int(np.sum(values[:,0]>=0)),
        hull_edge=int(np.sum((values[:,0]<0)&(values[:,12]==1))),hull_face=int(np.sum((values[:,0]<0)&(values[:,12]==2))),
        inside=int(np.sum(values[:,13]==1)),native_calls=0,
        historical_evidence_is_not_corrected_rollout_acceptance=True)
    (ROOT/'validation/hull-fixtures.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='fixtures'},indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--candidate',type=Path,required=True)
    p.add_argument('--static-inputs',type=Path,required=True);p.add_argument('--history',type=Path,required=True)
    a=p.parse_args();build(a.candidate,a.static_inputs,a.history)
