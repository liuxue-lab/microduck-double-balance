"""Every declared callable has paired WAL records; no budget rollback or retry."""
import time
import json
from runtime_accounting import Journal as BaseJournal, make_classes, require, save
from macro_state_bridge import MacroBudget
BaseGate, _ = make_classes()

class Journal(BaseJournal):
    def __init__(self, out, counts, caps, plan):
        self.plan = plan; self.trials = 0; self.resolution = None
        self.micro_done = 0; self.collection_complete = False; self.wal_bytes = 0
        super().__init__(out, counts, caps)
    def event(self,kind,label,number,**extra):
        size=len((json.dumps(dict(seq=self.seq+1,kind=kind,label=label,number=number,**extra),sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode())
        require(self.wal_bytes+size<=self.plan['wal_max_bytes'],'Durable WAL byte cap reached; preserve incomplete calls')
        super().event(kind,label,number,**extra);self.wal_bytes+=size
    def progress(self, force=False):
        now = time.monotonic()
        if not force and now-self.last_progress < 2: return
        save(self.out/'progress.json', dict(phase=self.phase, elapsed_s=now-self.start,
            trials_completed=self.trials, trial_cap=6, resolution=self.resolution,
            trial_microsteps_completed=self.micro_done,
            trial_percent=None if self.resolution is None else 100*self.micro_done/self.resolution,
            integration_budget_used=self.counts.get('integrations_attempted',0),
            integration_budget_cap=1504, counts=self.counts, pending=dict(self.pending),
            percentage_scope='Current resolution trial only; integration cap is consumption, not completion',
            collection_complete=self.collection_complete, native_points_accepted=2, native_points_total=5,
            original_deadlines=self.plan['original_deadlines'], deadline_reset=False,
            PPO=0, cloud_training=0), durable=True)
        self.last_progress = now
    def close(self):
        if self.closed:return
        super().close()
        path=self.out/'accounting-review.json'
        row=json.loads(path.read_text())
        row.update(full_per_kernel_persistence=True,WAL_bytes=self.wal_bytes,nested_counter_rule='Every declared call has paired durable WAL; unpaired calls remain pending after loss.')
        save(path,row,durable=True)

class Gate(BaseGate):
    def __init__(self, counts, journal, sync, caps, *, native_stop_utc, total_stop_utc):
        super().__init__(counts,journal,sync,caps)
        self.native_stop_utc, self.total_stop_utc = native_stop_utc, total_stop_utc
        self.deadline = time.monotonic()+max(0,native_stop_utc-time.time())
        self.total_deadline = time.monotonic()+max(0,total_stop_utc-time.time())
    def boundary(self, cleanup=False):
        wall = self.total_stop_utc if cleanup else self.native_stop_utc
        mono = self.total_deadline if cleanup else self.deadline
        require(time.time()<wall and time.monotonic()<mono, 'New IVP window reached; preserve, no retry')
    def counted(self,label,native,*,synchronize=True,cleanup=False):
        require(label in self.caps, 'Undeclared callable: '+label)
        self.boundary(cleanup)
        number = self.counts.get(label+'_attempted',0)+1
        require(number<=self.caps[label], 'Call cap reached: '+label)
        self.journal.begin(label,number); self.counts[label+'_attempted']=number; t=time.monotonic()
        try:
            value=native()
            if synchronize: self.sync()
            self.journal.end(label,number)
            self.counts[label+'_completed']=self.counts.get(label+'_completed',0)+1
            self.boundary(cleanup)
            return value
        finally:
            row=self.timings.setdefault(label,dict(calls=0,inclusive_s=0.))
            row['calls']+=1; row['inclusive_s']+=time.monotonic()-t
            self.journal.progress()
    def limited(self,label,limit,native,check=None):
        require(label in self.caps,'Undeclared callable operation: '+label)
        def call(*args,**kwargs):
            if check is not None: check(args,kwargs)
            return self.counted(label,lambda:native(*args,**kwargs))
        return call

class Budget(MacroBudget):
    delegated=frozenset(('GPU_forward','sense','Scene_write','Scene_update','Action_apply','Metrics_substep'))
    def __init__(self, limits, gate):
        super().__init__(limits,counts=gate.counts,persist=gate.journal.progress,sync=gate.sync,deadline=gate.deadline)
        self.gate=gate
    def reserve(self,**cost):
        self.gate.boundary(); return super().reserve(**cost)
    def run(self,name,fn):
        self.reserve(**{name:1})
        if name in self.delegated:
            before=tuple(self.counts.get(name+'_'+k,0) for k in ('attempted','completed'))
            value=fn()
            require(tuple(self.counts.get(name+'_'+k,0) for k in ('attempted','completed'))==tuple(v+1 for v in before), 'Delegated accounting mismatch: '+name)
            return value
        return self.gate.counted(name,fn)
