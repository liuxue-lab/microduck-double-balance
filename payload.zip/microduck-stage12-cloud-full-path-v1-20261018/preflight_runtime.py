"""Check installed versions and 219 frozen source pins without native imports."""
import importlib.util
import sys
from static_common import require


def verify(candidate, project):
    native_modules = ('numpy', 'torch', 'warp', 'mujoco', 'mujoco_warp', 'mjlab')
    before = set(sys.modules)
    for name in native_modules:
        require(importlib.util.find_spec(name) is not None,
                'Missing ' + name + '; use the existing workspace/.venv/bin/python')
    source = candidate / 'baseline/g11'
    sys.path[:0] = [str(source), str(source / 'accepted'), str(source / 'host-candidate')]
    from worker_g11 import verify_sources
    pins = verify_sources(project)
    require(not any(name in sys.modules and name not in before for name in native_modules),
            'Source preflight unexpectedly imported native dependencies')
    return dict(status='PINNED_RUNTIME_SOURCE_PREFLIGHT_PASS', source_files=len(pins),
                native_calls=0, native_dependencies_imported=False)
