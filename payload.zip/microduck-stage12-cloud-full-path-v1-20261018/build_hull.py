"""Offline hull proposal plus exact integer support and manifold certificate.

SciPy is used here only to propose indices. No runtime dependency is added.
Every original float32 vertex is an exact dyadic rational; all facet-side
checks below are exact Python integers, with no geometric epsilon.
"""
import hashlib
import json
from collections import Counter
from pathlib import Path
import numpy as np
from scipy.spatial import ConvexHull

ROOT = Path(__file__).resolve().parent


def build():
    with np.load(ROOT/'source-reference/head-geometry.npz', allow_pickle=False) as z:
        v = z['vertices']
    ratios = [float(x).as_integer_ratio() for x in v.flat]
    scale = max(d for _, d in ratios)
    integers = np.array([n*(scale//d) for n,d in ratios], dtype=object).reshape(v.shape)
    proposed = ConvexHull(v.astype(np.float64)).simplices
    center = np.sum(integers, axis=0)
    facets = []
    for triangle in proposed:
        i,j,k = map(int, triangle)
        a,b,c = integers[[i,j,k]]
        u,w = b-a,c-a
        n = np.array([u[1]*w[2]-u[2]*w[1],u[2]*w[0]-u[0]*w[2],u[0]*w[1]-u[1]*w[0]],dtype=object)
        assert any(n), 'Degenerate proposed facet'
        orientation = sum(n*(center-len(v)*a))
        assert orientation != 0, 'Hull has no strict interior witness'
        if orientation > 0:
            j,k = k,j
            n = -n
        offsets = (integers[:,0]-a[0])*n[0]+(integers[:,1]-a[1])*n[1]+(integers[:,2]-a[2])*n[2]
        assert max(offsets) == 0 and min(offsets) < 0, 'Qhull proposal violates exact supporting plane'
        f = (i,j,k)
        at = f.index(min(f)); facets.append(f[at:]+f[:at])
    facets = np.array(sorted(facets), np.int32)
    edges = Counter()
    for a,b,c in facets.tolist():
        edges.update(((a,b),(b,c),(c,a)))
    assert all(n == 1 and edges[b,a] == 1 for (a,b),n in edges.items()), 'Not a closed oriented manifold'
    vertices = set(facets.ravel().tolist())
    assert len(vertices)-len(edges)//2+len(facets)==2, 'Hull Euler characteristic differs'
    adjacency={i:set() for i in vertices}
    for a,b in edges:adjacency[a].add(b)
    reached=set();pending=[next(iter(vertices))]
    while pending:
        i=pending.pop()
        if i not in reached:reached.add(i);pending.extend(adjacency[i]-reached)
    assert reached == vertices, 'Disconnected hull'
    path=ROOT/'source-reference/convex-hull.npz'
    np.savez_compressed(path,facets=facets)
    report=dict(status='EXACT_DYADIC_CONVEX_HULL_CERTIFIED',vertices=len(v),hull_vertices=len(vertices),
        facets=len(facets),oriented_edges=len(edges),connected=True,euler_characteristic=2,
        dyadic_scale=str(scale),facet_vertex_exact_checks=len(facets)*len(v),
        vertices_sha256=hashlib.sha256(v.tobytes()).hexdigest(),
        facets_sha256=hashlib.sha256(facets.tobytes()).hexdigest(),
        geometric_epsilon=0,scipy_only_proposes_indices=True,native_calls=0)
    (ROOT/'validation/exact-hull-certificate.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':build()
