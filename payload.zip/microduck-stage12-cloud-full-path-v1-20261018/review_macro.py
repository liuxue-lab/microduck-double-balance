"""Independent NumPy reconstruction of one macro; bounded memory across the run."""
import gzip
import hashlib
import json
from pathlib import Path
import numpy as np
from static_common import read,require


def digest(raw):return hashlib.sha256(raw).hexdigest()
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()


def geometry_check(row,vertices,facets,radius):
    from convex_reference import geometry
    expected=geometry(vertices,facets,np.asarray(row['position']),np.asarray(row['rotation']),radius)
    result=np.asarray(row['values']);require(result.shape==(16,) and np.isfinite(result).all(),'Geometry vector differs')
    require(result[10]==1 and result[13]==expected[13] and (result[3]<0)==(expected[3]<0)
            and np.max(abs(result[2:4]-expected[2:4]))<1e-13
            and np.max(abs(result[4:10]-expected[4:10]))<1e-10,'Independent hull geometry differs')
    if expected[0]>=0:require(result[0]==expected[0] and result[1]>=0,'v2 fast-path certificate differs')
    m=row['mutation'];require(m['other_contact_fields_byte_identical']==16 and len(m['other_fields_sha256'])==16
        and m['new_target']==int(result[3]<0) and m['new_contacts']==m['old_contacts']-m['old_target']+m['new_target'],
        'Contact mutation roster/count differs')
    if m['new_target']:
        t=m['target'];require(t['geom']==[84,49] and t['worldid']==0 and t['dist']==float(np.float32(result[3])),
                             'Published contact pair/distance differs')
        require(np.asarray(t['pos'],np.float32).tobytes()==result[7:10].astype(np.float32).tobytes()
                and np.linalg.norm(np.asarray(t['frame'][0])-result[4:7])<1e-6,'Published point/normal differs')
    else:require(m['target'] is None,'Noncontact has a target')
    return result


def audit_macro(n,geometry_rows,kref,vertices,facets,radius,proofs,result):
    from ground_scalar_contract import brackets
    from convergence_contract import ContactIntegral,PAIRS
    from packed_contact_observer import observe,occupancy
    from dynamic_driver import assess_ivp
    from batch_position_candidate import BatchPositionAccumulator
    from review_kinematics import expected_pose,verify_pose,encoded_physical
    from clock_contract import TickClock
    from kinematic_precision import FIELDS
    from static_common import ROOT
    model_pins=read(ROOT/'origin/macro-68/raw/record-00001-snapshot.json')['model_hashes']
    n=Path(n);events=[read(f) for f in sorted((n/'raw').glob('record-*.json')) if not f.name.endswith('-snapshot.json')]
    trials={e['row']['trial']:e['row'] for e in events if e['kind']=='trial_complete'}
    starts={e['row']['trial']:e['row'] for e in events if e['kind']=='trial_start'}
    require(list(trials)==list(starts)==list(range(1,len(trials)+1)),'Incomplete trial schedule')
    replay=[i for i,r in starts.items() if r['role']=='replay'];require(len(replay)==1 and replay[0]==len(starts),'Unique final replay missing')
    last=replay[0];accepted=starts[last]['resolution'];tiers=[32,64,128,256,512]
    require(accepted in tiers[1:] and [starts[i]['resolution'] for i in starts]==tiers[:tiers.index(accepted)+1]+[accepted],
            'Unexpected or unnecessary refinement trial')
    expected_roles=['estimate','candidate']+['retry']*(len(starts)-3)+['replay']
    require([starts[i]['role'] for i in starts]==expected_roles,'Trial roles differ')
    snapshots=0;initial=None;initial_q=None;endpoint_raw={};snapshot_by_trial={};committed=None
    for event in events:
        prefix='record-%05d'%event['sequence'];sf=n/'raw'/(prefix+'-snapshot.json')
        if not sf.is_file():continue
        snap=read(sf)
        require(all(snap['model_hashes']['Model.'+k]==model_pins['Model.'+k] for k in FIELDS),
                'Live macro kinematic Model changed from the pinned reference')
        with np.load(n/'raw'/(prefix+'-owners.npz'),allow_pickle=False) as z:owners={k:z[k].copy() for k in z.files}
        require(set(owners)==set(snap['owners']),'Owner snapshot roster differs')
        for name,a in owners.items():
            pin=snap['owners'][name];require(digest(a.tobytes())==pin['sha256'] and list(a.shape)==pin['shape']
                and str(a.dtype)==pin['dtype'],'Owner snapshot bytes differ')
        with np.load(n/'raw'/(prefix+'-data.npz'),allow_pickle=False) as z:raw={k:z[k].copy() for k in z.files}
        require(set(raw)==set(snap['Data']) and len(raw)==114,'Raw Data roster differs')
        for name,a in raw.items():require(digest(a.tobytes())==snap['Data'][name]['sha256'] and np.isfinite(a).all(),'Data bytes/value differ')
        if event['kind']=='macro_start':
            require(initial is None,'Duplicate macro start');initial=snap;initial_q=raw['Data.qpos'].copy();tick=event['row']['ticks'][0]
            require(raw['Data.time'].tobytes()==np.array([TickClock(tick).published],np.float32).tobytes(),'Macro input clock differs')
        if event['kind']=='rollback':
            require(initial is not None and all(snap[k]==initial[k] for k in
                ('Data','owners','owner_scalars','owner_topology','global_rng','model_hashes')),'Rollback is not exact')
        if event['kind'] in ('trial_complete','trial_physics_complete'):
            require(observe(raw,state_generation=0,solved_generation=0)==event['row']['endpoint_contacts'],'Endpoint contact decoding differs')
        if event['kind']=='trial_complete':
            t=event['row'];record=json.loads(t['endpoint_record']);hashes={k:v['sha256'] for k,v in snap['Data'].items()}
            require(digest(t['endpoint_record'].encode())==t['endpoint_sha256'] and record['data']==hashes==t['numeric_Data_hashes']
                    and record['model']==snap['model_hashes'],'Endpoint not bound to raw state')
            endpoint_raw[t['trial']]={k:raw['Data.'+k] for k in ('qpos','qvel')};snapshot_by_trial[t['trial']]=snap
        if event['kind']=='commit_prepared':committed=snap
        snapshots+=1
    require(initial is not None and committed is not None,'Missing input/publication snapshot')
    groups={};rk_digest=hashlib.sha256();rk_bytes=0
    with gzip.open(n/'rk-stages.jsonl.gz','rb') as stream:
        for line in stream:
            rk_digest.update(line);rk_bytes+=len(line);r=json.loads(line);groups.setdefault(r['trial'],[]).append(r)
    stream_index=read(n/'rk-stream-index.json')
    require(rk_digest.hexdigest()==stream_index['uncompressed_sha256'] and rk_bytes==stream_index['uncompressed_bytes']
            and sum(map(len,groups.values()))==stream_index['records'] and set(groups)==set(trials),'RK stream differs')
    worlds={};stage_lookup={};pose_lookup={};stage_rows=0
    for trial,rows in groups.items():
        end=trials[trial];res=end['resolution'];require(len(rows)==res,'Incomplete integration trace')
        acc=BatchPositionAccumulator(initial_q.copy(),np.ones(1,np.bool_));before=initial_q.copy()
        integral=ContactIntegral();samples=[];chain=hashlib.sha256()
        for i,row in enumerate(rows):
            require(row['micro_index']==i and row['resolution']==res and len(row['stages'])==4,'Microstep order differs')
            compact=[]
            for k,stage in enumerate(row['stages']):
                require(stage['stage']==k and len(stage['full_Data_hashes'])==114,'Stage roster differs')
                for key in ('qpos','qvel','qacc'):
                    require(digest(np.asarray(stage[key],np.float32).tobytes())==stage['full_Data_hashes']['Data.'+key],'Stage primary hash differs')
                if k==0:
                    require(np.asarray(stage['qpos'],np.float32).tobytes()==before.tobytes(),'Microstep input state differs')
                    samples.append(occupancy(stage['contacts'][0],PAIRS))
                converted={'contact_force_rows':[dict(geoms=c['geom'],raw_solver_forces=c['raw_solver_rows'],distance_m=c['distance_m']) for c in stage['contacts'][0]]}
                integral.observe(converted,k,float(np.float32(.002/res)))
                compact.append({key:v for key,v in stage.items() if key not in ('qpos','qvel','qacc','position_correction')})
                stage_lookup[(trial,4*i+k)]=stage;stage_rows+=1
                pose_lookup[(trial,4*i+k)]=expected_pose(np.asarray(stage['qpos'],np.float32),acc.value.copy(),float(np.float32(.002/res)),k,
                    None if k==0 else np.asarray(row['stages'][k-1]['qvel'],np.float32),i)
            require(digest(canonical(compact))==row['stage_sha256'],'RK stage digest differs');chain.update(bytes.fromhex(row['stage_sha256']))
            native=np.asarray([row['correction'][0]['native_qpos']],np.float32)
            velocity=np.asarray([s['qvel'] for s in row['stages']],np.float32)
            corrected,_=acc.advance(before,velocity,native,float(np.float32(.002/res)),np.ones(1,np.bool_))
            require(corrected.tobytes()==np.asarray(row['post_integrator']['qpos'],np.float32).tobytes(),'Original position correction differs')
            before=corrected
        pose_lookup[(trial,4*res)]=expected_pose(before,acc.value.copy(),float(np.float32(.002/res)),None,None,res)
        require(chain.hexdigest()==end['stage_sha256'],'Trial stage digest differs')
        for key in ('qpos','qvel'):
            raw=endpoint_raw[trial][key]
            require(raw[0].tobytes()==np.asarray(end['worlds'][0]['endpoint'][key],np.float32).tobytes()
                and raw.tobytes()==np.asarray(rows[-1]['post_integrator'][key],np.float32).tobytes(),'Assessed endpoint differs from integrated raw state')
        samples.append(occupancy(end['endpoint_contacts'][0],PAIRS))
        world=dict(resolution=res,endpoint=end['worlds'][0]['endpoint'],event_samples=samples,brackets=brackets(samples,res),integral=integral.result())
        require(world==end['worlds'][0],'Events/integrals differ');worlds[trial]=world
    pose_digests={};seen=set();forward_count=0
    for row in geometry_rows:
        require(row['phase'] in ('trial','commit') and not row.get('certificate_failed_before_mutation'),'Unexpected geometry phase/failure')
        key=(row['trial'],row['trial_forward'] if row['phase']=='trial' else 4*row['resolution'])
        unique=(row['phase'],*key);require(unique not in seen and key in pose_lookup,'Duplicated/unbound forward');seen.add(unique)
        physical=verify_pose(row,pose_lookup[key],kref)
        if row['phase']=='trial':pose_digests.setdefault(row['trial'],hashlib.sha256()).update(encoded_physical(physical))
        g=geometry_check(row,vertices,facets,radius)
        stage=stage_lookup.get(key) if row['phase']=='trial' else None
        if stage:
            for name in ('qpos','qvel','time','ctrl'):require(row['primary_sha256'][name]==stage['full_Data_hashes']['Data.'+name],'Geometry/RK binding differs')
            target=[c for c in stage['contacts'][0] if set(c['geom'])=={49,84} and c['constraint']]
            require(len(target)==int(g[3]<0),'Solved stage occupancy differs')
            if target:require(target[0]['distance_m']==float(np.float32(g[3])),'Solved stage distance differs')
        else:
            snap=committed if row['phase']=='commit' else snapshot_by_trial[row['trial']]
            for name in ('qpos','qvel','time','ctrl'):require(row['primary_sha256'][name]==snap['Data']['Data.'+name]['sha256'],'Endpoint/publication geometry binding differs')
        forward_count+=1
    require(forward_count==sum(4*t['resolution']+1 for t in trials.values())+1,'Per-macro forward coverage differs')
    decisions=[]
    for event in events:
        if event['kind']!='decision':continue
        row=event['row'];ids=[i for i,t in starts.items() if t['resolution']==row['resolution'] and t['role']!='replay']
        require(len(ids)==1,'Decision identity differs');trial=ids[0]
        def typed(w):return {**w,'endpoint':{k:np.asarray(v,np.float32) for k,v in w['endpoint'].items()}}
        computed=assess_ivp(typed(worlds[trial-1]),typed(worlds[trial]))
        require(computed==row['worlds'][0]['original'],'Original decision recomputation differs');decisions.append(computed)
    require(decisions and decisions[-1]['accepted'] and not any(d['accepted'] for d in decisions[:-1]),'First passing tier not respected')
    require(trials[last-1]['endpoint_record']==trials[last]['endpoint_record'] and trials[last-1]['stage_sha256']==trials[last]['stage_sha256'],
            'Mandatory physical/owner replay differs')
    require(len(proofs)==len(trials),'Kinematic trial roster differs')
    for proof in proofs:
        t=proof['trial'];require(proof['resolution']==trials[t]['resolution'] and proof['role']==trials[t]['role']
            and proof['forwards']==4*trials[t]['resolution']+1 and pose_digests[t].hexdigest()==proof['kinematic_sha256'],
            'Kinematic trial proof differs')
    require(pose_digests[last-1].hexdigest()==pose_digests[last].hexdigest(),'Kinematic replay differs')
    count=sum(map(len,groups.values()))
    require(result['replayed'] and result['mandatory_exact_replay'] and result['accepted_resolution']==accepted
            and result['actual_integrations']==count and result['actual_trial_count']==len(trials)
            and result['public_ticks']==[tick+1] and result['accepted_stage_sha256']==trials[last]['stage_sha256'],'Macro publication summary differs')
    require(committed['Data']['Data.time']['sha256']==digest(np.asarray([TickClock(tick+1).published],np.float32).tobytes()),'Published clock differs')
    return dict(integrations=count,forwards=forward_count,RK_stages=stage_rows,snapshots=snapshots,trials=len(trials),
        accepted_resolution=accepted,input_tick=tick,public_tick=tick+1,
        input_primary={k:initial['Data']['Data.'+k]['sha256'] for k in ('qpos','qvel','time')},
        output_primary={k:committed['Data']['Data.'+k]['sha256'] for k in ('qpos','qvel','time')})
