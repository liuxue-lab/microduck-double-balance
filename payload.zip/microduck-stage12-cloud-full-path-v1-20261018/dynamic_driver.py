"""One independent corrected IVP. Original local and contact criteria are unchanged."""
from integration.refined_adaptive import RefinedAdaptive
from integration.refinement_contract import TIERS, macro_cost
from batch_position_candidate import assess_cohort
from ground_scalar_contract import assess
from convergence_contract import compare
from replay_diagnostics import compare as compare_replay
from lifecycle_support import require

def assess_ivp(coarse,fine):
    local=assess(coarse,fine)
    def endpoint(w):
        return dict(tick=1,native_time_s=.138,**w['endpoint'])
    contact=compare([endpoint(coarse)],[endpoint(fine)],coarse['integral'],fine['integral'],expected_macros=1,max_resolution=512)
    return dict(**{k:v for k,v in local.items() if k not in ('accepted','reasons')},
        accepted=local['accepted'] and contact['passed'],
        reasons=local['reasons']+([] if contact['passed'] else ['original_state_contact_integral_limits']),
        state_contact_comparison=contact)

class DynamicIVP(RefinedAdaptive):
    def __init__(self,bridge,engine,emit):
        super().__init__(bridge,engine,(0,),emit);self.ticks=(68,)
    def advance(self):
        require(self.phase=='idle' and self.bridge.phase=='idle' and self.commits==0 and self.ticks==(68,), 'One IVP only; no retry')
        self.bridge.budget.reserve(**macro_cost())
        require(self.bridge.sim.wp_data.time.numpy().tobytes()==self.published.tobytes(),'Archived physical boundary clock differs')
        self.phase='running';tx=self.transaction
        try:
            self.bridge.checkpoint();tx.begin()
            self.record('macro_start',numeric_Data_hashes=self.bridge.saved.data.fingerprint(),independent_IVP=True,old_owner_resumed=False)
            previous=self._trial(32,'estimate');self._rollback('discard_estimator')
            for n in TIERS[1:]:
                tx.begin();candidate=self._trial(n,'candidate' if n==64 else 'retry')
                decision=assess_cohort(previous['worlds'],candidate['worlds'],(0,),assess_ivp)
                self.record('decision',resolution=n,**decision)
                ticket=tx.decide(decision,candidate['endpoint'],replay_required=True,stage_trace_digest=candidate['stage_sha256'])
                if decision['accepted']:
                    self._rollback('mandatory_accepted_replay')
                    replay=self._trial(n,'replay')
                    self.last_replay_comparison=compare_replay(candidate,replay)
                    self.record('replay_comparison',resolution=n,**self.last_replay_comparison)
                    ticket=tx.replay_complete(replay['endpoint'],stage_trace_digest=replay['stage_sha256'])
                    self.record('exact_replay',resolution=n,full_numeric_Data_and_held_owners=True,sensor_values_and_schema=True,physical_stage_hashes=True)
                    self.accepted_trial=replay
                    result=self._commit(ticket,replay,decision)
                    result.update(replayed=True,mandatory_exact_replay=True,actual_trial_count=self.trial_serial,
                        actual_integrations=sum(t for t in TIERS if t<=n)+n,accepted_stage_sha256=replay['stage_sha256'],
                        independent_corrected_IVP=True,original_campaign_acceptance_credit=False)
                    return result
                self.rejections.append(decision);self._rollback('reject_corrected_candidate');previous=candidate
            raise RuntimeError('Declared tier512 failed; initial IVP restored; no higher tier or automatic retry')
        except BaseException as exc:
            self.last_failure=dict(error=repr(exc),transaction_phase=tx.phase,bridge_phase=self.bridge.phase,commits=self.commits,
                replay_comparison=getattr(self,'last_replay_comparison',None))
            if self.bridge.phase=='trial' and tx.phase!='idle' and not self.bridge.budget.counts.get('public_clock_write_attempted',0):
                try:self.last_failure['rollback_proof']=self._rollback('exception_abort')
                except BaseException as error:self.last_failure['restore_error']=repr(error)
            self.phase='stopped';tx.ticket=None
            if self.bridge.phase=='trial':self.bridge.close()
            raise
