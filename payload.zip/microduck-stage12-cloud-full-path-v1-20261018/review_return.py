"""Read immutable Git evidence; never execute a native dependency or a trial."""
import argparse
import gzip
import hashlib
import itertools
import json
import sys
from pathlib import Path
import numpy as np
from static_common import read,require,sha


def wire(row,shape,dtype=None):
    require(row.get('_tensor') is True and row['shape']==shape,'IPC tensor envelope differs')
    a=np.asarray(row['values'],dtype=row['dtype']).reshape(shape)
    require(np.isfinite(a).all() and (dtype is None or str(a.dtype)==dtype),'IPC dtype/value differs')
    return a


def audit(root,candidate):
    root,candidate=Path(root).resolve(),Path(candidate).resolve()
    p,e=root/'diagnostic-package',root/'evidence';n=e/'native/owner-0'
    manifest=read(root/'transport/MANIFEST.json');plan=read(p/'plan.json');idx=read(e/'evidence-index.json')
    require(sha(e/'evidence-index.json')==manifest['evidence_index_sha256'] and sha(p/'MANIFEST.json')==manifest['package_manifest_sha256'],
            'Return evidence/package identity differs')
    for directory,pins in ((e,idx['files']),(p,read(p/'MANIFEST.json')['files'])):
        for name,pin in pins.items():
            if directory==p and name=='frozen-inputs.zip':continue
            f=directory/name;require(f.resolve().is_relative_to(directory) and not f.is_symlink()
                and f.stat().st_size==pin['bytes'] and sha(f)==pin['sha256'],'Returned bytes differ: '+name)
    for name,pin in read(p/'candidate-pins.json').items():require(sha(candidate/name)==pin,'Frozen review source differs: '+name)
    sys.path[:0]=[str(p),str(candidate),str(candidate/'baseline/g11'),str(candidate/'baseline/g11/accepted'),str(candidate/'baseline/g11/host-candidate')]
    from operation_contract import validate_caps
    from runtime_accounting import review_ledger
    from kinematic_precision import reference_model,fk
    from review_macro import audit_macro,geometry_check,digest
    validate_caps(candidate,plan)
    result=read(e/'result.json');campaign=read(e/'full-path-report.json') if (e/'full-path-report.json').is_file() else {}
    r=read(n/'native-report.json') if (n/'native-report.json').is_file() else {}
    ledger=review_ledger(n/'native-ledger.jsonl') if (n/'native-ledger.jsonl').is_file() else None
    require(ledger==result['ledger'],'Final WAL review differs')
    require(result['original_deadlines']==plan['original_deadlines'] and result['canonical_before']==plan['canonical_integrations_before'],
            'Historical deadline/counts changed')
    require(result['PPO']==result['cloud_training']==0 and not result['automatic_push'] and not result['automatic_PR']
            and not result['automatic_merge'] and not result['automatic_power_actions'],'Unauthorized operation')
    if ledger is not None:
        aggregate={k:plan['canonical_integrations_before'][k]+ledger['integration_'+k]
            for k in ('attempted_lower','attempted_upper','completed_lower','completed_upper')}
        require(result['canonical_after_interval']==aggregate,'Historical attempted/completed interval changed')
        for name,count in ledger['attempts'].items():
            require(name in plan['caps'] and count<=plan['caps'][name] and ledger['completed'].get(name,0)<=count,'WAL exceeds declared cap')
    if result['status']!='FULL_PATH_COMPLETE_REVIEW_REQUIRED':
        return dict(status='FULL_PATH_FAILURE_ARCHIVE_VERIFIED_NO_ACCEPTANCE',verified_files=len(idx['files']),
            ledger=ledger,native_errors=r.get('errors',campaign.get('errors',[])),canonical_after_interval=result['canonical_after_interval'],
            original_native_points='2/5',native_retry_authorized=False,assistant_native_calls=0,PPO=0,cloud_training=0)
    require(result['returncode']==0 and not result['forced_timeout'] and result['error'] is None
        and r['status']=='STAGE12_NATIVE_CANDIDATE_FINISHED_REVIEW_REQUIRED' and not r['errors']
        and campaign['status']=='FULL_PATH_COMPLETE_REVIEW_REQUIRED','Inconsistent completion')
    require(ledger==r['native_ledger']==campaign['ledger'] and ledger['exact'] and not ledger['pending'],'Incomplete final ledger')
    for name,count in r['counts'].items():
        if name.endswith('_attempted'):
            key=name[:-10];require(count==r['counts'][key+'_completed']==ledger['attempts'].get(key,0)==ledger['completed'].get(key,0),
                                    'Report/WAL mismatch: '+key)
    require(read(n/'source-pins-before.json')==read(n/'source-pins-after.json') and len(read(n/'source-pins-before.json'))==219,'Installed source identity changed')
    require(r['contact']['graph_closed'] and r['env_close']['status']=='FULL_ENV_CLOSE_RETURNED','Owner cleanup failed')
    targets=read(n/'resource-lifetime.json')['targets']
    require(len(targets)==42 and all(t['released'] and t['weakref_dead'] for t in targets),'Native resources not released')
    boot=read(e/'native/owner-0-bootstrap/bootstrap-report.json')
    require(boot['status']=='GUARDED_BOOTSTRAP_CLOSED' and not boot['cleanup_errors'] and read(e/'native/owner-closeout.json')['all_clean'],
            'Guarded child/owner closure failed')
    start=read(e/'started.json');auth=read(n/'started-v1.json')['authorization']
    require(start['native_stop_utc']-start['started_utc']==85500 and start['stop_utc']-start['started_utc']==86400
        and auth['native_stop_utc']==start['native_stop_utc'] and auth['stop_utc']==start['stop_utc'],'New window changed')
    with np.load(p/'source-reference/head-geometry.npz',allow_pickle=False) as z:vertices=z['vertices'].copy()
    with np.load(p/'source-reference/convex-hull.npz',allow_pickle=False) as z:facets=z['facets'].copy()
    radius=read(p/'geometry-contract.json')['radius']
    with np.load(n/'kinematic-model.npz',allow_pickle=False) as z:kmodel={k:z[k].copy() for k in z.files}
    kref=reference_model(kmodel,read(p/'origin/macro-68/raw/record-00001-snapshot.json')['model_hashes'])
    with np.load(n/'hull-fixture-return.npz',allow_pickle=False) as z:returned=z['values'].copy()
    with np.load(p/'source-reference/hull-fixtures.npz',allow_pickle=False) as z:expected=z['expected'].copy()
    require(returned.shape==expected.shape==(98,16) and np.isfinite(returned).all()
        and np.all(returned[:,10]==1) and np.array_equal(returned[:,3]<0,expected[:,3]<0)
        and np.max(abs(returned[:,2:4]-expected[:,2:4]))<1e-13
        and np.max(abs(returned[:,4:10]-expected[:,4:10]))<1e-10,'GPU fixture result differs')
    fixture=read(n/'hull-fixture-review.json')
    require(fixture['count']==98 and not fixture['first_public_reset_started'] and fixture['native_state_unchanged'],'Fixture gate differs')
    proofs=read(n/'kinematic-trials.json')['trials'];require(proofs==r['precise_close']['kinematic_trial_proofs'],'Kinematic proof summary differs')
    per_macro={i:list(rows) for i,rows in itertools.groupby(proofs,key=lambda row:row['macro_index'])}
    geo_hash=hashlib.sha256();geo_bytes=0;geo_count=0;external=0;macros=[]
    def geometry_stream(stream):
        nonlocal geo_bytes,geo_count
        for line in stream:
            geo_hash.update(line);geo_bytes+=len(line);row=json.loads(line);geo_count+=1
            require(row['serial']==geo_count,'Geometry sequence differs');yield row
    with gzip.open(n/'geometry-witness.jsonl.gz','rb') as stream:
        for index,rows in itertools.groupby(geometry_stream(stream),key=lambda row:row['macro_index']):
            if index is None:
                for row in rows:
                    require(row['phase']=='external' and row['kinematics']['mode']=='external_native_pose','External pose phase differs')
                    proof=row['kinematics'];native=np.asarray(proof['qpos_native'],np.float32)
                    q=native[0].astype(np.float64);pos,rot=fk(q,kref)
                    require(proof['qpos_geometry']==q.tolist() and not proof['native_qpos_written'] and not proof['quaternions_changed']
                        and digest(native.tobytes())==row['primary_sha256']['qpos']
                        and np.max(abs(pos-np.asarray(row['position'])))<1e-15
                        and np.max(abs(rot-np.asarray(row['rotation'])))<3e-15,'External FK binding differs')
                    geometry_check(row,vertices,facets,radius);external+=1
            else:
                require(type(index) is int and index==len(macros) and index<250,'Macro geometry order differs')
                directory=n/('macro-%02d'%index);summary=audit_macro(directory,rows,kref,vertices,facets,radius,
                    per_macro[index],read(directory/'macro-result.json'));macros.append(summary)
                print('IndependentMacroReview=%d/250'%(index+1),file=sys.stderr,flush=True)
    require(len(macros)==250 and set(per_macro)==set(range(250)) and geo_count==r['counts']['GPU_forward_completed']
        and geo_hash.hexdigest()==r['precise_close']['sha256'] and geo_bytes==r['precise_close']['raw_bytes'],'Geometry completeness differs')
    require(external==r['precise_close']['external_forwards']<=504 and r['precise_close']['completed_macros']==250
        and r['precise_close']['gpu_fixture_verified'],'Full boundary phase accounting differs')
    require(sum(m['integrations'] for m in macros)==r['counts']['integrations_completed']
        and sum(m['forwards'] for m in macros)+external==geo_count,'Macro/owner accounting differs')
    steps=[read(e/'native'/('public-step-%03d.json'%i)) for i in range(1,26)]
    resets=1;previous_tick=0;previous_primary=None;done=False
    for i,step in enumerate(steps):
        if i==24:resets+=1;previous_tick=0;previous_primary=None
        for m in macros[10*i:10*i+10]:
            require(m['input_tick']==previous_tick,'Public/macro clock continuity differs')
            if previous_primary is not None:require(m['input_primary']==previous_primary,'Public primary state continuity differs')
            previous_tick=m['public_tick'];previous_primary=m['output_primary']
        require(step['index']==i+1,'Public step order differs')
        wire(step['observations']['actor'],[1,61],'float32');wire(step['observations']['critic'],[1,85],'float32')
        wire(step['reward'],[1],'float32');done=bool(wire(step['done'],[1])[0]);t=step['extras']['stage12_transition']
        terminated=bool(wire(t['terminated'],[1],'bool')[0]);truncated=bool(wire(t['truncated'],[1],'bool')[0])
        require(done==(terminated or truncated) and bool(wire(t['bootstrap_mask'],[1],'bool')[0])==(truncated and not terminated)
                and not t['bootstrap_applied'],'Terminal/bootstrap semantics differ')
        wire(t['terminal_observation']['actor'],[1,61],'float32');wire(t['terminal_observation']['critic'],[1,85],'float32')
        if done:resets+=1;previous_tick=0;previous_primary=None
        w=step['witness'];require(w['public_steps']==i+1 and w['macros']==10*(i+1) and w['resets']==resets
            and w['public_tick']==previous_tick,'Public witness differs')
    for name,value in dict(Action_process_action=25,Reward_compute=25,Termination_compute=25,Metrics_compute=25,
        Scene_update=250,Metrics_substep=250,public_clock_write=250,Observation_compute=25+resets).items():
        require(r['counts'][name+'_completed']==value,'Full public manager cadence differs: '+name)
    keys=('counts','rng_sha256','observation_sha256','resets','episode_length')
    cached=read(e/'native/cached-observation-review.json');reset=read(e/'native/explicit-reset-review.json')
    require(all(cached['before'][k]==cached['after'][k] and reset['after'][k]==reset['after_empty'][k] for k in keys)
        and reset['after']['resets']==reset['before']['resets']+1 and reset['after']['public_tick']==0
        and reset['after']['episode_length']==[0],'Cached/explicit/empty reset semantics differ')
    require(not any(x in sys.modules for x in ('torch','warp','mujoco','mujoco_warp','mjlab')),'Offline audit imported native dependency')
    return dict(status='FULL_PATH_DECLARED_SCOPE_INDEPENDENT_REVIEW_PASS',verified_files=len(idx['files']),
        macros=250,public_steps=25,resets=resets,integrations=r['counts']['integrations_completed'],
        GPU_forwards=geo_count,external_forwards=external,RK_stages=sum(m['RK_stages'] for m in macros),
        raw_snapshots=sum(m['snapshots'] for m in macros),exact_replay_macros=250,
        corrected_N1_rollout_steps=24,explicit_reset_post_steps=1,GPU_fixture_cases=98,
        original_native_points='2/5; this separate corrected scope does not rewrite historical acceptance',
        N2_rollout_validated=False,full_500_step_episode_validated=False,training_ready=False,
        canonical_after_interval=result['canonical_after_interval'],assistant_native_calls=0,PPO=0,cloud_training=0)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--return-root',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True)
    a=p.parse_args();print(json.dumps(audit(a.return_root,a.candidate),indent=2,ensure_ascii=False))
