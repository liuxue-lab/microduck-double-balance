"""Execute kernel arithmetic as pure NumPy, plus independent analytic geometry.

This is not a Warp CPU/CUDA compilation or native kernel execution. The actual
GPU compiler and fixture gate remain mandatory on the user's pinned runtime.
"""
import ast
import json
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from scipy.spatial import ConvexHull
from convex_reference import closest

ROOT=Path(__file__).resolve().parent


def source_math():
    functions=[]
    for file,name in (('precise_pose_kernel.py','relative_vertex'),('convex_pose_kernel.py','convex_geometry')):
        tree=ast.parse((ROOT/file).read_text())
        f=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
        f.decorator_list=[];f.returns=None
        for arg in f.args.args:arg.annotation=None
        functions.append(f)
    wp=SimpleNamespace(float64=np.float64,vec3d=lambda *v:np.array(v if v else [0.,0.,0.]),
        vec2d=lambda *v:np.array(v if v else [0.,0.]),tid=lambda:0,
        dot=np.dot,cross=np.cross,min=np.minimum,sqrt=np.sqrt,clamp=np.clip)
    ns={'wp':wp};exec(compile(ast.Module(body=functions,type_ignores=[]),'kernel_math','exec'),ns)
    return ns['convex_geometry']


def verify():
    cube=np.array([[x,y,z] for x in (-1.,1.) for y in (-1.,1.) for z in (-1.,1.)])
    faces=ConvexHull(cube).simplices.copy()
    for f in faces:
        a,b,c=cube[f]
        if np.dot(np.cross(b-a,c-a),a)<0:f[1],f[2]=f[2],f[1]
    cases=[([2.,.2,.3],1.,[-1.,0.,0.]),([2.,2.,0.],np.sqrt(2),[-1/np.sqrt(2),-1/np.sqrt(2),0.]),
           ([2.,2.,2.],np.sqrt(3),[-1/np.sqrt(3)]*3),([.1,.2,.3],-.7,[0.,0.,-1.])]
    for point,distance,normal in cases:
        r=closest(np.array(point),cube,faces)
        assert abs(r['distance']-distance)<1e-14 and np.max(abs(r['normal']-normal))<1e-14
    with np.load(ROOT/'source-reference/head-geometry.npz') as z:v=z['vertices']
    with np.load(ROOT/'source-reference/convex-hull.npz') as z:f=z['facets']
    kernel=source_math();maxima=np.zeros(10);count=0
    with np.load(ROOT/'source-reference/hull-fixtures.npz') as z:
        for p,r,expected in zip(z['positions'],z['rotations'],z['expected'],strict=True):
            result=np.zeros((1,16));kernel(v,f,p[None],r[None],0,len(v),len(f),np.float32(.02),result)
            result=result[0];delta=np.abs(result[:10]-expected[:10])
            assert result[10]==1 and (result[3]<0)==(expected[3]<0) and result[13]==expected[13]
            assert max(delta[2:4])<1e-13 and max(delta[4:10])<1e-10
            if expected[0]>=0:assert result[0]==expected[0] and result[1]>=0
            maxima=np.maximum(maxima,delta);count+=1
    result=dict(status='PURE_NUMPY_KERNEL_MATH_AND_ANALYTIC_CASES_PASS',fixtures=count,
        independent_cube_cases=len(cases),max_abs_length_gap_error=float(np.max(maxima[2:4])),
        max_abs_normal_point_error=float(np.max(maxima[4:10])),
        Warp_CPU_execution=False,CUDA_compilation=False,GPU_execution=False,native_calls=0)
    print(json.dumps(result,indent=2))


if __name__=='__main__':verify()
