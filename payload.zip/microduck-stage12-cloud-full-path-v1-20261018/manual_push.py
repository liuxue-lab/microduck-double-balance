"""User-invoked Git SSH publication. Runtime preparation never calls this file."""
import argparse
import json
import subprocess
from pathlib import Path


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--push',action='store_true');a=p.parse_args()
    root=Path(__file__).resolve().parent;plan=json.loads((root/'PUSH-PLAN.json').read_bytes())
    if not a.push:
        print('仅显示：%d 个证据分卷 + 1 个总索引；显式 --push 才会使用现有 Git SSH。'%len(plan['volumes']))
        return
    for row in [*plan['volumes'],plan['index']]:
        folder=root/row['directory'];marker=folder/'PUSH-DONE.json'
        head=subprocess.check_output(['git','-C',str(folder),'rev-parse','HEAD'],text=True).strip()
        if head!=row['commit']:raise RuntimeError('Local evidence commit changed; preserve all files')
        remote=subprocess.check_output(['git','-C',str(folder),'remote','get-url','origin'],text=True).strip()
        if remote!='git@github.com:liuxue-lab/microduck-double-balance.git':raise RuntimeError('Pinned SSH remote changed')
        if marker.exists():
            if json.loads(marker.read_bytes())['commit']!=head:raise RuntimeError('Push receipt differs')
            print('已完成，跳过：'+row['branch'],flush=True);continue
        subprocess.run(['git','-C',str(folder),'push','origin','HEAD:refs/heads/'+row['branch']],check=True)
        with marker.open('x') as f:json.dump(dict(commit=head,branch=row['branch'],git_returncode=0),f)
    print('Stage12FullPathPush=COMPLETE；总索引分支：'+plan['index']['branch'],flush=True)


if __name__=='__main__':main()
