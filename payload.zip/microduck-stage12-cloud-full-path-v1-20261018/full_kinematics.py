"""v2 compensated FK inside trials; native float64 FK for public/reset forwards."""
import numpy as np
from kinematic_precision import KinematicPrecision, fk
from static_common import require


class FullKinematics(KinematicPrecision):
    def compute(self,boundary):
        if boundary.phase!='external':return super().compute(boundary)
        require(self.engine is None,'Public forward retains an active trial engine')
        native=self.d.qpos.numpy()
        require(native.shape==(1,35) and native.dtype==np.float32 and np.isfinite(native).all(),
                'Public qpos layout differs')
        q=native[0].astype(np.float64);p,r=fk(q,self.reference)
        def upload():
            self.positions.assign(p[None]);self.rotations.assign(r[None])
        self.gate.limited('Kinematic_pose_upload',self.plan['caps']['GPU_forward'],upload)()
        require(self.positions.numpy().tobytes()==p[None].tobytes()
                and self.rotations.numpy().tobytes()==r[None].tobytes(),'Public double FK upload differs')
        return p,r,dict(mode='external_native_pose',qpos_native=native.tolist(),qpos_geometry=q.tolist(),
                        native_qpos_written=False,quaternions_changed=False)
