"""Host-only identities. The historical module name keeps frozen helper imports intact."""
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SCOPE = 'CLOUD_RTX5090_FULL_PATH_V1'
REMOTE = 'git@github.com:liuxue-lab/microduck-double-balance.git'

def require(ok, message):
    if not ok: raise RuntimeError(message)

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()

def read(path): return json.loads(Path(path).read_bytes())

def write(path, value, *, exclusive=False):
    path = Path(path)
    raw = (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)+'\n').encode()
    target = path if exclusive else path.with_name(path.name+'.writing')
    with target.open('xb' if exclusive else 'wb') as f:
        f.write(raw); f.flush(); os.fsync(f.fileno())
    if not exclusive: os.replace(target, path)

def plain(path):
    p = Path(path).absolute()
    require(p == p.resolve() and not p.is_symlink(), 'Symlink path refused: '+str(p))
    return p

def verify_package():
    manifest = read(ROOT/'MANIFEST.json')
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()
              and '__pycache__' not in p.parts and p.suffix != '.pyc' and p != ROOT/'MANIFEST.json'}
    require(actual == set(manifest['files']), 'Package file roster differs')
    for name, pin in manifest['files'].items():
        p = ROOT/name
        require(p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(ROOT)
                and p.stat().st_size == pin['bytes'] and sha(p) == pin['sha256'], 'Package differs: '+name)
    return sha(ROOT/'MANIFEST.json')

def load_run(root):
    root = plain(root); receipt = read(root/'prepared.json'); plan = read(ROOT/'plan.json')
    require(receipt['package_sha256'] == verify_package() and receipt['plan_sha256'] == sha(ROOT/'plan.json'),
            'Prepared package or budget changed')
    require(receipt['run_directory'] == str(root) == plan['run_directory'], 'Run directory changed')
    from frozen_inputs import exact
    exact(root/'inputs', read(ROOT/'frozen-inputs-manifest.json')['files'])
    from operation_contract import validate_caps
    validate_caps(root/'inputs/candidate', plan)
    return root, receipt, plan
