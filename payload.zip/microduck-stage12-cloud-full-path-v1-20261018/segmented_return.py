"""Bounded-memory, lossless transport for full-path evidence of any file size."""
import base64
import hashlib
import io
import json
import zipfile

CHUNK=8*1024**2
VOLUME_RAW=32*1024**2
LIMIT=49*1024**2
MAX_SEGMENTS=1024


def sha(raw):return hashlib.sha256(raw).hexdigest()


def volumes(entries):
    stream=None;archive=None;rows=[];size=0;serial=0;metadata_bytes=2
    def put(name,data):
        # Stable ZIP timestamps make interrupted transfer preparation reproducible.
        info=zipfile.ZipInfo(name,date_time=(2026,10,18,0,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        archive.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=6)
    def begin():
        s=io.BytesIO();return s,zipfile.ZipFile(s,'w',zipfile.ZIP_DEFLATED,compresslevel=6)
    def finish():
        metadata=json.dumps(rows,sort_keys=True,separators=(',',':'))
        if len(metadata.encode())>=2*1024**2:raise RuntimeError('Segment metadata exceeds decoder limit')
        put('segments.json',metadata)
        archive.close();raw=stream.getvalue()
        if len(raw)>LIMIT:raise RuntimeError('Transport volume exceeds immutable 49 MiB limit')
        return raw
    for path,target in entries:
        offset=0
        with path.open('rb') as f:
            while True:
                data=f.read(CHUNK)
                if not data and offset:break
                if archive is None:stream,archive=begin()
                name='segment-%08d.bin'%serial;serial+=1
                put(name,data)
                row=dict(member=name,target=target,offset=offset,bytes=len(data),sha256=sha(data))
                rows.append(row);metadata_bytes+=len(json.dumps(row,sort_keys=True,separators=(',',':')).encode())+1
                size+=len(data);offset+=len(data)
                if size>=VOLUME_RAW or len(rows)>=MAX_SEGMENTS or metadata_bytes>=1024**2:
                    yield finish();stream=archive=None;rows=[];size=0;metadata_bytes=2
                if not data:break
    if archive is not None:yield finish()


def encode_parts(raw):
    for index,start in enumerate(range(0,len(raw),384*1024)):
        yield index,base64.b64encode(raw[start:start+384*1024])+b'\n'
