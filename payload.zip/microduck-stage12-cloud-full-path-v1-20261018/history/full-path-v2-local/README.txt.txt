microduck-double-balance / Stage12 / full-path-v2 / 2026-10-18
本机只做开发、仿真与验证；正式训练仅在云 GPU。当前 PPO=0、cloud_training=0。
状态：编译问题已修复并通过离线真实编译与样本核对，等待本机 GPU 执行验证。
本包不表示 Stage12 已验收完成，不包含训练或自动云电源操作。

现在运行这一条
将同名 PY 与 ZIP 放入 /home/lx/下载，无需解压：
python3 "/home/lx/下载/microduck-stage12-full-path-v2-20261018.py" --run

运行结束后，Git SSH 回传命令在这里
python3 /home/lx/microduck-double-balance/artifacts/double-balance-stage12/full-path-v2/transfer-local-20261018-v2/manual_push.py --push
只在运行结束且显示 LOCAL_GIT_RETURN_PREPARED_NOT_PUSHED 后执行回传。
成功会显示 Stage12FullPathPush=COMPLETE。之后 Codex 从固定 Git commit 检查结果。
回传脚本先推送分卷，再推送总索引；不推送 double-balance、不 PR、不 merge。

刚完成的 v1 核验
总索引分支 stage12-full-path-v1-return-20261018t062129z-7202c3bfe5
总索引 commit b3f7aece6f5b61594f83db9bbf6e16ff9b5395f3
分卷 commit d96978c0d719d74582a7ee2f71547ac35e999177
证据索引 SHA256 7202c3bfe58632cc1157a988628697c0c2b135ffb578ea35bc7882a259ec83b0
完整回传 ZIP SHA256 d4acc0e99cd3245e9ec7d0cfcf11b715e7ed7b519dae62ff8ead4a57c239b763
171 个回传文件（包含证据与执行包）通过逐文件校验。
结果为 FULL_PATH_FAILURE_ARCHIVE_VERIFIED_NO_ACCEPTANCE。
实际构建了单个仿真环境，在 Hull_module_load 编译阶段停止：
WarpCodegenError: Error mutating a constant inside inside a dynamic loop。
public step=0，积分 attempted=0/completed=0，GPU forward=0；没有 PPO/训练。
原总计保持 completed=735352 / attempted=735353，历史差额 1 原样保留。
WAL 的 Hull_module_load attempted=1/completed=0 保留，不能改写为成功。
219 个运行时源码 pin 前后相同；42 个受审计资源已释放，环境/接触图已关闭。
owner 总体仍是失败，不能把资源释放等同为仿真成功；本包不重试旧 v1 槽位。
完整旧回传 ZIP、原索引、启动记录、失败记录、独立审查均在 history/full-path-v1。

本次修复与已完成检查
1. 凸壳内核进入动态循环前将 inside=1 改为 inside=int(1)。
   原来的赋值令 Warp 把 inside 视为编译期常量。除类型声明外数值算法不变。
2. 工厂先保留 FullBoundary 对象再初始化；增加构造早期的清理默认值。
   编译或中间检查抛错时，finally 仍可关闭几何证据流并记录 precise_close。
3. 使用独立的 Warp 1.12.0 环境复现原错误后编译修正版，运行时 context.py
   SHA 与本机回传的固定源码一致。没有安装/更换用户本机环境。
4. 修正凸壳内核及只读位姿依赖的真实 CPU 编译通过；98 个 CPU 几何样本通过。
   最大长度/间隙误差 3.469446951953614e-18 m；法线/接触点差异
   2.220446049250313e-16。另有 NumPy 解释与 4 个解析立方体检查通过。
5. NVIDIA NVRTC 的 compute_120 PTX 离线编译通过。这是实际 CUDA 编译，
   但不代表在 RTX5060 上成功加载或执行；本机 98 个 GPU 样本门仍必须通过。
6. 28 项离线回归检查通过，新增构造中途失败三处注入与证据流关闭检查。
   原阈值拒绝、最大 tier512 停止、强制精确回放、WAL pending 保留、started
   防重跑、窗口不续期、跨卷完整回传、断点传输等检查仍保留。
7. 8062 个冻结 mesh 顶点、7612 个凸壳面、98 个独立样本未改；
   61,367,944 次精确整数支撑半空间验证的原证明完整保留。
   原积分器、接触材料、CCD 配置和 precise_contact_kernel.py 均未改。

这次只验证同一尚未完成的 N1 范围
新的修正版独立槽位：一个 N1 环境，零动作 24 个 public step，
随后显式 reset、empty reset 检查和 1 个 post-reset step。
共 25 step / 250 macro / 0.5 秒仿真时间；保留自然 terminated/truncated 行为。
首次 public reset/任何 RK 积分前，先核对 98 个 GPU 几何样本。
固定 tiers=32/64/128/256/512，首个通过候选必须精确回放。
上限仍为 376000 次积分、1506254 次 GPU forward、28 reset、1 world。
原 event bracket<=25us、midpoint agreement<=62.5us、局部状态与接触积分限值不变。
首次启动至少 32 GiB 可用空间，运行时 8 GiB 剩余空间门仍保留。
--run 显式启动一个新修正槽位：native 窗口 85500 秒，总窗口 86400 秒，
最后 900 秒保留给清理。24 小时是上限，不是预计耗时；可能运行数小时。
原截止 2026-10-17T11:23:14+08:00 / 11:53:14+08:00 完全不变。
v1 已开始窗口与失败证据也不续期、不清除、不挪用。

位置、联网和恢复
源码：/home/lx/microduck-double-balance/workspace
既有 Python：/home/lx/microduck-double-balance/workspace/.venv/bin/python
新仿真目录：/home/lx/microduck-double-balance/artifacts/double-balance-stage12/full-path-v2/local-20261018-v2
新传输目录：/home/lx/microduck-double-balance/artifacts/double-balance-stage12/full-path-v2/transfer-local-20261018-v2
已有 SSH 远端：git@github.com:liuxue-lab/microduck-double-balance.git
运行使用既有 Torch 2.9.1 / MuJoCo 3.10.0 / mujoco-warp 3.8.1 /
Warp 1.12.0 / mjlab 1.3.0 / BAM 1.0.1；不升级、不联网补装依赖。
从旧 dynamic-ivp-v2 inputs 复用并核对 951 个冻结文件，否则使用包内相同文件。
下载和 Git SSH 推送需要联网；准备、编译、仿真、日志、本地 Git 提交不需要联网。
运行中不要并发启动。再次 --run 只能收集已退出进程，不会重新执行 native。
只收集已有结果：
python3 "/home/lx/下载/microduck-stage12-full-path-v2-20261018.py" --collect-only
只校验下载包：
python3 "/home/lx/下载/microduck-stage12-full-path-v2-20261018.py" --verify-only
只读查看日志：
tail -f /home/lx/microduck-double-balance/artifacts/double-balance-stage12/full-path-v2/local-20261018-v2/console.log
回传中断：重新执行本文开头 manual_push.py --push，已完成卷会跳过；不重跑仿真。
Git non-fast-forward/SHA 不符：停止并保留两边，不 force push、不改期望 SHA。
SSH 私钥口令交由既有 SSH/ssh-agent 处理，不写密码、不切 HTTPS/PAT。
若缺少依赖、固定 pin 不匹配、空间不足或已有活动进程，保留记录并停止。

还没解决的项目项
A. 修正后内核的真实 GPU 样本和完整 N1 路径验收，本次就是验证它。
B. 原 native 验收仍为 2/5：n1-pilot、n2-pilot 已完成；
   n1-rollout 原 macro68 失败仍保留；n2-rollout、n1-full-episode 未开始。
   新 N1 结果须独立审查后才能判定范围；500-step 回合不在本批次内。
C. 必要的生命周期、吞吐与完整执行路径证据，不能由 2ms IVP 成功外推。
D. 物理验收完成后，另定云 GPU PPO 预算及模型/检查点端到端验收。
   本机永远不承担正式训练，本包 PPO=0、cloud_training=0、training_ready=false。
不能把 2/5 说成整个项目工时完成 40%，也不能承诺训练前固定只剩几次运行。

最新已通过的物理证据仍是 dynamic-ivp-v2
commit e256a0789ebfb0a1a35d621856e50479c4b89c8e
分支 stage12-dynamic-ivp-v2-return-20261018t045031z-f78c68a928
352 次积分、1413 forward，32/64/128/128-replay 精确回放通过，不重跑。
旧 cloud 归档、v1 动态失败、70 个静态样本通过与完整原始交接均保留。
此前用户确认云机 OFF；本轮无电源复查，不自动开关机。
已完成云批次无剩余必要云计算/回传；旧 Stage09 云端完整轨迹仍按原历史规范留存。

长期规范全文仍在包内
 docs/handoffs/microduck-local-ssh-push-protocol.md
 docs/handoffs/microduck-cloud-gpu-and-transfer-protocol.md
原交接全文：origin/complete-handoff.txt；上一版说明：history/full-path-v1/README.txt。
正式阶段封口仍须本地提交/增量 Git bundle 和用户 SSH push，不合并证据分支。
