microduck-double-balance / Stage12 / full-path-v1 / 2026-10-18
状态：离线准备完成，等待本机 RTX 5060 首次运行。本包不是 Stage12 全部验收通过。

下一条命令
把本次同名 ZIP、PY 启动器放到 /home/lx/下载，运行：
python3 "/home/lx/下载/microduck-stage12-full-path-v1-20261018.py" --run

这条命令显式授权一个新的独立批次：新 native 窗口 85500 秒，含清理总窗口
86400 秒，最后 900 秒留作清理。24 小时是上限，不是预计耗时；可能运行数小时。
旧截止仍是 2026-10-17T11:23:14+08:00 / 11:53:14+08:00，绝不顺延或复用。
前台每 10 秒显示新 macro 0/250 的实际进度。首次运行需要至少 32 GiB 可用空间；
运行时剩余空间低于 8 GiB 会停止并保留。分卷准备另行检查当前空间。

固定位置与环境
源码：/home/lx/microduck-double-balance/workspace，正式分支 double-balance。
Python：/home/lx/microduck-double-balance/workspace/.venv/bin/python。
新运行：/home/lx/microduck-double-balance/artifacts/double-balance-stage12/full-path-v1/local-20261018-v1。
新传输：/home/lx/microduck-double-balance/artifacts/double-balance-stage12/full-path-v1/transfer-local-20261018-v1。
SSH 远端：git@github.com:liuxue-lab/microduck-double-balance.git。
保持既有 Torch 2.9.1 / MuJoCo 3.10.0 / mujoco-warp 3.8.1 / Warp 1.12.0 /
mjlab 1.3.0 / BAM 1.0.1；核对 219 个既有源码 pin，不安装或升级环境。
自动从旧 v2 inputs 复用并验证 951 个冻结文件；不存在时使用包内完全相同的冻结 ZIP。
不读取旧检查点，不创建 PPO/优化器，不改正式源码分支，不创建完成标签。

是否联网
下载本包及最后手动 Git SSH push 需要网络。
准备、CUDA 编译、本机仿真、日志与本地 Git 分卷提交不需要网络。
native 子进程沿用审计隔离，禁止网络连接，HF/W&B 保持离线；无运行中下载依赖。
缺少既有依赖/资源或 SHA 不匹配时停止，不偷偷联网补装。

从哪里继续
最新已独立核验：dynamic-ivp-v2，Git 分支
stage12-dynamic-ivp-v2-return-20261018t045031z-f78c68a928
commit e256a0789ebfb0a1a35d621856e50479c4b89c8e。
evidence index SHA256 f78c68a9283941b1463ae512a4c314683947f313efb178627299d3e096fc8e2b。
回传 ZIP SHA256 bcea50228a2499c590fb48801d01860441b53cec9bdfadb1b304361dbd414a93。
v2 已通过 32/64/128/128-replay：352 次积分、1413 forward、1408 RK 阶段，
状态与运动学精确回放通过，不能重跑。
累计 completed=735352 / attempted=735353，历史差额 1 保留。
旧 n1/n2 pilot、70 个静态接触样本、动态 v1 失败和动态 v2 成功均保留。
原 n1 rollout 的 macro68 失败仍是失败；旧验收仍 2/5。
完整原 TXT 在 origin/complete-handoff.txt；新增 v2 核验与 started/result 在 history/。
history 中旧命令/旧预算仅供追溯，不得执行。

这次修了什么
1. v2 的最近顶点证书不能覆盖初始名义轨迹：对历史最初 15 个 macro 的 2592 个
   microstep 姿态，顶点证书均不成立。不能直接把 v2 的单个边界成功外推成全路径。
2. 用冻结的 8062 个 float32 mesh 顶点生成 7612 个凸壳三角面。SciPy 只提出面索引；
   全部 61,367,944 个面/顶点支撑半空间关系随后用精确二进制有理数整数运算验证。
   同时验证闭合定向边、连通性、Euler=2 和严格内部点；几何 epsilon=0。
3. 保留 v2 最近顶点快速路径。其证书不成立时，枚举全部凸壳面投影与夹紧边段，
   支持面、边及内部点；不是虚构顶点距离，也不回退原 GJK。球心恰在壳面、无唯一
   已放行法线等未覆盖情况会停止，绝不静默接受。
4. 沿用已验证的 float64 接触 FK：RK 内使用原 compensated position 与原 stage
   velocity；外部 reset/public forward 使用 native qpos 的只读 float64 FK。
   不改原积分器、四元数写入、position accumulator、材料、CCD 设置或验收阈值。
5. 接入真实单进程 owner 的 BAM、Scene、manager、私有 RNG、TerminalBridge 和
   CPU IPC；每个 macro 最先通过的候选必须精确回放，再发布一次公共时钟。
6. 修复大文件回传：单个 WAL/RK 文件可跨多个分卷，内存有界；完成分卷可恢复复用。
   磁盘检查只限制首次 native 运行，不阻止已有 started/result 的收集。

本批次的精确范围
一个全新修正后的 N1 环境，零动作，24 个真实 public step；随后显式 reset，
检查 empty reset，再做 1 个 public step。共 25 step / 250 macro / 0.5 秒仿真时间。
rollout 中保留原 terminated/truncated 行为，必要时自然 reset；不保证单回合存活。
每个 macro 2ms，固定 tiers32/64/128/256/512，首个通过候选强制 exact replay。
最多 376000 次积分、1506254 次 forward、28 次 reset、1 个物理 world。
预算是保守上限，实际次数由 WAL 对账。所有调用、失败、未完成 attempt 都保留。
开跑前先执行 98 个 GPU 几何样本核对：70 个旧静态样本、15 个历史 macro 起点、
12 个面邻域样本、1 个内部样本。该门通过前不会进行第一次 public reset 或 RK 积分。
fixture 的 float64 实现差异界只用于 CPU/GPU 一致性，不改变物理接触判定或原验收阈值。
原 event bracket <=25us、midpoint agreement <=62.5us、局部状态/接触积分限值不变。
原积分/比较/回放/回滚源码保存在冻结 inputs；plan.json 是完整有限调用预算。

已经完成的离线检查与仍待验证的边界
27 项回归检查通过：原阈值拒绝、512 上限停止、强制回放及回放失败、计数/WAL、
窗口不续期、started 防重跑、活进程禁止归档、外部 FK 不写 primary、macro 相位、
证书失败先于接触写入，以及跨分卷文件、空文件、大量小文件、中断恢复、篡改拒绝。
98 个真实/构造姿态的 kernel 源码由 NumPy 解释执行，并通过独立几何 oracle；
另有 4 个解析立方体用例。该检查不是 Warp 执行或 CUDA 编译。
新离线审查器重读已核验 v2 原始字节，独立重建全部积分记录、接触积分、13 个
raw boundary、原拒绝决策及精确回放。没有重新执行 v2。
当前助手环境无 Warp/MuJoCo/CUDA，因此新 hull kernel 的实际 CUDA 编译、GPU
fixture 和完整 BAM/manager 路径仍必须由本机这次运行验证，不能写成已经通过。

运行结束与 Git 回传
成功或失败都会保留 started、完整日志、WAL、每个 macro 的 raw boundary/owners、
全部 RK primary/qacc/contact 记录和 114 个 Data 哈希、几何证据、public transition、
私有 RNG、资源销毁与隔离回执。全量新证据可能达到 GB 级；不会只回传成功摘要。
工具先在独立传输目录创建本地 Git 提交，压缩分卷始终 <=49 MiB，最后打印：
python3 /home/lx/microduck-double-balance/artifacts/double-balance-stage12/full-path-v1/transfer-local-20261018-v1/manual_push.py --push
由用户手动运行这一条，沿用现有 SSH 身份。脚本依次推送分卷分支，最后推送总索引；
不 force push、不 push double-balance、不 PR、不 merge、不操作云电源。
总索引分支格式 stage12-full-path-v1-return-<UTC>-<indexhash10>，分卷追加 -volNNN。
总索引固定各卷 commit、ZIP/part/segment SHA，保留 evidence-index 与原始文件 SHA。
仅省略已经交付的相同 frozen-inputs.zip；其 SHA 仍被总清单绑定，不省略新 native 证据。
推送成功后，Codex 从 Git 固定 commit 直接读取结果，无需用户上传 ZIP/截图或跑整套核验。

恢复与常见错误
运行中不要并发重开脚本。Ctrl+C 主前台会中断新批次；本批次不能重试 native。
重复 --run 会检查 started：只能收集已退出的子进程/进程组并准备回传，不重新仿真。
若需要明确只收集：
python3 "/home/lx/下载/microduck-stage12-full-path-v1-20261018.py" --collect-only
文件名带 (1) 的 ZIP 会按 SHA 自动识别；如果 PY 被浏览器重命名，命令使用实际 PY 名。
只校验下载包、绝不启动环境：
python3 "/home/lx/下载/microduck-stage12-full-path-v1-20261018.py" --verify-only
缺少 .venv/固定源码 pin、磁盘不足、活动进程未退出、证据被改动时停止并保留。
仅传输中断：再次运行打印的 manual_push.py --push，已确认卷跳过；不重跑 native。
分卷准备中断：--collect-only 复用同一 evidence index 和已完成卷，不复制一套新结果。
SSH 私钥口令不是 GitHub 密码；沿用 ssh-agent/既有 key，不能切 HTTPS/PAT。
non-fast-forward / SHA 不符：保留两边，停止 force/覆盖操作；不改期望哈希。
只读查看日志（Ctrl+C 只退出 tail）：
tail -f /home/lx/microduck-double-balance/artifacts/double-balance-stage12/full-path-v1/local-20261018-v1/console.log

下一阶段与云状态
本次返回须经独立 Git 审查，之后才判断修正 N1 rollout 的验收范围。
N2 rollout、完整 500-step episode、另行预算的 PPO/检查点端到端验收尚未完成。
PPO=0，cloud_training=0，training_ready=false。本批次不需要云 GPU。
此前用户已明确回复“已经关机 继续”，记录为用户确认 OFF；精确确认时间未记录，
本轮没有平台电源复查。旧完成云批次无剩余必要云计算/回传任务；旧 Stage09 云端
完整轨迹仍按历史规范留存，不能据此声称所有历史云文件均已备份。
不启动/停止云实例，不重新执行失败关机 daemon；若未来新增云工作，另立预算。

长期规范（完整原文随包保留）
docs/handoffs/microduck-local-ssh-push-protocol.md
docs/handoffs/microduck-cloud-gpu-and-transfer-protocol.md
本包是待核验实验工作包，尚无正式阶段提交/完成标签；以后正式源码封口仍按
double-balance 的本地提交、增量 Git bundle 和用户 SSH push 规范执行。
