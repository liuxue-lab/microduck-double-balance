microduck-double-balance Stage12 / independent dynamic IVP v2
Prepared 2026-10-18. OFFLINE_PREPARED_NOT_RUN. 本次新增 native=0。

下一条命令（先将本次 ZIP 和 PY 放在 /home/lx/下载）
python3 /home/lx/下载/microduck-stage12-dynamic-ivp-v2-20261018.py --run

本包承接已核验的 dynamic-ivp-v1 失败返回。v2 是新的有界精度诊断，不能称为
动态验收已通过。启动器默认只准备；--run 才启动本文声明的新范围和新窗口。
不安装或升级依赖，不重跑旧完成批次，不自动 push、PR、merge 或操作云电源。
PPO=0、cloud_training=0；本机 RTX5060 仅做本次仿真。

最新 Git 返回与未完成项
- branch: stage12-dynamic-ivp-v1-return-20261018t035700z-246babe9f6
- commit: dc20e0586f42ecdc0a5a6256db505982eb5c43f6
- evidence-index SHA256:
  246babe9f67131a3a22c30599476c37a06ae7c5c594275bf904d3933c868a9c3
- return ZIP SHA256:
  9f5aa30d4812cabc0e602861688eec3a147fbf9d2ad3ac3c6a7e1425a948cedc
- 51 个分片、197 个归档成员和117个证据文件均已通过 Git 取得并核验。
- v1 状态 DYNAMIC_IVP_STOPPED_PRESERVE，returncode=1；实际687.858秒。
  992/992积分，3973/3973 forward，3968个RK stage，5试次；无超时，无回放，
  无发表。228468条WAL完整配对，无pending；42个原生资源释放。
- 32/64/128/256/512档的 upper_head 事件数为2/6/10/16/34；四次状态与
  接触积分比较均通过，事件比较失败。最后方向数量不等，前缀中点差
  146.484375 us > 原62.5 us界限。512失败保持失败，不能追加更细档或自动重试。
- 原验收仍2/5：n1-pilot、n2-pilot已通过；n1-rollout在macro68失败，
  n2-rollout与n1-full-episode未完成。后续仍需完整环境路径、剩余三点、
  lifecycle/吞吐复核和阶段归档。本次2ms独立IVP不增加原验收点。
- 原静态contact-precision-v1的70/70已完成，不重跑；此前全部失败/归档保留。
  历史资料在origin/，新增失败摘要与原窗口在history/；最新状态看顶层CURRENT-STATE.json。

本次精度改动及离线依据
- v1 虽以float64做相对几何计算，输入geom_xpos/geom_xmat此前已在float32
  FK中舍入；已有float64位置累计值也先转为float32 qpos。
- 读取v1归档的3973个真实位姿，分别重算原位姿几何、双精度FK+原qpos、
  双精度FK+既有位置累计值。五档事件数分别是：
  原值 2/6/10/16/34；只提高FK精度 2/4/6/16/22；连同累计值 2/2/2/2/2。
  共复核11919个全8062顶点凸性证书。此为同一旧轨迹的几何复算，不是新动力学。
- 用独立Rodrigues矩阵组合复核FK：最大位置差2.221e-16 m，矩阵差1.041e-15。
  14个完整Model数组已从冻结MJCF和已归档compiled geometry离线重建，SHA256
  全部精确匹配原329数组清单。运行时再次核对所有14数组和目标拓扑。
- 新KinematicPrecision在每个RK stage使用已有BatchPositionAccumulator，
  stage1/2/3按原dt和上一stage原生qvel计算位置；保持原生float32四元数。
  终点使用该试次累计值。检查原stage舍入边界和accumulator/native绑定；
  只推导sphere84/mesh49的双精度位姿，不写入primary Data，不改积分器。
- 新双精度位姿上传两个缓冲区（共192字节）；precise_pose_kernel.py只改变
  原certified_geometry/relative_vertex的位姿参数类型，函数体AST逐项一致。
  原precise_contact_kernel.py逐字节保留，继续使用原contact_params/write_contact。
  新kernel及新动态包装尚未进行CUDA编译/执行，不将静态通过沿用为v2通过。
- 每次遍历8062顶点，min_dot>=0且length>0才允许替换目标接触；无epsilon、
  无固定顶点、无平滑/滞回、无失败fallback。非目标16类接触字段逐字节检查。
- 逐forward保存原生位姿、新位姿、原qpos、累计值、stage速度来源、几何证书
  和primary哈希。额外要求candidate/replay几何证据链精确一致后才可发表。
- 原接口输出的其他碰撞、约束、sensor与其内部位姿仍使用原生精度；本包是
  目标接触对的混合精度诊断，不声称全模拟器已双精度化。

初值、原阈值和有限调度
- 单世界、独立2ms IVP：归档macro68数值边界，名义0.136 -> 0.138秒。
  114个numeric Data数组完整恢复；329个numeric Model哈希精确匹配。
  BAM dof_damping/dof_frictionloss沿用v1已核验重建数组及其哈希，重建脚本保留。
- managers、BAM Python历史、sensor context/BVH和RNG均是fresh owner；初始
  sense只建立上下文/别名，随后再次恢复完整Data。没有旧opaque owner恢复。
  ctrl保持，外力为0，act为空；public RL step/reset=0。
- tiers固定32/64/128/256/512，沿用冻结局部状态/事件及全局状态/接触积分阈值。
  第一个通过档必须精确重放；Data、selected owners、sensor及stage哈希相同。
  同时要求本次新增的几何证据链相同。512失败即回滚并停止，不扩档。
- 最多6试次、1504积分、6023 GPU forward。新FK计算/上传各最多6023次，
  仅1次Model捕获、2次缓冲分配、1次新kernel模块加载；详见plan.json。
- 历史completed=734008、attempted=734009，加已完成v1的992次后，
  当前completed=735000、attempted=735001；历史差额1继续保留。
- 原截止native=2026-10-17T11:23:14+08:00，total=2026-10-17T11:53:14+08:00
  原值保留且不可重开。v1已结束的新窗口也原样保留在history/dynamic-v1-started.json。
- 本次--run单独授权v2新窗口：native上限6900秒，含清理总上限7200秒，
  预留300秒。是上限，不是预计用时。每项声明调用检查墙钟/单调时钟，
  总截止由父进程终止其专属子进程组。失败/超时均归档，不重开窗口。
- paired durable WAL保留未完成attempt；边界原始证据48MiB、RK解压192MiB、
  几何解压64MiB、WAL160MiB。不静默截断，不因证据额度不足丢弃失败记录。

本机执行、回传与恢复
- canonical源码：/home/lx/microduck-double-balance/workspace，分支double-balance。
- Python：/home/lx/microduck-double-balance/workspace/.venv/bin/python。
- 下载：/home/lx/下载；固定新产物目录：
  /home/lx/microduck-double-balance/artifacts/double-balance-stage12/dynamic-ivp-v2/local-20261018-v1
- 固定Torch2.9.1、MuJoCo3.10.0、mujoco-warp3.8.1、Warp1.12.0、mjlab1.3.0、
  BAM1.0.1；预检219源码pin，不安装任何依赖。
- SHA锁定启动器兼容ZIP文件名末尾(1)；ZIP/PY需来自本次v2。支持ZIP内
  带完整951文件冻结输入，不依赖重下旧归档。默认只准备；--verify-only只验包；
  --collect-only只收集已退出子进程，均不启动native。
- started一旦存在绝不重跑native；重复命令只收集或复用已准备回传。
  子进程身份不明时停止；禁止删started、改目录或改标记冒充新运行。
- 成功与失败均在源码和运行目录之外准备本地Git artifact branch/commit，
  不修改canonical checkout。每ZIP不超过49MiB，以384KiB片段编码回传。
- 结束后手动执行脚本打印的Git SSH push：
  git@github.com:liuxue-lab/microduck-double-balance.git
  分支前缀stage12-dynamic-ivp-v2-return-。本包不自动push、PR、merge或建阶段完成标签。
- 推送成功后回复“已推送”或粘贴正常输出即可；Codex直接通过Git读取固定commit，
  校验所有分片/归档/index，再离线审查轨迹、FK来源、原判据、账本、回滚和精确回放。
  无需重跑验证批次或另行上传全套日志；artifact branch不能合并到double-balance。
- review_return.py只接受完整成功返回；中途失败/512拒绝保留原结论，单独复核，
  不能改成PASS。v1审查中发现的JSON端点dtype问题已在v2 reviewer修正：
  按实际float32恢复端点后调用原判据；没有修改运行时阈值。

常见情况与云状态
- ZIP SHA不匹配：保留现场，仅重取对应文件；不可改期望SHA。
- 缺既有venv或源码pin不同：停止，不自动升级；把错误结果交回。
- 前台首次编译暂慢：看每10秒心跳，不并发重开；Ctrl+C会中断本次运行。
- 仅需打包恢复：原命令加--collect-only，不删除started。
- Git Permission denied：复用既有SSH agent/key；不改HTTPS、PAT或网页登录。
  non-fast-forward时停止，不force push；正常push输出足以确认回传动作。
- 当前云端剩余计算任务=0；正式云训练预算UNSET，PPO=0/cloud_training=0。
  云电源沿用用户“已经关机 继续”的OFF确认（确切时间未记录），没有平台独立
  轮询。历史关机提醒记录保留，不操作电源；本次不需要启动云GPU。
  Stage09未完整回传的旧head-trace仍是历史留存，不能称为全部备份。
- 两份长期协议全文保留，后续交接继续引用：
  docs/handoffs/microduck-local-ssh-push-protocol.md
  docs/handoffs/microduck-cloud-gpu-and-transfer-protocol.md

离线验收与边界
- validation/offline-tests.txt：22项离线回归，包含原判据拒绝、强制回放、
  512封顶、WAL/截止、失败留存、完整传输往返与篡改拒绝、3973位姿复算、
  14数组重建、stage/endpoint/commit桥接、几何回放不一致阻止发表。
- check_offline.py：完整包/951输入哈希、调用cap闭包、源码语法、BAM重建、
  原kernel身份、14数组匹配和3973位姿独立FK复核；没有导入原生模拟器。
- 用户运行后的CUDA编译、实时所有证书、动力学收敛、原判据和精确回放，
  都必须由真实返回证明。离线复算的2/2/2/2/2不能充作这些证明。
