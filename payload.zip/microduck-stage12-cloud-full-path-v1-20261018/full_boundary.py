"""Full-path contact correction with an exactly certified hull and GPU preflight."""
import hashlib
import json
import numpy as np
from dynamic_boundary import DynamicBoundary, CONTACT_FIELDS, MATERIALS, target_mask, validate_replacement
from full_kinematics import FullKinematics
from static_common import ROOT, read, require, write


class FullBoundary(DynamicBoundary):
    def __init__(self,m,d,wp,gate,out,plan):
        # A failed constructor remains owned by the factory cleanup path.
        self.external_calls=0;self.macros=0;self.fixture_verified=False
        self.calls=0;self.attempts=0;self.raw_bytes=0;self.closed=False
        self.stream=None;self.digest=hashlib.sha256();self.trial_proofs=[]
        # Retain all original material, allocation, shape and callback checks.
        import dynamic_boundary
        import kinematic_precision
        original=kinematic_precision.KinematicPrecision
        kinematic_precision.KinematicPrecision=FullKinematics
        try:super().__init__(m,d,wp,gate,out,plan)
        finally:kinematic_precision.KinematicPrecision=original
        import convex_pose_kernel
        self.hull_kernels=convex_pose_kernel
        with np.load(ROOT/'source-reference/convex-hull.npz',allow_pickle=False) as z:faces=z['facets'].copy()
        certificate=read(ROOT/'validation/exact-hull-certificate.json')
        require(faces.dtype==np.int32 and faces.shape==(7612,3)
                and hashlib.sha256(faces.tobytes()).hexdigest()==certificate['facets_sha256'],
                'Certified hull indices differ')
        vertices=gate.limited('Hull_vertex_pin',1,lambda:m.mesh_vert.numpy()[100264:108326].copy())()
        require(hashlib.sha256(vertices.tobytes()).hexdigest()==certificate['vertices_sha256'],
                'Compiled hull vertex bytes differ')
        self.facets=gate.limited('Hull_allocation',2,lambda:wp.array(faces,dtype=wp.vec3i,device=d.qpos.device))()
        self.geometry=gate.limited('Hull_allocation',2,lambda:wp.zeros((1,16),dtype=wp.float64,device=d.qpos.device))()
        gate.limited('Hull_module_load',1,lambda:wp.load_module(convex_pose_kernel,device=d.qpos.device))()
        self.phase='external';self.role='external';self.resolution=0;self.macro_index=None
        self.external_calls=0;self.macros=0;self.fixture_verified=False

    def geometry_call(self,label):
        args=[self.m.mesh_vert,self.facets,self.kinematics.positions,self.kinematics.rotations,
              100264,8062,7612,self.contract['radius'],self.geometry]
        self.gate.limited(label,self.plan['caps'][label],lambda:self.wp.launch(
            self.hull_kernels.convex_geometry,dim=1,inputs=args,device=self.d.qpos.device))()
        return self.geometry.numpy()[0].copy()

    def verify_fixtures(self):
        require(self.calls==0 and not self.fixture_verified,'Fixture queries are one-time before public reset')
        with np.load(ROOT/'source-reference/hull-fixtures.npz',allow_pickle=False) as z:
            positions=z['positions'];rotations=z['rotations'];expected=z['expected']
        before={n:hashlib.sha256(getattr(self.d,n).numpy().tobytes()).hexdigest() for n in ('qpos','qvel','ctrl','time')}
        values=[]
        for p,r,reference in zip(positions,rotations,expected,strict=True):
            def upload():
                self.kinematics.positions.assign(p[None]);self.kinematics.rotations.assign(r[None])
            self.gate.limited('Hull_fixture_upload',128,upload)()
            result=self.geometry_call('Hull_fixture_query')
            require(np.isfinite(result).all() and result[10]==1,'GPU hull fixture failed')
            # These bounds compare two float64 implementations, not physical
            # acceptance or collision thresholds. Contact sign must match exactly.
            require((result[3]<0)==(reference[3]<0) and result[13]==reference[13]
                    and np.max(abs(result[2:4]-reference[2:4]))<1e-13
                    and np.max(abs(result[4:10]-reference[4:10]))<1e-10,
                    'GPU hull differs from the frozen independent fixture')
            if reference[0]>=0:
                require(result[0]==reference[0] and result[1]>=0,'v2 vertex fast path changed')
            values.append(result)
        require(before=={n:hashlib.sha256(getattr(self.d,n).numpy().tobytes()).hexdigest() for n in before},
                'Fixture query changed native state')
        np.savez_compressed(self.out/'hull-fixture-return.npz',values=np.asarray(values))
        write(self.out/'hull-fixture-review.json',dict(status='GPU_HULL_FIXTURES_PASS',count=len(values),
            first_public_reset_started=False,integrations=0,native_state_unchanged=True,
            runtime_collision_epsilon=0,original_thresholds_changed=False))
        self.fixture_verified=True

    def begin_macro(self,index,tick,engine):
        require(self.fixture_verified and self.phase=='external' and index==self.macros and index<250,
                'Unscheduled full-path macro')
        self.macro_index=index;self.episode_tick=tick;self.phase='idle';self.trial=0;self.trial_calls=0
        self.kinematics.engine=engine

    def end_macro(self):
        require(self.phase=='commit' and self.trial_calls==1,'Macro publication not complete')
        self.macros+=1;self.phase='external';self.role='external';self.resolution=0;self.trial=0;self.trial_calls=0
        self.macro_index=None;self.kinematics.engine=None

    def end_trial(self):
        require(self.phase=='trial' and self.trial_calls==4*self.resolution+1,'Incomplete trial geometry')
        proof=dict(macro_index=self.macro_index,trial=self.trial,resolution=self.resolution,role=self.role,
                   forwards=self.trial_calls,kinematic_sha256=self.pose_digest.hexdigest())
        if self.role=='replay':
            previous=self.trial_proofs[-1]
            require(previous['macro_index']==self.macro_index and previous['resolution']==self.resolution
                    and previous['role']!='replay' and previous['kinematic_sha256']==proof['kinematic_sha256'],
                    'Exact full-path kinematic replay failed')
        self.trial_proofs.append(proof)
        write(self.out/'kinematic-trials.json',dict(trials=self.trial_proofs))
        self.phase='idle'

    def wrap(self,native):
        def call(m,d):
            require(self.fixture_verified and m is self.m and d is self.d and not self.closed,
                    'Unverified, foreign or closed full-path correction')
            require(self.phase in ('external','trial','commit'),'Collision outside an admitted phase')
            if self.phase!='external':
                cap=4*self.resolution+1 if self.phase=='trial' else 1
                require(self.trial_calls<cap,'Per-trial forward cap reached')
            else:
                require(self.external_calls<self.plan['owner_plan']['external_forward_reservation'],
                        'External public/reset forward reservation exhausted')
            require(self.calls<self.plan['caps']['GPU_forward']
                    and self.gate.counts['GPU_forward_attempted']==self.gate.counts.get('GPU_forward_completed',0)+1==self.calls+1,
                    'Full-path collision/forward coverage mismatch')
            value=native(m,d);self.attempts+=1
            native_position=d.geom_xpos.numpy()[0,[84,49]];native_rotation=d.geom_xmat.numpy()[0,[84,49]]
            p,r,proof=self.gate.limited('Kinematic_pose_compute',self.plan['caps']['GPU_forward'],lambda:self.kinematics.compute(self))()
            result=self.geometry_call('Precise_geometry_kernel')
            row=dict(serial=self.attempts,macro_index=self.macro_index,phase=self.phase,trial=self.trial,
                resolution=self.resolution,role=self.role,trial_forward=self.trial_calls,
                position=p.tolist(),rotation=r.tolist(),native_position=native_position.tolist(),native_rotation=native_rotation.tolist(),
                kinematics=proof,values=result.tolist() if np.isfinite(result).all() else None,
                primary_sha256={n:hashlib.sha256(getattr(d,n).numpy().tobytes()).hexdigest() for n in ('qpos','qvel','time','ctrl')})
            if not (np.isfinite(result).all() and result[10]==1):
                row['certificate_failed_before_mutation']=True;self.append(row)
                raise RuntimeError('Certified hull query failed; no original narrowphase fallback or mutation')
            before={n:getattr(d.contact,n).numpy().copy() for n in CONTACT_FIELDS};old_n=int(d.nacon.numpy()[0])
            require(0<=old_n<=256,'Original contact overflow')
            count=int(target_mask(before,old_n).sum())
            require(count<=1 and old_n-count+int(result[3]<0)<=256,'Target multiplicity/contact capacity differs')
            args=[getattr(m,n) for n in MATERIALS]+[self.pair,self.pairid,self.geometry,d.naconmax,d.nacon]+[getattr(d.contact,n) for n in CONTACT_FIELDS]+[self.status]
            self.gate.limited('Precise_contact_kernel',self.plan['caps']['GPU_forward'],lambda:self.wp.launch(
                self.kernels.replace_target,dim=1,inputs=args,device=d.qpos.device))()
            after={n:getattr(d.contact,n).numpy().copy() for n in CONTACT_FIELDS}
            row['mutation']=validate_replacement(before,after,old_n,int(d.nacon.numpy()[0]),result)
            require(int(self.status.numpy()[0])==int(result[3]<0),'Mutation status differs')
            if self.phase=='trial':
                physical={k:row[k] for k in ('position','rotation','kinematics','values','mutation','primary_sha256')}
                self.pose_digest.update(json.dumps(physical,sort_keys=True,separators=(',',':'),allow_nan=False).encode()+b'\n')
            self.append(row);self.calls+=1
            if self.phase=='external':self.external_calls+=1
            else:self.trial_calls+=1
            return value
        return call

    def close(self):
        if self.stream is None:
            self.closed=True
            result=dict(attempts=self.attempts,completed=self.calls,raw_bytes=self.raw_bytes,
                sha256=self.digest.hexdigest(),closed=True,kinematic_trial_proofs=self.trial_proofs)
        else:
            result=super().close()
        result.update(external_forwards=self.external_calls,completed_macros=self.macros,
                      gpu_fixture_verified=self.fixture_verified,hull_facets=7612)
        return result
