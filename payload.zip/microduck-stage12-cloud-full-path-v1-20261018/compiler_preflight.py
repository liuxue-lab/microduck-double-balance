"""Actual Warp 1.12 compiler and isolated CPU geometry validation; no simulation.

Run only in the assistant's isolated validation dependencies. The user's native
GPU gate remains mandatory. No installer, network, MuJoCo, Torch, or PPO calls.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import numpy as np

ROOT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def verify(output):
    import warp as wp
    output=Path(output).resolve();output.mkdir(parents=True,exist_ok=False)
    assert wp.__version__=='1.12.0'
    wp.config.kernel_cache_dir=str(output/'cache')
    wp.init()
    assert not wp.get_cuda_devices(), 'This check is explicitly CPU and CUDA AOT only'
    import convex_pose_kernel,precise_pose_kernel
    modules=(convex_pose_kernel,precise_pose_kernel)
    for module in modules:
        wp.load_module(module,device='cpu')
        wp.compile_aot_module(module,arch=120,module_dir=str(output/'cuda-aot'),use_ptx=True)
    with np.load(ROOT/'source-reference/head-geometry.npz',allow_pickle=False) as z:v=z['vertices']
    with np.load(ROOT/'source-reference/convex-hull.npz',allow_pickle=False) as z:f=z['facets']
    with np.load(ROOT/'source-reference/hull-fixtures.npz',allow_pickle=False) as z:
        p=z['positions'];r=z['rotations'];expected=z['expected']
    values=wp.zeros((len(p),16),dtype=wp.float64,device='cpu')
    inputs=[wp.array(v,dtype=wp.vec3,device='cpu'),wp.array(f,dtype=wp.vec3i,device='cpu'),
        wp.array(p,dtype=wp.vec3d,device='cpu'),wp.array(r,dtype=wp.mat33d,device='cpu'),
        0,len(v),len(f),float(np.float32(.02)),values]
    wp.launch(convex_pose_kernel.convex_geometry,dim=len(p),inputs=inputs,device='cpu')
    actual=values.numpy()
    assert actual.shape==expected.shape==(98,16) and np.isfinite(actual).all()
    assert np.all(actual[:,10]==1) and np.array_equal(actual[:,3]<0,expected[:,3]<0)
    assert np.array_equal(actual[:,13],expected[:,13])
    max_gap=float(np.max(abs(actual[:,2:4]-expected[:,2:4])))
    max_pose=float(np.max(abs(actual[:,4:10]-expected[:,4:10])))
    assert max_gap<1e-13 and max_pose<1e-10,(max_gap,max_pose)
    fast=expected[:,0]>=0
    assert np.array_equal(actual[fast,0],expected[fast,0]) and np.all(actual[fast,1]>=0)
    np.savez_compressed(output/'warp-cpu-fixtures.npz',actual=actual,expected=expected)
    assert not any(m in sys.modules for m in ('torch','mujoco','mujoco_warp','mjlab','bam'))
    package_sources={m.__name__+'.py':sha(m.__file__) for m in modules}
    site=Path(wp.__file__).parent
    result=dict(status='WARP_112_CPU_FIXTURES_AND_CUDA_AOT_PASS',warp_version=wp.__version__,
        compiled_modules=[m.__name__ for m in modules],source_sha256=package_sources,
        compiler_sources={n:sha(site/n) for n in ('__init__.py','_src/context.py','_src/codegen.py','_src/build.py')},
        CPU_fixture_cases=98,max_abs_length_gap_error=max_gap,max_abs_normal_point_error=max_pose,
        CUDA_AOT_arch=120,CUDA_AOT_format='PTX',GPU_execution=False,MuJoCo_loaded=False,
        simulation_integrations=0,PPO=0,cloud_training=0,
        files={p.relative_to(output).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p))
            for p in sorted(output.rglob('*')) if p.is_file()})
    (output/'compiler-review.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='files'},indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    verify(p.parse_args().output)
