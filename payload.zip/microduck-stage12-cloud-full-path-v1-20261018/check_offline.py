"""Artifact, immutable-source and schedule checks; no simulator imports."""
import argparse
import ast
import hashlib
import json
import sys
from pathlib import Path
import numpy as np
from static_common import ROOT,read,require,verify_package,sha


def check(candidate):
    identity=verify_package();candidate=Path(candidate).resolve()
    from frozen_inputs import exact
    exact(candidate.parent,read(ROOT/'frozen-inputs-manifest.json')['files'])
    from operation_contract import validate_caps
    closure=validate_caps(candidate,read(ROOT/'plan.json'))
    count=0
    for p in ROOT.rglob('*.py'):ast.parse(p.read_text(),filename=str(p));count+=1
    require(sha(ROOT/'precise_contact_kernel.py')==read(ROOT/'kernel-provenance.json')['kernel_sha256'],
            'GPU-verified material/contact publication kernel changed')
    for name,pin in read(ROOT/'candidate-pins.json').items():require(sha(candidate/name)==pin,'Frozen numerical source changed: '+name)
    cert=read(ROOT/'validation/exact-hull-certificate.json')
    with np.load(ROOT/'source-reference/head-geometry.npz',allow_pickle=False) as z:v=z['vertices']
    with np.load(ROOT/'source-reference/convex-hull.npz',allow_pickle=False) as z:f=z['facets']
    require(hashlib.sha256(v.tobytes()).hexdigest()==cert['vertices_sha256']
        and hashlib.sha256(f.tobytes()).hexdigest()==cert['facets_sha256']
        and cert['facet_vertex_exact_checks']==61367944 and cert['geometric_epsilon']==0,'Exact hull certificate identity differs')
    math=read(ROOT/'validation/kernel-math-check.json')
    for name,pin in math['source_sha256'].items():require(sha(ROOT/name)==pin,'Kernel math validation source changed: '+name)
    require(math['status']=='PURE_NUMPY_KERNEL_MATH_AND_ANALYTIC_CASES_PASS' and math['fixtures']==98
        and not math['CUDA_compilation'] and not math['GPU_execution'],'Offline validation scope differs')
    compiler=read(ROOT/'validation/compiler-review.json')
    require(compiler['status']=='WARP_112_CPU_FIXTURES_AND_CUDA_AOT_PASS'
        and compiler['warp_version']=='1.12.0' and compiler['CPU_fixture_cases']==98
        and compiler['CUDA_AOT_arch']==120 and compiler['CUDA_AOT_format']=='PTX'
        and not compiler['GPU_execution'] and compiler['simulation_integrations']==0,
        'Actual compiler validation scope differs')
    for name,pin in compiler['source_sha256'].items():
        require(sha(ROOT/name)==pin,'Actually compiled source differs: '+name)
    require(sha(ROOT/'compiler_preflight.py')==compiler['compiler_preflight_sha256'],
        'Compiler verification program differs')
    for name in ('convex-hull.npz','head-geometry.npz','hull-fixtures.npz'):
        prior=read(ROOT/'history/full-path-v1/MANIFEST.json')['files']['source-reference/'+name]
        require(sha(ROOT/'source-reference'/name)==prior['sha256'],'Frozen geometry changed')
    with np.load(ROOT/'source-reference/hull-fixtures.npz',allow_pickle=False) as z:
        require(z['positions'].shape==(98,2,3) and z['rotations'].shape==(98,2,3,3)
            and z['expected'].shape==(98,16) and np.isfinite(z['expected']).all(),'GPU preflight fixture shape/value differs')
    require(not any(n in sys.modules for n in ('torch','warp','mujoco','mujoco_warp','mjlab','bam')),'Offline check imported native dependency')
    return dict(status='FULL_PATH_OFFLINE_PREPARATION_PASS',package_sha256=identity,python_files_parsed=count,
        callable_contract=closure,frozen_input_files=951,hull_exact_tests=61367944,GPU_fixture_cases_prepared=98,
        original_thresholds_changed=False,native_calls=0,integrations=0,PPO=0,cloud_training=0,
        Warp_CPU_fixture_cases_validated=98,CUDA_AOT_PTX_compilation_validated=True,
        GPU_execution_validated=False,requires_user_execution=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--candidate',type=Path,required=True);a=p.parse_args()
    print(json.dumps(check(a.candidate),ensure_ascii=False,indent=2))
