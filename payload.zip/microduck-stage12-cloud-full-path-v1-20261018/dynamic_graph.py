"""Same sorting graph, adding paired WAL for the already declared graph calls."""
from integration.native_runtime import FormalContact
from lifecycle_support import require

class DynamicContact(FormalContact):
    CALL_CAP=6023
    def call(self,name,fn,cleanup=False):
        require(name in self.limits,'Undeclared graph call')
        # No synchronization is inserted inside graph capture; original graph
        # synchronization boundaries remain in the inherited implementation.
        return self.gate.counted('ContactGraph_'+name,fn,synchronize=False,cleanup=cleanup)
    def prepare(self):
        super().prepare()
        # Inherited destruction hooks already count the native API. Add WAL
        # around them without incrementing the counters a second time.
        for name in ('wp_cuda_graph_destroy','wp_cuda_graph_exec_destroy'):
            original=getattr(self.ctx.runtime.core,name)
            label='ContactGraph_'+('exec_destroy' if name.endswith('exec_destroy') else 'graph_destroy')
            def wrapped(ctx,handle,_native=original,_label=label):
                self.gate.boundary(cleanup=True)
                number=self.counts.get(_label+'_attempted',0)+1
                require(number<=self.gate.caps[_label],'Graph destroy budget exhausted')
                self.gate.journal.begin(_label,number)
                result=_native(ctx,handle)
                if result:self.gate.journal.end(_label,number)
                return result
            setattr(self.ctx.runtime.core,name,wrapped)
