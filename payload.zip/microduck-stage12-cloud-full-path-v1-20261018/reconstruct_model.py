"""Offline reconstruction, accepted ONLY by the archived full-array SHA256.

The prior solved EFC frictionloss is stale at macro_start: Scene.write has just
updated the Model fields. Recompute the pinned BAM friction expression from
the archived previous solved forces and current velocity, not from ctrl.
No simulator imports, native calls, optimization, tolerance, or fitted values.
"""
import hashlib
import json
from pathlib import Path
import numpy as np
from static_common import ROOT, read, require, sha

def load_reconstructed(root=ROOT):
    """Use the exact recovered bytes, avoiding CPU math-library drift at runtime."""
    root=Path(root);snapshot=read(root/'origin/macro-68/raw/record-00001-snapshot.json')
    with np.load(root/'source-reference/reconstructed-model-fields.npz',allow_pickle=False) as z:
        arrays={k:z[k].copy() for k in z.files}
    require(set(arrays)=={'Model.dof_frictionloss','Model.dof_damping'},'Recovered Model roster differs')
    for name,a in arrays.items():
        require(a.shape==(1,32) and a.dtype==np.float32 and hashlib.sha256(a.tobytes()).hexdigest()==snapshot['model_hashes'][name],'Recovered Model bytes differ: '+name)
    return arrays,dict(status='ARCHIVED_BAM_MODEL_BYTES_LOADED_EXACT',
        model_fields={k:snapshot['model_hashes'][k] for k in arrays},offline_derivation='reconstruct_model.reconstruct',
        runtime_float_recomputation=False,native_calls=0,threshold_changes=0,old_owner_resume_claimed=False)

def reconstruct(root=ROOT):
    root = Path(root); base = root/'origin/macro-68/raw'
    snapshot = read(base/'record-00001-snapshot.json')
    with np.load(base/'record-00001-data.npz', allow_pickle=False) as z:
        data = {k: z[k].copy() for k in z.files}
    require(set(data) == set(snapshot['Data']), 'Boundary Data roster differs')
    for name, a in data.items():
        pin = snapshot['Data'][name]
        require(list(a.shape) == pin['shape'] and str(a.dtype) == pin['dtype']
                and hashlib.sha256(a.tobytes()).hexdigest() == pin['sha256'] and np.isfinite(a).all(),
                'Boundary Data bytes differ: '+name)
    require(sha(root/'source-reference/bam-mjlab.py') == 'af3de252939ca868712423979c2ab52e198d382d7aca613b5b33c77d74baa440', 'BAM source differs')
    require(sha(root/'source-reference/bam-xl330-m6.json') == '61c699362fb3fabdde93eeba5e1ad3bf4ef9ca2f71d03e316b1924ff005b20d3', 'BAM parameters differ')
    params = read(root/'source-reference/bam-xl330-m6.json')
    c = lambda key: np.float32(params[key])
    ids = np.arange(6,20)  # This frozen 35-qpos/32-dof model only; runtime verifies BAM IDs.
    require(data['Data.qvel'].shape == (1,32) and data['Data.ctrl'].shape == (1,14), 'Boundary layout differs')
    nefc = int(data['Data.nefc'][0]); require(0 <= nefc <= 1024, 'Boundary EFC overflow')
    friction_force = np.zeros((1,32), np.float32)
    seen = set()
    for i in range(nefc):
        if int(data['Data.efc.type'][0,i]) == 1:
            dof = int(data['Data.efc.id'][0,i])
            require(dof in ids and dof not in seen, 'Friction row identity differs')
            seen.add(dof); friction_force[0,dof] += data['Data.efc.force'][0,i]
    require(seen == set(ids), 'Fourteen archived friction rows required')
    external = -data['Data.qfrc_bias'][:,ids] + data['Data.qfrc_constraint'][:,ids] - friction_force[:,ids]
    previous_motor = data['Data.qfrc_actuator'][:,ids]
    vel = data['Data.qvel'][:,ids]
    stribeck = np.exp(-np.power(np.abs(vel)/c('dtheta_stribeck'), c('alpha')))
    loss = np.full_like(previous_motor, c('friction_base'))
    loss = loss + stribeck*c('friction_stribeck')
    loss = loss + np.abs(external*c('load_friction_external') - previous_motor*c('load_friction_motor'))
    loss = loss + stribeck*np.abs(external*c('load_friction_external_stribeck') - previous_motor*c('load_friction_motor_stribeck'))
    drive = (abs(previous_motor) > abs(external)).astype(np.float32)
    back = np.float32(1) - drive
    quadratic = drive*c('load_friction_external_quad')*abs(external)**2 + back*c('load_friction_motor_quad')*abs(previous_motor)**2
    loss = loss + stribeck*quadratic
    with np.load(base/'record-00001-owners.npz', allow_pickle=False) as z:
        scale = z['BAM.friction_scale']
        require(scale.shape == (1,1) and scale.dtype == np.float32, 'Archived friction scale differs')
        require(hashlib.sha256(scale.tobytes()).hexdigest() == snapshot['owners']['BAM.friction_scale']['sha256'], 'Scale hash differs')
        loss = loss*scale
    full = np.zeros((1,32), np.float32); full[:,ids] = loss
    damping = np.zeros_like(full); damping[:,ids] = c('friction_viscous')
    arrays = {'Model.dof_frictionloss': full, 'Model.dof_damping': damping}
    for name, a in arrays.items():
        require(hashlib.sha256(a.tobytes()).hexdigest() == snapshot['model_hashes'][name], 'Reconstructed Model hash mismatch: '+name)
    return arrays, dict(status='ARCHIVED_BAM_MODEL_BYTES_RECONSTRUCTED_EXACT',
        model_fields={k: snapshot['model_hashes'][k] for k in arrays},
        all_boundary_data_arrays=len(data), native_calls=0, threshold_changes=0,
        derivation='Pinned BAM previous solved forces + current qvel; float32 operations; archived full-array SHA256 is the acceptance oracle',
        old_efc_frictionloss_not_reused=True, old_owner_resume_claimed=False)

if __name__ == '__main__':
    print(json.dumps(reconstruct()[1], indent=2))
