"""Target-pair float64 FK from the existing compensated positions.

No simulator imports, new integrator, smoothing, tolerance, or primary Data write.
Quaternions remain the native RK values. Math/order follows pinned MW 3.8.1
smooth._kinematics_branch and math.py; only arithmetic precision is promoted.
"""
import hashlib
import numpy as np
from static_common import ROOT, read, require
from batch_position_candidate import Q, V, batch_stage_position

FIELDS = ('body_parentid','body_mocapid','body_jntnum','body_jntadr',
          'body_pos','body_quat','jnt_type','jnt_qposadr','jnt_pos','jnt_axis',
          'qpos0','geom_bodyid','geom_pos','geom_quat')
BODY = (8, 9, 10, 11)
QADR = (12, 13, 14, 15)

def mul(u,v):
    w,x,y,z=u; a,b,c,d=v
    return np.array([w*a-x*b-y*c-z*d,w*b+x*a+y*d-z*c,
                     w*c+y*a+z*b-x*d,w*d+z*a+x*c-y*b],np.float64)

def rot(v,q):
    s=q[0];u=q[1:]
    return 2*np.dot(u,v)*u+(s*s-np.dot(u,u))*v+2*s*np.cross(u,v)

def normalize(q):
    n=np.linalg.norm(q);require(np.isfinite(n) and n>0,'Invalid quaternion')
    return q/n

def matrix(q):
    w,x,y,z=q
    return np.array([[w*w+x*x-y*y-z*z,2*(x*y-w*z),2*(x*z+w*y)],
                     [2*(x*y+w*z),w*w-x*x+y*y-z*z,2*(y*z-w*x)],
                     [2*(x*z-w*y),2*(y*z+w*x),w*w-x*x-y*y+z*z]])

def fk(q, reference):
    q=np.asarray(q)
    require(q.dtype==np.float64 and q.shape==(35,) and np.isfinite(q).all(),'Float64 pose required')
    p=q[:3].copy();r=normalize(q[3:7])
    for k,adr in enumerate(QADR):
        p=rot(reference['body_pos'][k],r)+p
        r=mul(r,reference['body_quat'][k])
        angle=q[adr]
        r=normalize(mul(r,np.r_[np.cos(angle*.5),reference['jnt_axis'][k]*np.sin(angle*.5)]))
    # Sphere local translation is exactly zero; its orientation is retained too.
    positions=np.array([q[28:31],p+rot(reference['geom_pos'][1],r)])
    rotations=np.array([matrix(normalize(q[31:35])),matrix(mul(r,reference['geom_quat'][1]))])
    require(np.isfinite(positions).all() and np.isfinite(rotations).all(),'Nonfinite target FK')
    return positions,rotations

def reference_model(raw, expected_hashes):
    """Bind all 14 full live Model arrays to the archived model, then check scope."""
    require(set(raw)==set(FIELDS),'Kinematic model roster differs')
    for name,value in raw.items():
        require(hashlib.sha256(value.tobytes()).hexdigest()==expected_hashes['Model.'+name],
                'Kinematic Model pin differs: '+name)
    require(raw['geom_bodyid'][84]==18 and raw['geom_bodyid'][49]==11,'Geom owner differs')
    for body,adr,parent in zip(BODY,QADR,(2,8,9,10)):
        j=int(raw['body_jntadr'][body])
        require(raw['body_parentid'][body]==parent and raw['body_mocapid'][body]==-1
                and raw['body_jntnum'][body]==1 and raw['jnt_type'][j]==3
                and raw['jnt_qposadr'][j]==adr,'Head hinge topology differs')
        require(np.all(raw['jnt_pos'][0,j]==0) and raw['qpos0'][0,adr]==0,'Off-center/ref joint outside scope')
    for body,adr in ((2,0),(18,28)):
        j=int(raw['body_jntadr'][body])
        require(raw['body_jntnum'][body]==1 and raw['jnt_type'][j]==0
                and raw['jnt_qposadr'][j]==adr and raw['body_mocapid'][body]==-1,'Free body differs')
    require(np.all(raw['geom_pos'][0,84]==0) and np.array_equal(raw['geom_quat'][0,84],[1,0,0,0]),'Sphere offset differs')
    ids=[int(raw['body_jntadr'][i]) for i in BODY]
    ref=dict(body_pos=raw['body_pos'][0,list(BODY)].astype(float),
             body_quat=raw['body_quat'][0,list(BODY)].astype(float),
             jnt_axis=raw['jnt_axis'][0,ids].astype(float),
             geom_pos=raw['geom_pos'][0,[84,49]].astype(float),
             geom_quat=raw['geom_quat'][0,[84,49]].astype(float))
    with np.load(ROOT/'source-reference/kinematics-reference.npz',allow_pickle=False) as z:
        for name,value in ref.items():
            require(np.array_equal(value,z[name]),'Offline/live FK parameters differ: '+name)
    return ref

def pose_input(native, accumulator, dt, stage=None, previous_velocity=None):
    """Derive a read-only stage pose using the already-reviewed accumulation rule."""
    require(native.dtype==np.float32 and native.shape==(1,35) and np.isfinite(native).all(),'Native pose layout differs')
    acc=np.asarray(accumulator,np.float64)
    require(acc.shape==(1,23) and np.isfinite(acc).all(),'Accumulator layout differs')
    q=native[0].astype(np.float64)
    if stage in (None,0):
        require(acc.astype(np.float32).tobytes()==native[:,Q].tobytes(),'Compensated boundary/native mismatch')
        exact=acc.copy();proof=None
    else:
        require(type(stage) is int and stage in (1,2,3),'RK stage differs')
        require(previous_velocity.dtype==np.float32 and previous_velocity.shape==(1,32),'RK velocity layout differs')
        start=native.copy();start[:,Q]=acc.astype(np.float32)
        # Enforce the unchanged original roundoff bound without writing the proposal.
        _,proof=batch_stage_position(acc,start,previous_velocity,native,dt,stage,('all',))
        exact=acc+dt*(.5 if stage in (1,2) else 1.)*previous_velocity[:,V].astype(np.float64)
    q[Q]=exact[0]
    require(np.isfinite(q).all(),'Compensated pose overflow')
    return q,dict(stage=stage,accumulator=acc.tolist(),dt=dt,
                  previous_velocity=None if previous_velocity is None else previous_velocity.tolist(),
                  qpos_native=native.tolist(),qpos_geometry=q.tolist(),
                  original_stage_bound_checked=proof is not None,
                  native_qpos_written=False,quaternions_changed=False)

class KinematicPrecision:
    def __init__(self,m,d,wp,gate,out,plan):
        import precise_pose_kernel as kernels
        self.m,self.d,self.wp,self.gate,self.plan=m,d,wp,gate,plan
        self.kernels=kernels;self.engine=None
        raw=gate.limited('Kinematic_model_capture',1,lambda:{n:getattr(m,n).numpy().copy() for n in FIELDS})()
        pins=read(ROOT/'origin/macro-68/raw/record-00001-snapshot.json')['model_hashes']
        self.reference=reference_model(raw,pins)
        np.savez_compressed(out/'kinematic-model.npz',**raw)
        self.positions=gate.limited('Kinematic_allocation',2,lambda:wp.zeros((1,2),dtype=wp.vec3d,device=d.qpos.device))()
        self.rotations=gate.limited('Kinematic_allocation',2,lambda:wp.zeros((1,2),dtype=wp.mat33d,device=d.qpos.device))()
        require(self.positions.numpy().nbytes+self.rotations.numpy().nbytes==192,'Kinematic allocation differs')
        gate.limited('Kinematic_module_load',1,lambda:wp.load_module(kernels,device=d.qpos.device))()

    def compute(self,boundary):
        e=self.engine;require(e is not None and e.data is self.d and e.model is self.m,'Kinematic engine owner differs')
        require(hasattr(e,'acc') and e.acc.enabled.tolist()==[True],'Existing compensated accumulator required')
        stage=len(e.stages) if e.phase=='micro' else None
        steps=int(e.acc.steps[0])
        if stage is None:
            require(steps==boundary.resolution and (boundary.phase=='commit' or boundary.trial_calls==4*steps),'Unexpected endpoint FK')
        else:
            require(0<=stage<4 and boundary.phase=='trial' and boundary.trial_calls==4*steps+stage,'FK/RK stage sequence differs')
            require(e.start[:,Q].tobytes()==e.acc.expected.tobytes(),'RK accumulator/start binding differs')
        velocity=e.stages[-1]['qvel'] if stage not in (None,0) else None
        q,proof=pose_input(self.d.qpos.numpy(),e.acc.value,e.dt,stage,velocity)
        proof['micro_index']=steps
        p,r=fk(q,self.reference)
        def upload():
            self.positions.assign(p[None]);self.rotations.assign(r[None])
        self.gate.limited('Kinematic_pose_upload',self.plan['caps']['GPU_forward'],upload)()
        require(self.positions.numpy().tobytes()==p[None].tobytes() and self.rotations.numpy().tobytes()==r[None].tobytes(),'Double pose upload differs')
        return p,r,proof
