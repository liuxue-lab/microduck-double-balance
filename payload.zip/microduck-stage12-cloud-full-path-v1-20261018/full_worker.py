"""Single spawned owner, 24 real public steps, explicit reset and one further step."""
import argparse
import os
import sys
import time
import traceback
from pathlib import Path
from static_common import ROOT,SCOPE,load_run,read,require,write


def execute(run,plan,started):
    candidate=run/'inputs/candidate';repo=run/'inputs/project';base=candidate/'baseline/g11'
    os.environ['MD12_FULL_RUN_DIRECTORY']=str(run)
    sys.path[:0]=[str(candidate),str(base),str(base/'accepted'),str(base/'host-candidate')]
    from full_plan import fingerprint
    from full_processes import OwnerProcesses
    from integration.process_vector import tensor_wire
    from runtime_accounting import review_ledger
    import torch
    from tensordict import TensorDict
    owner=plan['owner_plan'];out=run/'native'
    auth=dict(authorization='USER_AUTHORIZED_NATIVE_MEASUREMENT',scope=SCOPE,
              owner_plan_sha256=fingerprint(owner),canonical_before=plan['canonical_integrations_before'],
              native_stop_utc=started['native_stop_utc'],stop_utc=started['stop_utc'],PPO=0,cloud_training=0)
    report=dict(status='FULL_PATH_STARTED',errors=[],completed_public_steps=0,PPO=0,cloud_training=0)
    start=time.monotonic();timings=[]
    try:
        with OwnerProcesses(repo,out,[owner],[auth],torch,TensorDict,
                            timeout_seconds=max(1,started['native_stop_utc']-time.time())) as env:
            before=env.inspect()[0];env.get_observations();env.get_observations();after=env.inspect()[0]
            keys=('counts','rng_sha256','observation_sha256','resets','episode_length')
            require(all(before[k]==after[k] for k in keys),'Cached observations caused native/public work')
            write(out/'cached-observation-review.json',dict(before=before,after=after,passed=True))
            action=torch.zeros((1,14),dtype=torch.float32)
            for i in range(25):
                if i==24:
                    old=env.inspect()[0];env.reset([0]);reset=env.inspect()[0]
                    require(reset['resets']==old['resets']+1 and reset['episode_length']==[0]
                            and reset['public_tick']==0,'Explicit reset did not restore episode origin')
                    env.reset([]);empty=env.inspect()[0]
                    require(all(reset[k]==empty[k] for k in keys),'Empty reset changed native owners')
                    write(out/'explicit-reset-review.json',dict(before=old,after=reset,after_empty=empty,passed=True))
                t=time.monotonic();obs,reward,done,extras=env.step(action);witness=env.inspect()[0]
                elapsed=time.monotonic()-t;timings.append(elapsed)
                require(witness['public_steps']==i+1 and witness['macros']==10*(i+1),
                        'Duplicated or incomplete public/macro clock')
                write(out/('public-step-%03d.json'%(i+1)),dict(index=i+1,wall_seconds=elapsed,
                    observations=tensor_wire(obs),reward=tensor_wire(reward),done=tensor_wire(done),
                    extras=tensor_wire(extras),witness=witness),exclusive=True)
                report['completed_public_steps']=i+1
                write(out/'campaign-progress.json',dict(completed=i+1,total=25,percent=100*(i+1)/25,
                    elapsed_s=time.monotonic()-start,original_native_points='2/5',PPO=0,cloud_training=0))
            final=env.inspect()[0]
            require(final['macros']==250 and final['public_steps']==25,'Full-path completion differs')
            report['final']=final
        closeout=read(out/'owner-closeout.json')
        require(closeout['all_clean'],'Owner did not close cleanly')
        report.update(status='FULL_PATH_COMPLETE_REVIEW_REQUIRED',closeout=closeout,
            rollout_steps=24,post_reset_steps=1,cached_observation_and_explicit_empty_reset_pass=True,
            timed_steps_excluding_first_warmup=23,timed_wall_seconds=sum(timings[1:24]),
            public_transitions_per_second=23/sum(timings[1:24]),
            throughput_scope='23 synchronized public transitions including IPC/audit after one warmup; no stable-rate or training claim')
    except BaseException as exc:
        report['status']='FULL_PATH_STOPPED_PRESERVE';report['errors'].append(dict(error=repr(exc),traceback=traceback.format_exc()))
    finally:
        report['elapsed_s']=time.monotonic()-start
        ledger=out/'owner-0/native-ledger.jsonl'
        report['ledger']=review_ledger(ledger) if ledger.exists() else None
        before=plan['canonical_integrations_before']
        report['canonical_before']=before
        if report['ledger'] is not None:
            l=report['ledger']
            report['canonical_after_interval']={k:before[k]+l['integration_'+k]
                for k in ('attempted_lower','attempted_upper','completed_lower','completed_upper')}
        write(run/'full-path-report.json',report,exclusive=True)
    return 0 if report['status']=='FULL_PATH_COMPLETE_REVIEW_REQUIRED' else 2


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--run-dir',type=Path,required=True);a=parser.parse_args()
    run,receipt,plan=load_run(a.run_dir);started=read(run/'started.json')
    require(started['explicit_cli_scope']==SCOPE and started['parent_pid']==os.getppid(),
            'Use the fixed parent launcher; direct execution refused')
    sys.exit(execute(run,plan,started))
