# Stage 11 独立头顶接触物理验证交接（进行中）

## 2026-10-03 23:16 获批 C1/C2 接触刚度诊断（唯一当前入口）

用户回复“是继续”，批准上一份审查报告列明的两组诊断。Stage11Status 仍为 MATERIAL_BLOCKED_REVIEW_REQUIRED，阶段未完成。此交付只实现获批范围，本机 C1/C2 尚未运行，新增真实积分 0；保护测试 14 passed、0 skipped，积分调用全部模拟。旧五组入口、v2 验证器、物理工厂和其余旧文件逐字节保留。

五组本机诊断已由用户正常 SSH 推送到 `stage11-floor-impact-transfer-20261003t141958z`，固定提交 `fe2db584e9b8fc391f9014e0e3401b4ceef9f5e5`。A0 时刻、距离、六维接触力精确复现；五组均 PENETRATION_BLOCKED，新增 14 步，原材料 4697 步，加总本机 4711 步。原最大积分前穿透 A0/A1/A2/B1/B2 分别 2.667188/1.003594/1.059542/1.003594/1.235800 mm；均未完成 50 ms，不称作完整碰撞峰值。最后积分后重叠另列，详见 [审查](../audits/stage-11-floor-impact-review.json)。

已读取完整新诊断 ZIP（SHA256 `dd42f05c240f45127731c87d9ad96079ced3c204588b505d762be804467f4f52`），59 项清单哈希匹配；10 个 Git blob 核验完成。原本机 MP4 已实际解码并检查全部 12 个编码帧，SHA256 `c55a11f706dc097e3103d6529d8601f010603d98505a2257313e186bef4b9335`：球沿曲面滚落后触地，画面未见额外板。助手视觉审查完成不等于用户验收，也不等于策略成功。旧归档中的 PENDING 保持历史原样，不倒填。整份旧 v2 ZIP 由本机核验，本环境未独立下载其全部字节。

新矩阵固定：C1 dt=0.5 ms、C2 dt=0.25 ms，两组球 geom solref=(0.001,1)，有效法向时间常数均 1 ms；每组最多 50 ms、100/200 步，共最多 300 步、墙钟 300 s，CPU only，0 PPO、0 云计算、0 整机积分。改变限于私有内存模型副本的 dt 和球 solref[0]；此参数不是全局“仅地面”参数，任何非预期头壳接触即停。摩擦、solimp、阻尼比、refsafe、margin/gap、掩码、质量/质心/完整惯量、几何、重力、求解器选项均冻结；不得据此改正式 Stage 03/04。

每组从同一本机保存状态 index=195、t=0.390 s 起步，qpos/qvel 和自由落体 warm-start 重建须与已存 A0 一致；不称完整历史状态恢复。校验原 v2 与五组归档 ZIP、实际输入、旧源文件以及 A0 的运行版本/Python 字符串和基线；复用 A0 成功证据，不重跑 A0 或五组。任一不符，积分前停止。

原积分前 1 mm 门槛保留；新增独立 MjData 的零积分 mj_forward 几何检查，记录每个积分后状态（含末帧）的重叠和非预期接触，不改变主积分数据或 warm-start。任一保存相位穿透 >1 mm 即停止该组；仅已知穿透失败可进入下一获批组，未知错误终止整个矩阵。记录法向冲量、反弹/末态速度、对齐时间差异；不凭两种步长宣称收敛或材料标定。

准确下一步命令（下载到既定目录后）：

```bash
python3 '/home/lx/下载/microduck-stage11-floor-stiffness.py'
```

安装器不联网、不安装依赖、不推送、不创建代码提交或完成标签。它核对 HEAD `056eaf2b0c78261f34e3fa581858c8573cab981e`、旧注释标签、SSH origin 和已知 12 个源/文档文件；新增四个文件，备份后更新本交接，其余 11 个旧文件不变。未知修改停止，不覆盖。重复运行同一包只报告已有记录，不自动重跑。`--verify-only` 仅预检，无写入或仿真。

输出 `/home/lx/microduck-double-balance/artifacts/double-balance-stage11/floor-stiffness/<UTC>/`，独立归档分支 `stage11-floor-stiffness-transfer-<utc>`；脚本打印用户手动 Git SSH push 命令，正常输出即可，不重复完整远端核验、不合并归档分支。超时保留 completed/attempted 计数及其不确定性，不把未知假称 0。旧原材料与五组目录及 ZIP 保留。HEAD、标签、基线跟踪区、输入归档和已安装源文件会在归档前再次检查不变。

若 C1/C2 都通过，只记 SHORT_IMPACT_CANDIDATE_REVIEW_REQUIRED，Stage 11 仍未完成。完整 13×2 材料验证、正式任务迁移、训练不自动启动。原 9 个 CPU、13 个 CUDA 案例仍 NOT_RUN；本轮不渲染新仿真视频，保存逐步状态供回传审查和必要的零积分渲染。

继续遵守 [本机 SSH 协议](microduck-local-ssh-push-protocol.md) 与 [云 GPU/回传协议](microduck-cloud-gpu-and-transfer-protocol.md)，固定仓库 `/home/lx/microduck-double-balance/workspace`、下载 `/home/lx/下载`。本机 RTX 5060 仅代码/仿真/推理/视频；云 5090 延续 OFF_CONFIRMED_BY_USER，本轮无新云会话/提醒/启停。Stage 09 全量原始轨迹未回传，禁止删除。未来必要回传 SHA256 完成即提醒手动关机，提醒与实际确认分开记录。不重跑旧收尾、CI 修复、Stage 06 smoke 或自动关机守护。

Stage 08 主模型、历史 652/768（84.90%）、Stage 10 B1/C1 缺口及未证明的因果链继续保留。正式观测/初态/奖励/验收参考系另审；10 s 回合、终局连续至少 5 s、无辅助、下球 <=0.15 m/s 及计时边界不变。固定头材料测试不计策略成功，整机头颈不锁，暂停头部纠偏，允许调整转头后回正。

下文均为历史快照，其中命令不再作为当前下一步。


## 2026-10-03 21:43 已批准的五组落地诊断（当前入口）

用户已回复“是，继续”，批准 [五组诊断计划](../audits/stage-11-floor-impact-diagnostic-plan.json)。只对已保存材料模型的独立副本做 CPU 参数对照：A0=(dt 2 ms, solref0 3 ms)、A1=(1,3)、A2=(0.5,3)、B1=(1,4)、B2=(0.5,4)，时间单位均为 ms。A0/B1/B2 固定法向有效时间常数为 4 ms，用于区分步长与 refsafe 柔顺性影响。每组最多 50 ms，总积分≤325 步、诊断墙钟≤5 分钟。未授权正式物理/任务迁移或训练。

当前状态仍为 **MATERIAL_BLOCKED_REVIEW_REQUIRED；Stage 11 未完成**。本机 v2 归档分支 `stage11-physics-v2-transfer-20261003t094423z` 已由用户正常 SSH 推送，固定提交 `51df1774385fec998b8a8e7f7dcfcde5f5a10a27`。13 项本机测试全部通过；质量/质心/完整惯量通过；v2 静态 49/49 通过，旧 v1 的 7 项 BLOCKED 保留。前三个 CPU 材料例各 1500 步，第四例 197 步时首次落地穿透 2.667188 mm，合计 4697 步；后续 9 个 CPU 和全部 13 个 CUDA 例未运行。四例摘要除墙钟外、最后接触行全部字段与隔离 CPU 证据一致。见 [本机材料审查](../audits/stage-11-local-material-review.json)。

隔离环境已完成诊断代码及 11 项针对性保护测试（全过、无跳过；积分调用均为模拟调用，真实动力学步为 0）。**新的五组诊断尚未在本机执行**，A0 重建和四组参数对照结果不能预填。没有在隔离环境重复这 5 组以增加用户批准之外的步数。

本次只读旧证据并创建新诊断输出。旧 ZIP SHA256 `d2c6cb2c788ee3b7020f6557dac1e0646940bebd43b290dc4b3f5c6e8110278d`；本次远程只读并校验 12 个文本 Git blob，未下载 ZIP、完整 NPZ/压缩轨迹或 MP4，视频人工审查仍 PENDING。诊断脚本将在本机先核验旧 ZIP 全字节 SHA256，并将读取的输入逐个对照 ZIP 和清单，再进行已有轨迹的零积分代数复核；复制原 MP4、导出 4 个关键帧，便于通过下一归档读取，不能自动标记人工视频审查完成。

初始化采用本机旧 `local-v2/cpu/release-y-minus12/states.npz` 中索引 195、t=0.390 s 的 qpos/qvel。显式重建派生量、warm-start 并记录；不称作完整历史状态恢复。A0 的首次接触时刻、距离和力分量必须满足计划中的原始记录对照容差，否则停止整个矩阵。已获批的各组在超过原 1 mm 门槛时终止该组并记录 PENETRATION_BLOCKED；按预先批准的矩阵可从相同初态进入下一组。任何非预期接触、非有限量、来源不符、A0 不符、预算超限都停止矩阵。原 v2 验证器整体 fail-fast 逻辑完全未改，诊断 PASS 也不解除原材料验证阻塞。

当前准确命令：

```bash
python3 '/home/lx/下载/microduck-stage11-floor-impact.py'
```

交付包只新增诊断脚本、其针对性测试、两份审查 JSON，并备份后更新本交接；原八个 Stage 11 文件中其余七个逐字节保留，基线 Stage 03/04 等跟踪文件不变。旧物理工厂与 v2 验证器分别保持 SHA256 `8a2446aa27d8e420e6e26e5e9985ab24cb774036936f393de680857edfd0af64`、`d5f88ffc2a65c3d98a6714d8aa67b8bffe8144f81be6e1d1fd6d89dcb908067c`。脚本先检查实际本机 HEAD、旧注释标签、SSH origin、已知 v2 文件和旧证据，不安装/升级依赖，不联网、不推送、不创建代码提交或完成标签。

输出位于 `/home/lx/microduck-double-balance/artifacts/double-balance-stage11/floor-impact/<UTC>/`，原物理证据目录保留。复核小包在新的独立归档仓库创建本机提交，只打印用户手动 Git SSH push 命令。重复运行同一包只报告已有结果，不自动重跑；`--verify-only` 只检查输入，无源文件写入、测试或积分。版本/文件/HEAD 不符保留现场，不能 reset/force、覆盖未知内容或重跑旧脚本。若诊断超时，读取 progress.json 中完成/尝试步数，不把未知计步假称 0。

下一轮读取归档后，先审查本机视频、相邻状态、A0 再现和四组对照。候选参数即使通过也只代表此 50 ms 材料片段；正式变更数值参数、完整 13×2 矩阵、任务迁移、PPO 均仍需单独审查，不自动延伸。正常推送输出足够，不重复完整远端核验，不合并归档分支。

继续保留下文固定路径、两份 SSH/云协议、旧标签和模型 SHA、关机状态与提醒规则、Stage 09 未回传数据、B1/C1 缺口、正式 10 s/终局 5 s/无辅助/0.15 m/s 标准。云 5090 保持 OFF_CONFIRMED_BY_USER，本轮云小时和 PPO 均为 0。

以下 v2/v1 段落为历史快照，旧命令不再是当前下一步。

## 2026-10-03 v2 当前入口（优先于下文 v1 历史快照）

用户在北京时间 17:06:09 询问“这是目前的最优解吗 如果是继续”。结论是现有证据下更有依据的下一步，不是已证明的全局最优。已按条件授权实施所提 v2 几何判据：表面距离≤0.2 mm、球壳间隙差≤0.2 mm、法线差≤5°；旧点对点 0.2 mm 结果继续记录，不改写旧 BLOCKED。通过 `--geometry-gate v2` 明确选择；脚本默认仍为 v1，不隐式绕过旧门槛。

本机 v1 归档已由用户正常 SSH 推送至 `stage11-physics-transfer-20261003t073525z`，提交 `0ecdb2959ca649349ad52e7609f91dc4329a9b90`。9 项测试全部通过，原静态 42/49 通过，质量/完整惯量通过。读取 10 份文本并校验 Git blob，未下载整个 ZIP，不声称已完成该 ZIP 的字节回传 SHA256。

本轮隔离 CPU 结果见 [v2 审查](../audits/stage-11-geometry-gate-v2-review.json)：静态 v2 49/49 PASS，v1 仍有 7 项 BLOCKED。材料测试依次完成 center、x-minus12、x-plus12；第 4 例 y-minus12 在首次地面接触触发 1 mm 穿透门槛，最大 2.667188 mm，因此整套仍 BLOCKED。该例头壳接触最大穿透 0.084472 mm。还未开始的 9 个 CPU 和 13 个 CUDA 案例均 NOT_RUN，未继续滑移/滚动/自旋专项。

相邻保存状态表明：t=0.390 s 球底距地 0.640381 mm、竖直速度 -1.634165 m/s；原定 2 ms 自由落体积分后，t=0.392 s 的球底为 -2.667188 mm。随后接触法向力 10.117701 N 对 10 g 球的速度改变量也与日志一致。这是本例首次落地离散跨越的证据，**不构成提高门槛或改时间步的授权**，也不证明整个任务的正式动力学已验收。

隔离材料积分共 4697 步，另有独立解析平面夹具的 Warp CPU 接口检查 4 步；整机积分 0、PPO 0、云计算 0。针对性测试 12 passed、1 skipped；完整本机 Scene v2 检查与 RTX 5060 CUDA 仍待执行。接口 CPU PASS 不冒充 CUDA 结果。物理工厂 SHA256 未变：`8a2446aa27d8e420e6e26e5e9985ab24cb774036936f393de680857edfd0af64`。

原始失败视频未包含末次采样的缺口已记录并保留文件；重新从保存状态渲染最终 pre/post 帧，叠加实际时间、穿透、滑移及世界法线数值。没有为视频新增物理步。视频仅展示固定材料夹具；球滚落并不等于策略验收样本。

当前唯一下一步命令：

```bash
python3 '/home/lx/下载/microduck-stage11-physics-v2.py'
```

该离线续跑包校验本机 HEAD、旧标签、SSH origin、v1 文件哈希与既有本机 v1 静态证据；先备份已知 v1 新增文件，再更新明确列出的 Stage 11 文件，新增两份审查 JSON。现有 Stage 03/04 等基线跟踪文件保持不变。它运行本机针对性测试、v2 静态矩阵，然后按原矩阵顺序运行 CPU；任何失败即停，CPU 全部通过才进入 CUDA。每例≤3 s、2 ms 步长，总验证墙钟≤45 min。已存在本包执行记录时不自动重跑。`--verify-only` 不导入或运行。

结果与源文件备份放在 `/home/lx/microduck-double-balance/artifacts/double-balance-stage11/physics/<UTC>/`，原 `/physics/20261003T073525Z/` 保持不变。小型复核 ZIP 及必要文本会在新的独立本机归档仓库提交，脚本只打印 SSH push 命令，用户手动推送；不要合并归档分支。返回正常输出即可，不重复完整远端核验。不创建 `stage-11-complete`，本阶段仍未收尾。

若本机复现 2.667 mm 地面穿透：停止，先审查报告；不可自动改 dt、margin、gap、solref、摩擦、solver、1 mm 判据，也不可删掉地面接触来放行。若本机得到不同结果，同样保留差异并按具体日志判断，不进行无判别目标重复诊断。后续任何正式物理或任务变更仍需单独说明理由、影响并确认。

以下为 v1 历史快照，其中旧交付命令不再作为下一步执行。

当前状态：**静态几何门槛阻塞；Stage 11 未完成**。新增 PPO 0，物理积分步 0，云计算 0，无新策略。未创建或移动阶段完成标签，正式 Stage 03/04 文件、任务、奖励、验收及模型未改。

## 已完成与证据限制

固定审查源码为 `056eaf2b0c78261f34e3fa581858c8573cab981e`，包括 Stage 10 publication-confirmation 补记。本机路径不可访问；本次隔离 CPU 检查从固定源码提取原工厂函数，使用全部原网格组装诊断场景。它不是本机完整 mjlab Scene 的验收结果。完整 Scene 测试仍待本机执行；当前针对性测试 8 passed、1 skipped。

[计划](../audits/stage-11-physics-plan.json)规定独立工厂只删除新建 spec 的 18 g 托盘子树，并给原始头壳碰撞体分配新接触位；上球只接触头壳和地面。不加平面、不提高摩擦、不锁整机头颈、不注册 RL 任务。

[审查数据](../audits/stage-11-physics-review.json)含完整质量、质心、3×3 惯量和 49 个静态点/姿态证据。机器人质量从 0.75524318 kg 变为 0.73724318 kg；含两球场景从 1.38524318 kg 变为 1.36724318 kg。质量及平行轴重组检查通过。

静态检查 42/49 通过，7/49 在 `y +12 mm` 触发接触位置 0.2 mm 门槛，最大约 0.249685 mm，法线最大约 0.697865°。完整提取模型的单点距离复核同样出现约 0.249660 mm 差异。独立逐面算法检查全部 16120 个原始面，复现原网格最近点；CPU 引擎点与凸包最近点一致到约 1.9e-8 m。这里是最近接触点的主要切向差异，不是同等深度的穿透，也不能据此宣布 Warp 接触机制已证明。

原始隔离运行还遭遇 `mj_saveLastXML: No XML model loaded`，失败 JSON 和错误日志保留；已改用编译模型 MJB 并验证重新加载，补了失败门槛阻止后续动力学的测试。没有重跑完整静态矩阵，也没有进行动力学重试。初始工具版本未在修复前记录代码哈希，保留此限制；交付版本有清单哈希。

动态 13 × 2 后端矩阵、穿透、有效摩擦、滑移、RTX 5060、动力学视频均 **NOT_RUN**。固定头材料测试永远不等于无辅助策略成功。摩擦 μ=0.6 沿用既有模拟假设，尚不是实体材料标定；condim=4 不提供滚动摩擦。所有既定阈值保留。

## 下一步准确命令

固定源码目录 `/home/lx/microduck-double-balance/workspace`，下载目录 `/home/lx/下载`。

```bash
python3 '/home/lx/下载/microduck-stage11-physics.py'
```

交付脚本先核对本机分支/基线、干净的既有跟踪文件、旧标签和 SSH remote，再校验内嵌增量 Git bundle，仅新增列明的六个文件。默认只运行本机已有 `.venv/bin/python` 的针对性测试和 `--static-only` 验证，不安装依赖、不联网、不推送、不训练、不做动态步。结果写入 `/home/lx/microduck-double-balance/artifacts/double-balance-stage11/physics/<时间戳>/`，生成带 SHA256 的小型复核 ZIP。已有结果不会自动重跑；重复执行只报告已有目录。参数 `--verify-only` 只核对，不写入仓库或运行检查。

脚本暂不创建本机提交：本阶段仍有阻塞，复核包会在独立本机归档仓库创建提交，打印准确的 Git SSH push 命令；由用户推送该归档分支，绝不合并到代码分支。先返回最后的 `Stage11Evidence` / `Stage11ReviewZip` 输出和正常 push 输出。收集本机静态结果后判断碰撞表示是否需要另行审查；不通过改阈值、提高摩擦、改变 solver 或删除测试点来继续。只有审查解除阻塞后，才讨论已规划动态矩阵的执行。不可默认把当前 CPU/Warp 未执行分支当成已经验证。

## 固定规则与已知错误

继续遵守[本机 Git SSH 规范](microduck-local-ssh-push-protocol.md)和[云 GPU/传输规范](microduck-cloud-gpu-and-transfer-protocol.md)。代码 `double-balance` 与模型/大轨迹归档分支分开，绝不合并归档分支；默认 Git SSH 上传/取文件。隔离开发通过增量 Git bundle 交付，不切换本机认证。后续本机创建提交/注释标签，用户 SSH 推送；正常 push 输出足够，不重复完整远端核验。

```bash
cd /home/lx/microduck-double-balance/workspace
git status --short --branch
git rev-parse HEAD
git rev-parse 'stage-10-complete^{}'
# 仅阶段评估、归档、交接和本机提交完成后，由用户执行：
git push origin double-balance
```

旧标签 `stage-10-complete` 固定在 `1a11f30cc7264d00dec7bce8f11449ded9164169`。不重跑旧 finalize/ci-fix/A/B/C/Stage 06 smoke。293900b 的 CI 36892445739 已成功（416 passed、6 skipped、3 warnings、17 subtests passed），不重新归档修复，更不能把旧 CI 认证归给 Stage 11。

常见错误：HEAD 与基线不符先报告实际 SHA，禁止 reset/force；已有目标文件若内容不符停止，禁止覆盖；版本不符禁止自动 uv sync 升降级；仓库暂存区/既有跟踪文件有修改时先保留现场；不存在 publication-confirmation 时只说明补记未应用，不倒填；验证 BLOCKED 不是策略失败率样本。精确重跑指令只能在审查具体失败之后给出，禁止无判别目标重复诊断。

主模型仍为 Stage 08 E/20260929/update_004000.pt，SHA256 `86d55c3703c18fcf4817db49c6e4dcf839b3f5195d68ae2c559db7e222bded97`。历史独立严格成功 652/768=84.90%；Stage 10 重复开发集不并入。B1/C1 事后检查缺口保留；浮点累加次序解释有证据，完整因果链仍未证明。

旧标准继续是 10 秒回合、终局连续稳定至少 5 秒、无辅助、下球速度上限 0.15 m/s；计时边界不改。正式迁移需要另行审查上球观测/初态/奖励/验收参考系，相同维度不是语义兼容。暂停头部纠偏，允许调整时转头、稳定后回正，不默认一直朝前。

RTX 5060 仅代码、MuJoCo 仿真、推理和视频。RTX 5090 状态 `OFF_CONFIRMED_BY_USER`，本阶段没有新云会话、关机提醒或操作。禁止自行启停、旧自动关机守护、删除尚未全部回传的 Stage 09 云原始轨迹。未来计算及必要回传 SHA256 完成后，立即提醒用户手动关机；提醒时间和用户实际确认分开记录。

任何后续训练必须先提交初始化检查点、归一化/Adam/学习率/iteration/common_step_counter/课程/辅助状态的恢复或重置规则，以及组数、种子、新增 PPO、评估间隔、云 GPU 时长费用和停止条件，另行获批。
