# Stage 11 独立头顶接触物理验证交接（进行中）

## 2026-10-03 v2 当前入口（优先于下文 v1 历史快照）

用户在北京时间 17:06:09 询问“这是目前的最优解吗 如果是继续”。结论是现有证据下更有依据的下一步，不是已证明的全局最优。已按条件授权实施所提 v2 几何判据：表面距离≤0.2 mm、球壳间隙差≤0.2 mm、法线差≤5°；旧点对点 0.2 mm 结果继续记录，不改写旧 BLOCKED。通过 `--geometry-gate v2` 明确选择；脚本默认仍为 v1，不隐式绕过旧门槛。

本机 v1 归档已由用户正常 SSH 推送至 `stage11-physics-transfer-20261003t073525z`，提交 `0ecdb2959ca649349ad52e7609f91dc4329a9b90`。9 项测试全部通过，原静态 42/49 通过，质量/完整惯量通过。读取 10 份文本并校验 Git blob，未下载整个 ZIP，不声称已完成该 ZIP 的字节回传 SHA256。

本轮隔离 CPU 结果见 [v2 审查](../audits/stage-11-geometry-gate-v2-review.json)：静态 v2 49/49 PASS，v1 仍有 7 项 BLOCKED。材料测试依次完成 center、x-minus12、x-plus12；第 4 例 y-minus12 在首次地面接触触发 1 mm 穿透门槛，最大 2.667188 mm，因此整套仍 BLOCKED。该例头壳接触最大穿透 0.084472 mm。还未开始的 9 个 CPU 和 13 个 CUDA 案例均 NOT_RUN，未继续滑移/滚动/自旋专项。

相邻保存状态表明：t=0.390 s 球底距地 0.640381 mm、竖直速度 -1.634165 m/s；原定 2 ms 自由落体积分后，t=0.392 s 的球底为 -2.667188 mm。随后接触法向力 10.117701 N 对 10 g 球的速度改变量也与日志一致。这是本例首次落地离散跨越的证据，**不构成提高门槛或改时间步的授权**，也不证明整个任务的正式动力学已验收。

隔离材料积分共 4697 步，另有独立解析平面夹具的 Warp CPU 接口检查 4 步；整机积分 0、PPO 0、云计算 0。针对性测试 12 passed、1 skipped；完整本机 Scene v2 检查与 RTX 5060 CUDA 仍待执行。接口 CPU PASS 不冒充 CUDA 结果。物理工厂 SHA256 未变：`8a2446aa27d8e420e6e26e5e9985ab24cb774036936f393de680857edfd0af64`。

原始失败视频未包含末次采样的缺口已记录并保留文件；重新从保存状态渲染最终 pre/post 帧，叠加实际时间、穿透、滑移及世界法线数值。没有为视频新增物理步。视频仅展示固定材料夹具；球滚落并不等于策略验收样本。

当前唯一下一步命令：

```bash
python3 '/home/lx/下载/microduck-stage11-physics-v2.py'
```

该离线续跑包校验本机 HEAD、旧标签、SSH origin、v1 文件哈希与既有本机 v1 静态证据；先备份已知 v1 新增文件，再更新明确列出的 Stage 11 文件，新增两份审查 JSON。现有 Stage 03/04 等基线跟踪文件保持不变。它运行本机针对性测试、v2 静态矩阵，然后按原矩阵顺序运行 CPU；任何失败即停，CPU 全部通过才进入 CUDA。每例≤3 s、2 ms 步长，总验证墙钟≤45 min。已存在本包执行记录时不自动重跑。`--verify-only` 不导入或运行。

结果与源文件备份放在 `/home/lx/microduck-double-balance/artifacts/double-balance-stage11/physics/<UTC>/`，原 `/physics/20261003T073525Z/` 保持不变。小型复核 ZIP 及必要文本会在新的独立本机归档仓库提交，脚本只打印 SSH push 命令，用户手动推送；不要合并归档分支。返回正常输出即可，不重复完整远端核验。不创建 `stage-11-complete`，本阶段仍未收尾。

若本机复现 2.667 mm 地面穿透：停止，先审查报告；不可自动改 dt、margin、gap、solref、摩擦、solver、1 mm 判据，也不可删掉地面接触来放行。若本机得到不同结果，同样保留差异并按具体日志判断，不进行无判别目标重复诊断。后续任何正式物理或任务变更仍需单独说明理由、影响并确认。

以下为 v1 历史快照，其中旧交付命令不再作为下一步执行。

当前状态：**静态几何门槛阻塞；Stage 11 未完成**。新增 PPO 0，物理积分步 0，云计算 0，无新策略。未创建或移动阶段完成标签，正式 Stage 03/04 文件、任务、奖励、验收及模型未改。

## 已完成与证据限制

固定审查源码为 `056eaf2b0c78261f34e3fa581858c8573cab981e`，包括 Stage 10 publication-confirmation 补记。本机路径不可访问；本次隔离 CPU 检查从固定源码提取原工厂函数，使用全部原网格组装诊断场景。它不是本机完整 mjlab Scene 的验收结果。完整 Scene 测试仍待本机执行；当前针对性测试 8 passed、1 skipped。

[计划](../audits/stage-11-physics-plan.json)规定独立工厂只删除新建 spec 的 18 g 托盘子树，并给原始头壳碰撞体分配新接触位；上球只接触头壳和地面。不加平面、不提高摩擦、不锁整机头颈、不注册 RL 任务。

[审查数据](../audits/stage-11-physics-review.json)含完整质量、质心、3×3 惯量和 49 个静态点/姿态证据。机器人质量从 0.75524318 kg 变为 0.73724318 kg；含两球场景从 1.38524318 kg 变为 1.36724318 kg。质量及平行轴重组检查通过。

静态检查 42/49 通过，7/49 在 `y +12 mm` 触发接触位置 0.2 mm 门槛，最大约 0.249685 mm，法线最大约 0.697865°。完整提取模型的单点距离复核同样出现约 0.249660 mm 差异。独立逐面算法检查全部 16120 个原始面，复现原网格最近点；CPU 引擎点与凸包最近点一致到约 1.9e-8 m。这里是最近接触点的主要切向差异，不是同等深度的穿透，也不能据此宣布 Warp 接触机制已证明。

原始隔离运行还遭遇 `mj_saveLastXML: No XML model loaded`，失败 JSON 和错误日志保留；已改用编译模型 MJB 并验证重新加载，补了失败门槛阻止后续动力学的测试。没有重跑完整静态矩阵，也没有进行动力学重试。初始工具版本未在修复前记录代码哈希，保留此限制；交付版本有清单哈希。

动态 13 × 2 后端矩阵、穿透、有效摩擦、滑移、RTX 5060、动力学视频均 **NOT_RUN**。固定头材料测试永远不等于无辅助策略成功。摩擦 μ=0.6 沿用既有模拟假设，尚不是实体材料标定；condim=4 不提供滚动摩擦。所有既定阈值保留。

## 下一步准确命令

固定源码目录 `/home/lx/microduck-double-balance/workspace`，下载目录 `/home/lx/下载`。

```bash
python3 '/home/lx/下载/microduck-stage11-physics.py'
```

交付脚本先核对本机分支/基线、干净的既有跟踪文件、旧标签和 SSH remote，再校验内嵌增量 Git bundle，仅新增列明的六个文件。默认只运行本机已有 `.venv/bin/python` 的针对性测试和 `--static-only` 验证，不安装依赖、不联网、不推送、不训练、不做动态步。结果写入 `/home/lx/microduck-double-balance/artifacts/double-balance-stage11/physics/<时间戳>/`，生成带 SHA256 的小型复核 ZIP。已有结果不会自动重跑；重复执行只报告已有目录。参数 `--verify-only` 只核对，不写入仓库或运行检查。

脚本暂不创建本机提交：本阶段仍有阻塞，复核包会在独立本机归档仓库创建提交，打印准确的 Git SSH push 命令；由用户推送该归档分支，绝不合并到代码分支。先返回最后的 `Stage11Evidence` / `Stage11ReviewZip` 输出和正常 push 输出。收集本机静态结果后判断碰撞表示是否需要另行审查；不通过改阈值、提高摩擦、改变 solver 或删除测试点来继续。只有审查解除阻塞后，才讨论已规划动态矩阵的执行。不可默认把当前 CPU/Warp 未执行分支当成已经验证。

## 固定规则与已知错误

继续遵守[本机 Git SSH 规范](microduck-local-ssh-push-protocol.md)和[云 GPU/传输规范](microduck-cloud-gpu-and-transfer-protocol.md)。代码 `double-balance` 与模型/大轨迹归档分支分开，绝不合并归档分支；默认 Git SSH 上传/取文件。隔离开发通过增量 Git bundle 交付，不切换本机认证。后续本机创建提交/注释标签，用户 SSH 推送；正常 push 输出足够，不重复完整远端核验。

```bash
cd /home/lx/microduck-double-balance/workspace
git status --short --branch
git rev-parse HEAD
git rev-parse 'stage-10-complete^{}'
# 仅阶段评估、归档、交接和本机提交完成后，由用户执行：
git push origin double-balance
```

旧标签 `stage-10-complete` 固定在 `1a11f30cc7264d00dec7bce8f11449ded9164169`。不重跑旧 finalize/ci-fix/A/B/C/Stage 06 smoke。293900b 的 CI 36892445739 已成功（416 passed、6 skipped、3 warnings、17 subtests passed），不重新归档修复，更不能把旧 CI 认证归给 Stage 11。

常见错误：HEAD 与基线不符先报告实际 SHA，禁止 reset/force；已有目标文件若内容不符停止，禁止覆盖；版本不符禁止自动 uv sync 升降级；仓库暂存区/既有跟踪文件有修改时先保留现场；不存在 publication-confirmation 时只说明补记未应用，不倒填；验证 BLOCKED 不是策略失败率样本。精确重跑指令只能在审查具体失败之后给出，禁止无判别目标重复诊断。

主模型仍为 Stage 08 E/20260929/update_004000.pt，SHA256 `86d55c3703c18fcf4817db49c6e4dcf839b3f5195d68ae2c559db7e222bded97`。历史独立严格成功 652/768=84.90%；Stage 10 重复开发集不并入。B1/C1 事后检查缺口保留；浮点累加次序解释有证据，完整因果链仍未证明。

旧标准继续是 10 秒回合、终局连续稳定至少 5 秒、无辅助、下球速度上限 0.15 m/s；计时边界不改。正式迁移需要另行审查上球观测/初态/奖励/验收参考系，相同维度不是语义兼容。暂停头部纠偏，允许调整时转头、稳定后回正，不默认一直朝前。

RTX 5060 仅代码、MuJoCo 仿真、推理和视频。RTX 5090 状态 `OFF_CONFIRMED_BY_USER`，本阶段没有新云会话、关机提醒或操作。禁止自行启停、旧自动关机守护、删除尚未全部回传的 Stage 09 云原始轨迹。未来计算及必要回传 SHA256 完成后，立即提醒用户手动关机；提醒时间和用户实际确认分开记录。

任何后续训练必须先提交初始化检查点、归一化/Adam/学习率/iteration/common_step_counter/课程/辅助状态的恢复或重置规则，以及组数、种子、新增 PPO、评估间隔、云 GPU 时长费用和停止条件，另行获批。
