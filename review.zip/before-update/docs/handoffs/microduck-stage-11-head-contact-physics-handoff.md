# Stage 11 真实头顶接触物理交接

## 2026-10-04 03:29 继续零积分参考系静态审查（当前唯一入口）

用户回复“继续”，承接六组摩擦审查报告第 6 节，授权制作和运行独立参考点/坐标语义静态验证包。仅编译、设置独立审查数据 qpos、前向、距离与代数运算；新增积分上限 0、PPO 0、云计算 0。不授权正式物理、初态、奖励、观测或验收迁移。Stage11Status=MATERIAL_BLOCKED_REVIEW_REQUIRED，阶段未完成。

六组摩擦证据已正常 SSH 推送至 `stage11-head-friction-transfer-20261003t183812z`，固定提交 `7c3157818500b357e733a22ae6df54ce3fbcf7b4`。ZIP SHA256 `f692ff89cfdd0b1036570a2eb5cc4a7f679eb49bc407af37e5e3410478dd343d`，4,043,339 字节，68 项文件及六个分片校验通过。本机原始 MJB SHA256 `e6cd330bddc3a29abf9ce4eca4f308a2680e4910405725e5ce054cb0a19d2da0` 本次已完整返回，不再以隔离模型代指。用户正常 push 足够，不重复完整远端核验，不合并归档分支。

六组完成/尝试均 1684 步，物理墙钟约 32.594 s，累计已知本机材料及诊断为 6211+1684=7895 步。两组 FLOOR_PENETRATION_BLOCKED，四组 FLOOR_EVENT_CENSORED；均未完成 3 s。所有末次地面重叠发生在 post-state，pre-state 地面受力步均为 0，不是完整撞击峰值。已记录最大头壳穿透约 0.081–0.087 mm，v2 几何门槛没有失败。世界力/力矩与 1684 组状态更新独立复算一致；18 个瞬时正切向功率样本保留，累计 pre-step 功率估计不作精确机械功或材料标定。三段视频的全部 132 个保存帧已通过联系表和选定原图审查，球沿曲面滚落；固定头材料场景不含完整机器人/下球，不能认作无辅助策略成功。详见 [六组回传审查](../audits/stage-11-head-friction-review.json)。

旧托盘 XY 投影中心的头壳法线偏离竖直约 4.390888°，切向重力分量约 0.751058 m/s²。网格最高顶点相对旧中心向正 X 偏移约 59.307 mm，距 X 最大包围盒边界约 2.041 mm；这不是物理冠部边缘的精确距离，也不能自动选最高点作为平衡中心。

[静态设计](../audits/stage-11-head-reference-design.json)和新增 `scripts/audit_head_contact_reference.py` 使用完整自由关节模型，保留原头颈关节、执行器和范围。七个审查姿态为 HOME 及 HOME 基础上 head_yaw ±90°、head_pitch ±10°、head_roll ±10°，其余关节/root保持 HOME；超限停止不钳位。它们是真实关节配置，区别于旧固定材料夹具的世界轴刚性转动；实际头部世界变换逐一保存，不声称两者相同。

七个位置沿用旧中心、x/y ±12 mm、y ±20 mm。每个姿态/位置明确比较两种几何定义：A 将 HOME 有限半径球心/曲面见证点/法线随 jaw_soft 变换；B 从 A 的**曲面见证点世界 XY**重新求沿世界竖直的有限球支持位置。B 不使用 A 的球心 XY，两者不能混淆。R=20 mm、表面间隙 0.5 mm 沿用原材料值。这些配置只为几何审查，均未被选作任务 reset。49 组主比较最多 98 次几何距离；另仅记录 HOME 最高顶点描述，不新增动力学。

保留 v2 表面距离/球间隙各≤0.2 mm、法线≤5°，旧 v1 结果并列记录。边界同时报告精确重合顶点焊接后的拓扑开边数量/距离及 HOME XY 包围盒余量；后者不能当物理边缘。真实曲面冠部/边缘语义未定义时，physical_rim_distance 保持 null，不编造。头壳封闭网格不存在拓扑开边也不代表可以无限滚动。

速度语义区分旧 `Rᵀ(v_ball−v_origin)`、旋转坐标导数 `Rᵀ(v_ball−v_origin−ω_head×r)`、包含球自旋的接触点滑移。通过真实关节雅可比和 head_yaw ±1e-6 rad 的静态配置差分核对符号；虚拟 1 rad/s 仅为代数测试向量，不是执行指令或物理轨迹。61D 相同不代表模型/归一化语义兼容。

实现测试 14 项通过、无 skipped、无真实积分。首次隔离完整模型检查因简化装配的 robot root HOME z=0.12 相对本机几何多出 120 mm 而停止，原日志保留。只在隔离测试夹具中把 HOME root z 对齐到本机的 0，随后 49 组/98 次距离检查均满足 v2，转动导数误差约 8.15e-12 m/s；两种球心定义差 1.4–8.4 mm。这是隔离工厂提取检查，不替代本机完整 mjlab Scene。没有改本机或脚本中的校验阈值来掩盖差异。

下一步准确命令（下载文件到既定目录后）：

```bash
python3 '/home/lx/下载/microduck-stage11-head-reference.py'
```

安装器离线，核对 HEAD、旧注释标签、SSH origin、24 个旧 Stage 11 文件和五份既有归档 ZIP；新增四文件、备份更新本交接，其余 23 个旧文件字节不变，共 28 个 Stage 11 文件。只导入 bundle 对象并写列明文件，不 checkout/merge/reset，不更新依赖，不创建代码提交或完成标签，不推送。`--verify-only` 可选，只读预检；不必先重复执行。重复运行同一包只显示已有记录，不自动再运行静态检查。

本机以现有 `.venv/bin/python` 跑针对性测试，然后单次 `--static-reference-only`。对 mj_step/step1/step2/Euler/RungeKutta/implicit/integratePos 装拒绝调用保护；任何尝试记录并停止。静态程序总墙钟上限 300 s，外层 360 s；本轮没有渲染、Warp 动力学、策略加载或 PPO。几何失败、来源不符、模型签名变化、静态状态变时、非有限值或未知错误明确 BLOCKED，保留证据；即使全几何通过，只记 STATIC_REFERENCE_REVIEW_REQUIRED。物理/材料/Stage 11 不改判。

结果存 `/home/lx/microduck-double-balance/artifacts/double-balance-stage11/head-reference/<UTC>/`，包括来源校验、结构/质量/质心/完整惯量、候选点/边界定义、49 组比较、静态配置、雅可比差分、模型签名、测试和运行日志。无新视频需求；上一批视频审查随文档归档。独立 `stage11-head-reference-transfer-<utc>` 包含 review.zip、SHA256、768 KiB 字节分片和清单，打印用户手动 SSH push 命令。推送成功后返回摘要和正常 push 输出即可；不重复完整远端核验、不合并到代码分支。

固定仓库 `/home/lx/microduck-double-balance/workspace`，下载 `/home/lx/下载`。代码分支 `double-balance` HEAD `056eaf2b0c78261f34e3fa581858c8573cab981e`；Stage 10 注释标签保持 `1a11f30cc7264d00dec7bce8f11449ded9164169`。既有本机证据根 `/home/lx/microduck-double-balance/artifacts/double-balance-stage11`：原材料 `physics/20261003T094423Z`、五组 `floor-impact/20261003T141958Z`、C1/C2 `floor-stiffness/20261003T170744Z`、C3/C4 `floor-refinement/20261003T173938Z`、六组 `head-friction/20261003T183812Z`。均保留，不重跑其安装器或诊断。

持续遵守 [本机 SSH 协议](microduck-local-ssh-push-protocol.md) 和 [云 GPU/传输协议](microduck-cloud-gpu-and-transfer-protocol.md)：Git SSH 默认上传和取件，代码与模型/证据归档分支分开；本机创建最终提交/注释标签，用户 SSH 推送。常见错误：哈希/运行版本/HEAD/未知修改不符时保留现场，禁止改期望哈希、force/reset、覆盖未知文件或自动 uv sync；包围盒余量≠物理边缘；静态前向≠积分；测试中故意被拦截的 API 调用≠真实物理步；CENSORED≠PASS。已有完整原始 ZIP，分片仅解决连接器大文件返回限制，不是额外证据或新上传协议。

v1 静态 42/49、v2 静态 49/49、原材料落地 2.667188376 mm、五组地面失败、C3/C4 的 2/4 同时刻敏感性失败均保留。原材料剩余 9 CPU + 13 CUDA 未运行，新诊断不回填。Stage 10 B1/C1 事后检查缺口与未证明的完整因果链保留。主模型仍 Stage 08 E/20260929/update_004000.pt，SHA256 `86d55c3703c18fcf4817db49c6e4dcf839b3f5195d68ae2c559db7e222bded97`，历史独立严格成功 652/768=84.90%，不并入开发诊断。

旧验收仍为 10 秒回合、终局连续稳定≥5 秒、无辅助、下球速度≤0.15 m/s，原计时边界不变。暂停头部纠偏，允许调整时转头，稳定后回正，不要求全程朝前。正式删板及上球参考点、初态、观测、归一化、奖励、约束、验收语义需另审精确差异并由用户确认。

本机 5060 仅代码/仿真/推理/视频。云 5090 延续 OFF_CONFIRMED_BY_USER，本次无云会话、启停和新关机提醒/确认。禁止自行启停、旧自动关机守护、Stage 06 smoke、Stage 10 收尾/CI修复或删除尚未完整回传的 Stage 09 云数据。以后云计算及必要回传 SHA256 完成即提醒手动关机，提醒与实际确认分开记录。任何训练仍须先列初始化检查点和归一化、Adam、LR、计数器/课程/辅助恢复规则，组数/种子/PPO/评估间隔/云时长费用及停止条件，另行获批。

以下内容为历史快照，旧“当前入口”与旧命令均不作为本次执行入口。

# Stage 11 独立头顶接触物理验证交接（进行中）

## 2026-10-04 01:59 六组原参数头壳摩擦诊断获批（当前入口）

用户在北京时间 01:59:56 回复“批准并继续”，授权六组、9000 CPU 步/300 s 积分墙钟上限及明确的首次触地终点规则。新入口已实现；本机新六组尚未运行，本轮隔离环境真实积分 0，PPO/云/整机积分 0。22 项零积分保护测试全部通过，所有 mj_step 均被模拟。静态检查确认六组旧初态定义可复现、初始曲面间隙约 0.5 mm，未积分；该检查使用旧隔离模型，其 MJB 字节哈希与本机归档不同，不作为本机新结果。

Stage11Status=MATERIAL_BLOCKED_REVIEW_REQUIRED，阶段未完成；本机累计已知完成 6211 步（4697+14+300+1200）。不创建 Stage 11 完成标签。

C3/C4 回传已完成：独立分支 `stage11-floor-refinement-transfer-20261003t173938z`，提交 `234030e0f701e788f2d649c31b98ba76a5cd8934`，ZIP SHA256 `5085c2ec989361d0523cbad27cbadb7927cb928f5f39175bb5f10ef8a81c394a`；463527 字节、36 项清单及 5 个 Git blob 校验通过。两组完成 400/800 步、各 50 ms，最大穿透 0.597336582/0.589915495 mm，均低于 1 mm。四项敏感性判据仅 2/4 通过：最大穿透差 0.007421088 mm≤0.1；最大位置差 0.203633604 mm>0.2；最大线速度差 0.211022860 m/s>0.05；最大向上速度差 0.005807214 m/s≤0.02。保持 STEP_REFINEMENT_SENSITIVITY_BLOCKED_REVIEW_REQUIRED，不能舍入或平移时间后改判。原始状态代数复核发现首触地相差 0.0625 ms、再次触地相差 1.125 ms；最大线速度差在后一事件出现。保存力/速度的更新残差≤1.11e−16 m/s，位置残差 0。C3/C4 无新视频，不声称已观看。详见 [C3/C4 审查](../audits/stage-11-floor-refinement-review.json)。

本次不继续地面细化，不采用 C1–C4 参数。保持 dt=2 ms、球 solref=(0.003,1)、有效摩擦 [0.6,0.6,0.005,0.0001,0.0001]、condim=4。几何、原头壳曲面、碰撞掩码、地面、质量/质心/完整惯量、solver、refsafe、solimp 均不变；没有新增平板、提高摩擦或修改正式工厂/任务。condim=4 不代表启用滚动摩擦力矩，原摩擦是仿真假设，未宣称真实材料标定。

仅六组：slide-x-plus、slide-x-minus、slide-y-plus、slide-y-minus（原中心切向速度 ±0.05 m/s）；initial-no-slip-roll（v=0.05 tx，ω=cross(n,v)/0.02）；normal-spin（v=0，ω=n×1 rad/s）。全部复用原 dynamic_matrix 定义、新数据独立初始化，无预热积分或旧轨迹重放。每组最多 3 s/1500 步，CPU 总计最多 9000 步，物理过程墙钟 300 s；不追加 release 案例，不用 CUDA，不训练。

新增独立脚本的明确规则：积分前力对应积分前 qpos/qvel；另建数据执行积分后几何检查，不改主状态或 warm-start。原 v2 表面距离与球间隙误差各≤0.2 mm、法线误差≤5°、穿透≤1 mm 都保留，v1 诊断也留存。首次地面接触或几何重叠即记录并停止该组，≤1 mm 为 FLOOR_EVENT_CENSORED，>1 mm 为 FLOOR_PENETRATION_BLOCKED；均不是 PASS 或完成 3 s，只有这两类终点可进入下一预定组。头部穿透/几何异常、非预期接触、非有限量、来源/参数不符、整段无头接触或未知错误立即停止整批。头部异常优先于地面终点，不能被截断规则掩盖。原校验器 fail-fast 没有修改。

记录世界系接触点滑移（含角速度项）、接触法线与穿透、法/切向力及冲量、扭转力矩/功率、正切向功率、摩擦锥利用率、头接触与脱离区间、地面到达及截断时间。功率等量如实保留，不事后添加通过阈值。即使六组完整通过物理门槛，也只记 HEAD_FRICTION_EVIDENCE_REVIEW_REQUIRED；原完整材料矩阵、落地敏感性、CUDA 和策略目标仍未完成。固定头仅限材料夹具，不锁正式整机头颈，不算无辅助策略成功。

准确下一步命令：

```bash
python3 '/home/lx/下载/microduck-stage11-head-friction.py'
```

可选 `--verify-only` 仅预检不运行，不必先重复执行。安装器校验 HEAD、注释旧标签、SSH remote、20 个旧文件及原材料/五组/C1C2/C3C4 四份本机 ZIP；新增四文件、备份更新本交接，其余 19 个旧文件字节不变，总共 24 个 Stage 11 文件仍待后续代码归档。运行入口进一步按固定 ZIP 验证本机 MJB、几何、初态、静态/惯量审查、源码与 Python/运行版本，不符就停止。GitHub 连接器未能读取旧大 ZIP 二进制，不以空内容或隔离副本替代本机来源检查。

安装器离线，不更新依赖、不联网、不推送、不创建代码分支提交或阶段标签。只把增量 bundle 的已列文件写入工作区，不 checkout/merge/reset。重复运行同一包只显示已有执行记录，不自动重跑。外层物理进程超时 330 s 留出进程启动/报告时间，脚本内积分墙钟上限仍 300 s。保存状态渲染是独立命令，零积分，最多 600 s 外层超时；不因渲染失败重跑物理。

视频选择已执行案例中头部最大滑移的平移案例、normal-spin，另加首个不同的阻塞/截断案例。未执行案例明确写 NOT_RUN，不伪造视频。视频标注固定材料、真实时间、截断状态和记录长度；包含关键接触和末两帧，采样不均匀，以画面时间戳为准。输出待回传目视审查，不预先声称视频通过。

输出 `/home/lx/microduck-double-balance/artifacts/double-balance-stage11/head-friction/<UTC>/`，并准备独立 `stage11-head-friction-transfer-<utc>`。原 MJB、几何、完整状态/接触、测试、运行版本/哈希、视频与计步均归档。未知/中断按完成与尝试步如实报告，不把未知假称 0。归档分支保留完整 review.zip，同时附 768 KiB 的原始字节分片和 review-parts.json，以绕开连接器已观察到的大文件读取限制；按顺序拼接后校验整 ZIP SHA256，不是额外仿真或重复证据。本机上传仍是同一条 Git SSH push。

用户执行脚本末尾打印的准确 push 命令即可，正常输出足够；不重复完整远端核验，不合并归档分支，不重跑此前五次物理/诊断包。原 C3/C4 本机目录为 `/home/lx/microduck-double-balance/artifacts/double-balance-stage11/floor-refinement/20261003T173938Z`；原材料目录为 `physics/20261003T094423Z`，五组为 `floor-impact/20261003T141958Z`，C1/C2 为 `floor-stiffness/20261003T170744Z`，均位于同一 Stage 11 产物根目录。哈希/版本/未知文件冲突时保留现场并返回错误；禁止改期望哈希放行、覆盖未知修改、force/reset 或自动同步依赖。

固定仓库 `/home/lx/microduck-double-balance/workspace`，下载 `/home/lx/下载`。代码 `double-balance` HEAD `056eaf2b0c78261f34e3fa581858c8573cab981e`；旧 `stage-10-complete` 保持 `1a11f30cc7264d00dec7bce8f11449ded9164169`。遵守 [本机 SSH 协议](microduck-local-ssh-push-protocol.md) 与 [云 GPU/传输协议](microduck-cloud-gpu-and-transfer-protocol.md)，Git SSH 默认上传/取件；源码和模型/证据分支分开，本机创建提交/注释标签，用户 SSH 推送。旧静态 v1 失败、材料 y-minus12 落地失败、C3/C4 两项失败均不改判。旧材料矩阵余下 9 CPU 和全部 13 CUDA 仍未执行，六组新诊断状态另记，不代填原矩阵。

本机 5060 仅代码/仿真/推理/视频。云 5090 延续 OFF_CONFIRMED_BY_USER，本轮没有云会话、启停或新的关机提醒/确认。Stage 09 原始轨迹未全回传，禁止删除。以后云计算及必要回传 SHA256 完成即提醒手动关机，提醒和实际确认分开记录；不得运行旧关机守护、Stage 06 smoke、Stage 10 收尾或 CI 修复。

主模型仍为 Stage 08 E/20260929/update_004000.pt，SHA256 `86d55c3703c18fcf4817db49c6e4dcf839b3f5195d68ae2c559db7e222bded97`；历史独立严格成功 652/768（84.90%）不变，不混入开发重复。Stage 10 B1/C1 事后缺口保留，并行浮点累加解释仍非完整因果证明。正式上球观测/初态/奖励/验收参考系另审，相同维度不代表语义兼容。旧 10 s 回合、终局连续稳定≥5 s、无辅助、下球≤0.15 m/s、原计时边界保持。优先无辅助双球平衡，暂停头部纠偏，允许调整时转头后回正。训练检查点及归一化、Adam、LR、计数器/课程/辅助状态恢复规则、实验/种子/新增 PPO/评估间隔/云费用和停止条件仍须单独获批。

以下为历史快照，其中旧“当前入口”和旧命令不作为本次执行指令。


## 2026-10-04 01:23 获批 C3/C4 步长细化（唯一当前入口）

用户在北京时间 01:23:44 回复“批准”，授权此前报告中的 C3/C4 两组及四项诊断误差预算。Stage11Status=MATERIAL_BLOCKED_REVIEW_REQUIRED，阶段未完成；当前 C3/C4 未运行，新增真实积分 0。18 项零积分保护测试通过，无 skipped；所有 mj_step 均模拟。最初测试辅助路径仍指向 C1 的错误已改为 C3，初次与最终日志保留，不计物理执行。

C1/C2 已由用户正常 SSH 推送至 `stage11-floor-stiffness-transfer-20261003t170744z`，固定提交 `bf2a9e8eabd2a31513b8e55504f6e7a84a77d276`。完整 ZIP SHA256 `0ba55b83e4523ba636f7e8f4a948f1694ed4b9f3de13890c317da6e9bf3976cf`，235665 字节、32 项清单和 5 个 Git blob 核验通过。两组各完成 50 ms，100+200=300 步；本机累计 4697+14+300=5011 步，PPO/云/整机积分均为 0。

C1/C2 最大积分前及积分后穿透分别 0.179154/0.455593 mm，均低于原 1 mm 门槛；最大向上速度 0.089530/0.171917 m/s。共同时间最大位置差 1.176157 mm、线速度差 0.385140 m/s，尚有明显步长敏感性，不能以较小穿透选 C1。逐步动量和位置更新代数复核已通过；冲量近似相同主要受相同初态、时长和近零最终竖直速度约束，不单独证明瞬态收敛。详见 [C1/C2 审查](../audits/stage-11-floor-stiffness-review.json)。

获批矩阵：C3 dt=0.125 ms、400 步；C4 dt=0.0625 ms、800 步；每组最多 50 ms，球 solref=(0.001,1)，CPU 共最多 1200 步、墙钟 300 s。私有内存模型副本只改所列 dt 及已经审查的候选球 solref。几何、摩擦、solimp、阻尼比、refsafe、margin/gap、碰撞掩码、质量/质心/完整惯量、重力和求解器选项冻结。原物理工厂、Stage 03/04 正式任务/奖励/约束/验收不变。

从旧本机状态 index=195、t=0.390 s 的 qpos/qvel 初始化，沿用已审查的 A0 派生量和自由落体 warm-start 重建，不称完整历史状态恢复。先核验原材料、五组、C1/C2 三份归档及逐文件输入、源代码、版本、Python 与基线；任何不符积分前停止。A0/C1/C2 均不重跑；C2 状态只复制参与比较，复制哈希及来源写入输出。

保留所有积分前与积分后 1 mm 门槛和末状态几何检查；任一超限终止该组，仅已知穿透失败允许进入下一预先批准组。非有限量、非预期接触、来源/参数/运行异常终止矩阵。四项获批 C3/C4 比较预算：采样最大穿透差≤0.1 mm，共同时间最大位置差≤0.2 mm，最大线速度差≤0.05 m/s，最大向上速度差≤0.02 m/s。边界按原始数值比较，不用显示舍入放行。这些是事件级诊断预算，不替换正式标准或证明数学收敛。

报告 C2/C3、C3/C4 共同时间比较，并把三组放在 C2 网格上比较。只有 C3/C4 均完成完整 50 ms、物理门槛通过且四项预算全满足，才标记 STEP_REFINEMENT_CANDIDATE_REVIEW_REQUIRED。否则保留穿透或敏感性阻塞。不自动加 C5、调整 solref、继续减半、运行完整头部材料/CUDA 矩阵、迁移任务或训练。Stage 11 在所有输出分支都未完成。

准确下一步命令：

```bash
python3 '/home/lx/下载/microduck-stage11-floor-refinement.py'
```

离线安装器仅新增四个文件，备份后更新本交接；其余 15 个旧文件逐字节保留，共 20 个 Stage 11 新文件仍待后续代码归档。脚本不联网、不安装依赖、不推送、不创建代码提交或完成标签，旧完成标签不移动。未知文件修改、基线或运行版本不符时保留现场；重复执行同一包仅返回已有记录，不重跑。`--verify-only` 只预检，不写入或运行。

输出 `/home/lx/microduck-double-balance/artifacts/double-balance-stage11/floor-refinement/<UTC>/`，独立归档分支 `stage11-floor-refinement-transfer-<utc>`。归档前核对原三份 ZIP、已安装源文件、代码 HEAD、旧标签、基线跟踪区及暂存区保持不变。超时/异常按完成和尝试步数如实报告，不把未知假称 0。脚本仅打印用户手动 Git SSH push 命令；正常输出足够，不重复完整远端核验、不合并归档分支。

本机 C1/C2 没有新视频，未声称看过不存在的视频。原 y-minus12 本机片段全部 12 帧的助手审查保持单独记录，不倒填其历史 PENDING。后续必要视频从保存状态零积分渲染。原完整矩阵尚有 9 个 CPU、13 个 CUDA 未执行；固定头材料验证不算策略成功。

固定仓库 `/home/lx/microduck-double-balance/workspace`，下载 `/home/lx/下载`。代码 HEAD `056eaf2b0c78261f34e3fa581858c8573cab981e`；旧 `stage-10-complete` 仍指向 `1a11f30cc7264d00dec7bce8f11449ded9164169`。继续遵守 [本机 SSH 协议](microduck-local-ssh-push-protocol.md) 和 [云 GPU/传输协议](microduck-cloud-gpu-and-transfer-protocol.md)，Git SSH 默认上传与取件，代码与模型/证据分支分开。本机创建阶段提交/注释标签，由用户 SSH 推送。不 reset/force、不覆盖未知内容、不自动同步依赖、不重跑旧收尾/CI 修复/Stage 06 smoke。

本机 5060 仅开发、仿真、推理、视频。云 5090 延续 OFF_CONFIRMED_BY_USER，本轮无新云会话、启停或提醒；Stage 09 原始轨迹未全回传，禁止删除。以后云计算及必要回传 SHA256 完成后立即提醒手动关机，提醒和实际确认分别记录；禁止旧自动关机守护。

主模型 Stage 08 E/20260929/update_004000.pt（SHA256 `86d55c3703c18fcf4817db49c6e4dcf839b3f5195d68ae2c559db7e222bded97`）与历史独立 652/768（84.90%）不变；Stage 10 B1/C1 缺口及未证明完整因果链不倒填。正式观测、初态、奖励和验收参考系另审。10 s 回合、终局连续稳定≥5 s、无辅助、下球≤0.15 m/s 和原计时边界保持。暂停头部纠偏，允许调整时转头后回正；整机头颈不锁，不加隐藏板或提高摩擦。训练及恢复规则与预算仍需另行审查。

下文均为历史快照，旧命令不作为当前下一步。


## 2026-10-03 23:16 获批 C1/C2 接触刚度诊断（唯一当前入口）

用户回复“是继续”，批准上一份审查报告列明的两组诊断。Stage11Status 仍为 MATERIAL_BLOCKED_REVIEW_REQUIRED，阶段未完成。此交付只实现获批范围，本机 C1/C2 尚未运行，新增真实积分 0；保护测试 14 passed、0 skipped，积分调用全部模拟。旧五组入口、v2 验证器、物理工厂和其余旧文件逐字节保留。

五组本机诊断已由用户正常 SSH 推送到 `stage11-floor-impact-transfer-20261003t141958z`，固定提交 `fe2db584e9b8fc391f9014e0e3401b4ceef9f5e5`。A0 时刻、距离、六维接触力精确复现；五组均 PENETRATION_BLOCKED，新增 14 步，原材料 4697 步，加总本机 4711 步。原最大积分前穿透 A0/A1/A2/B1/B2 分别 2.667188/1.003594/1.059542/1.003594/1.235800 mm；均未完成 50 ms，不称作完整碰撞峰值。最后积分后重叠另列，详见 [审查](../audits/stage-11-floor-impact-review.json)。

已读取完整新诊断 ZIP（SHA256 `dd42f05c240f45127731c87d9ad96079ced3c204588b505d762be804467f4f52`），59 项清单哈希匹配；10 个 Git blob 核验完成。原本机 MP4 已实际解码并检查全部 12 个编码帧，SHA256 `c55a11f706dc097e3103d6529d8601f010603d98505a2257313e186bef4b9335`：球沿曲面滚落后触地，画面未见额外板。助手视觉审查完成不等于用户验收，也不等于策略成功。旧归档中的 PENDING 保持历史原样，不倒填。整份旧 v2 ZIP 由本机核验，本环境未独立下载其全部字节。

新矩阵固定：C1 dt=0.5 ms、C2 dt=0.25 ms，两组球 geom solref=(0.001,1)，有效法向时间常数均 1 ms；每组最多 50 ms、100/200 步，共最多 300 步、墙钟 300 s，CPU only，0 PPO、0 云计算、0 整机积分。改变限于私有内存模型副本的 dt 和球 solref[0]；此参数不是全局“仅地面”参数，任何非预期头壳接触即停。摩擦、solimp、阻尼比、refsafe、margin/gap、掩码、质量/质心/完整惯量、几何、重力、求解器选项均冻结；不得据此改正式 Stage 03/04。

每组从同一本机保存状态 index=195、t=0.390 s 起步，qpos/qvel 和自由落体 warm-start 重建须与已存 A0 一致；不称完整历史状态恢复。校验原 v2 与五组归档 ZIP、实际输入、旧源文件以及 A0 的运行版本/Python 字符串和基线；复用 A0 成功证据，不重跑 A0 或五组。任一不符，积分前停止。

原积分前 1 mm 门槛保留；新增独立 MjData 的零积分 mj_forward 几何检查，记录每个积分后状态（含末帧）的重叠和非预期接触，不改变主积分数据或 warm-start。任一保存相位穿透 >1 mm 即停止该组；仅已知穿透失败可进入下一获批组，未知错误终止整个矩阵。记录法向冲量、反弹/末态速度、对齐时间差异；不凭两种步长宣称收敛或材料标定。

准确下一步命令（下载到既定目录后）：

```bash
python3 '/home/lx/下载/microduck-stage11-floor-stiffness.py'
```

安装器不联网、不安装依赖、不推送、不创建代码提交或完成标签。它核对 HEAD `056eaf2b0c78261f34e3fa581858c8573cab981e`、旧注释标签、SSH origin 和已知 12 个源/文档文件；新增四个文件，备份后更新本交接，其余 11 个旧文件不变。未知修改停止，不覆盖。重复运行同一包只报告已有记录，不自动重跑。`--verify-only` 仅预检，无写入或仿真。

输出 `/home/lx/microduck-double-balance/artifacts/double-balance-stage11/floor-stiffness/<UTC>/`，独立归档分支 `stage11-floor-stiffness-transfer-<utc>`；脚本打印用户手动 Git SSH push 命令，正常输出即可，不重复完整远端核验、不合并归档分支。超时保留 completed/attempted 计数及其不确定性，不把未知假称 0。旧原材料与五组目录及 ZIP 保留。HEAD、标签、基线跟踪区、输入归档和已安装源文件会在归档前再次检查不变。

若 C1/C2 都通过，只记 SHORT_IMPACT_CANDIDATE_REVIEW_REQUIRED，Stage 11 仍未完成。完整 13×2 材料验证、正式任务迁移、训练不自动启动。原 9 个 CPU、13 个 CUDA 案例仍 NOT_RUN；本轮不渲染新仿真视频，保存逐步状态供回传审查和必要的零积分渲染。

继续遵守 [本机 SSH 协议](microduck-local-ssh-push-protocol.md) 与 [云 GPU/回传协议](microduck-cloud-gpu-and-transfer-protocol.md)，固定仓库 `/home/lx/microduck-double-balance/workspace`、下载 `/home/lx/下载`。本机 RTX 5060 仅代码/仿真/推理/视频；云 5090 延续 OFF_CONFIRMED_BY_USER，本轮无新云会话/提醒/启停。Stage 09 全量原始轨迹未回传，禁止删除。未来必要回传 SHA256 完成即提醒手动关机，提醒与实际确认分开记录。不重跑旧收尾、CI 修复、Stage 06 smoke 或自动关机守护。

Stage 08 主模型、历史 652/768（84.90%）、Stage 10 B1/C1 缺口及未证明的因果链继续保留。正式观测/初态/奖励/验收参考系另审；10 s 回合、终局连续至少 5 s、无辅助、下球 <=0.15 m/s 及计时边界不变。固定头材料测试不计策略成功，整机头颈不锁，暂停头部纠偏，允许调整转头后回正。

下文均为历史快照，其中命令不再作为当前下一步。


## 2026-10-03 21:43 已批准的五组落地诊断（当前入口）

用户已回复“是，继续”，批准 [五组诊断计划](../audits/stage-11-floor-impact-diagnostic-plan.json)。只对已保存材料模型的独立副本做 CPU 参数对照：A0=(dt 2 ms, solref0 3 ms)、A1=(1,3)、A2=(0.5,3)、B1=(1,4)、B2=(0.5,4)，时间单位均为 ms。A0/B1/B2 固定法向有效时间常数为 4 ms，用于区分步长与 refsafe 柔顺性影响。每组最多 50 ms，总积分≤325 步、诊断墙钟≤5 分钟。未授权正式物理/任务迁移或训练。

当前状态仍为 **MATERIAL_BLOCKED_REVIEW_REQUIRED；Stage 11 未完成**。本机 v2 归档分支 `stage11-physics-v2-transfer-20261003t094423z` 已由用户正常 SSH 推送，固定提交 `51df1774385fec998b8a8e7f7dcfcde5f5a10a27`。13 项本机测试全部通过；质量/质心/完整惯量通过；v2 静态 49/49 通过，旧 v1 的 7 项 BLOCKED 保留。前三个 CPU 材料例各 1500 步，第四例 197 步时首次落地穿透 2.667188 mm，合计 4697 步；后续 9 个 CPU 和全部 13 个 CUDA 例未运行。四例摘要除墙钟外、最后接触行全部字段与隔离 CPU 证据一致。见 [本机材料审查](../audits/stage-11-local-material-review.json)。

隔离环境已完成诊断代码及 11 项针对性保护测试（全过、无跳过；积分调用均为模拟调用，真实动力学步为 0）。**新的五组诊断尚未在本机执行**，A0 重建和四组参数对照结果不能预填。没有在隔离环境重复这 5 组以增加用户批准之外的步数。

本次只读旧证据并创建新诊断输出。旧 ZIP SHA256 `d2c6cb2c788ee3b7020f6557dac1e0646940bebd43b290dc4b3f5c6e8110278d`；本次远程只读并校验 12 个文本 Git blob，未下载 ZIP、完整 NPZ/压缩轨迹或 MP4，视频人工审查仍 PENDING。诊断脚本将在本机先核验旧 ZIP 全字节 SHA256，并将读取的输入逐个对照 ZIP 和清单，再进行已有轨迹的零积分代数复核；复制原 MP4、导出 4 个关键帧，便于通过下一归档读取，不能自动标记人工视频审查完成。

初始化采用本机旧 `local-v2/cpu/release-y-minus12/states.npz` 中索引 195、t=0.390 s 的 qpos/qvel。显式重建派生量、warm-start 并记录；不称作完整历史状态恢复。A0 的首次接触时刻、距离和力分量必须满足计划中的原始记录对照容差，否则停止整个矩阵。已获批的各组在超过原 1 mm 门槛时终止该组并记录 PENETRATION_BLOCKED；按预先批准的矩阵可从相同初态进入下一组。任何非预期接触、非有限量、来源不符、A0 不符、预算超限都停止矩阵。原 v2 验证器整体 fail-fast 逻辑完全未改，诊断 PASS 也不解除原材料验证阻塞。

当前准确命令：

```bash
python3 '/home/lx/下载/microduck-stage11-floor-impact.py'
```

交付包只新增诊断脚本、其针对性测试、两份审查 JSON，并备份后更新本交接；原八个 Stage 11 文件中其余七个逐字节保留，基线 Stage 03/04 等跟踪文件不变。旧物理工厂与 v2 验证器分别保持 SHA256 `8a2446aa27d8e420e6e26e5e9985ab24cb774036936f393de680857edfd0af64`、`d5f88ffc2a65c3d98a6714d8aa67b8bffe8144f81be6e1d1fd6d89dcb908067c`。脚本先检查实际本机 HEAD、旧注释标签、SSH origin、已知 v2 文件和旧证据，不安装/升级依赖，不联网、不推送、不创建代码提交或完成标签。

输出位于 `/home/lx/microduck-double-balance/artifacts/double-balance-stage11/floor-impact/<UTC>/`，原物理证据目录保留。复核小包在新的独立归档仓库创建本机提交，只打印用户手动 Git SSH push 命令。重复运行同一包只报告已有结果，不自动重跑；`--verify-only` 只检查输入，无源文件写入、测试或积分。版本/文件/HEAD 不符保留现场，不能 reset/force、覆盖未知内容或重跑旧脚本。若诊断超时，读取 progress.json 中完成/尝试步数，不把未知计步假称 0。

下一轮读取归档后，先审查本机视频、相邻状态、A0 再现和四组对照。候选参数即使通过也只代表此 50 ms 材料片段；正式变更数值参数、完整 13×2 矩阵、任务迁移、PPO 均仍需单独审查，不自动延伸。正常推送输出足够，不重复完整远端核验，不合并归档分支。

继续保留下文固定路径、两份 SSH/云协议、旧标签和模型 SHA、关机状态与提醒规则、Stage 09 未回传数据、B1/C1 缺口、正式 10 s/终局 5 s/无辅助/0.15 m/s 标准。云 5090 保持 OFF_CONFIRMED_BY_USER，本轮云小时和 PPO 均为 0。

以下 v2/v1 段落为历史快照，旧命令不再是当前下一步。

## 2026-10-03 v2 当前入口（优先于下文 v1 历史快照）

用户在北京时间 17:06:09 询问“这是目前的最优解吗 如果是继续”。结论是现有证据下更有依据的下一步，不是已证明的全局最优。已按条件授权实施所提 v2 几何判据：表面距离≤0.2 mm、球壳间隙差≤0.2 mm、法线差≤5°；旧点对点 0.2 mm 结果继续记录，不改写旧 BLOCKED。通过 `--geometry-gate v2` 明确选择；脚本默认仍为 v1，不隐式绕过旧门槛。

本机 v1 归档已由用户正常 SSH 推送至 `stage11-physics-transfer-20261003t073525z`，提交 `0ecdb2959ca649349ad52e7609f91dc4329a9b90`。9 项测试全部通过，原静态 42/49 通过，质量/完整惯量通过。读取 10 份文本并校验 Git blob，未下载整个 ZIP，不声称已完成该 ZIP 的字节回传 SHA256。

本轮隔离 CPU 结果见 [v2 审查](../audits/stage-11-geometry-gate-v2-review.json)：静态 v2 49/49 PASS，v1 仍有 7 项 BLOCKED。材料测试依次完成 center、x-minus12、x-plus12；第 4 例 y-minus12 在首次地面接触触发 1 mm 穿透门槛，最大 2.667188 mm，因此整套仍 BLOCKED。该例头壳接触最大穿透 0.084472 mm。还未开始的 9 个 CPU 和 13 个 CUDA 案例均 NOT_RUN，未继续滑移/滚动/自旋专项。

相邻保存状态表明：t=0.390 s 球底距地 0.640381 mm、竖直速度 -1.634165 m/s；原定 2 ms 自由落体积分后，t=0.392 s 的球底为 -2.667188 mm。随后接触法向力 10.117701 N 对 10 g 球的速度改变量也与日志一致。这是本例首次落地离散跨越的证据，**不构成提高门槛或改时间步的授权**，也不证明整个任务的正式动力学已验收。

隔离材料积分共 4697 步，另有独立解析平面夹具的 Warp CPU 接口检查 4 步；整机积分 0、PPO 0、云计算 0。针对性测试 12 passed、1 skipped；完整本机 Scene v2 检查与 RTX 5060 CUDA 仍待执行。接口 CPU PASS 不冒充 CUDA 结果。物理工厂 SHA256 未变：`8a2446aa27d8e420e6e26e5e9985ab24cb774036936f393de680857edfd0af64`。

原始失败视频未包含末次采样的缺口已记录并保留文件；重新从保存状态渲染最终 pre/post 帧，叠加实际时间、穿透、滑移及世界法线数值。没有为视频新增物理步。视频仅展示固定材料夹具；球滚落并不等于策略验收样本。

当前唯一下一步命令：

```bash
python3 '/home/lx/下载/microduck-stage11-physics-v2.py'
```

该离线续跑包校验本机 HEAD、旧标签、SSH origin、v1 文件哈希与既有本机 v1 静态证据；先备份已知 v1 新增文件，再更新明确列出的 Stage 11 文件，新增两份审查 JSON。现有 Stage 03/04 等基线跟踪文件保持不变。它运行本机针对性测试、v2 静态矩阵，然后按原矩阵顺序运行 CPU；任何失败即停，CPU 全部通过才进入 CUDA。每例≤3 s、2 ms 步长，总验证墙钟≤45 min。已存在本包执行记录时不自动重跑。`--verify-only` 不导入或运行。

结果与源文件备份放在 `/home/lx/microduck-double-balance/artifacts/double-balance-stage11/physics/<UTC>/`，原 `/physics/20261003T073525Z/` 保持不变。小型复核 ZIP 及必要文本会在新的独立本机归档仓库提交，脚本只打印 SSH push 命令，用户手动推送；不要合并归档分支。返回正常输出即可，不重复完整远端核验。不创建 `stage-11-complete`，本阶段仍未收尾。

若本机复现 2.667 mm 地面穿透：停止，先审查报告；不可自动改 dt、margin、gap、solref、摩擦、solver、1 mm 判据，也不可删掉地面接触来放行。若本机得到不同结果，同样保留差异并按具体日志判断，不进行无判别目标重复诊断。后续任何正式物理或任务变更仍需单独说明理由、影响并确认。

以下为 v1 历史快照，其中旧交付命令不再作为下一步执行。

当前状态：**静态几何门槛阻塞；Stage 11 未完成**。新增 PPO 0，物理积分步 0，云计算 0，无新策略。未创建或移动阶段完成标签，正式 Stage 03/04 文件、任务、奖励、验收及模型未改。

## 已完成与证据限制

固定审查源码为 `056eaf2b0c78261f34e3fa581858c8573cab981e`，包括 Stage 10 publication-confirmation 补记。本机路径不可访问；本次隔离 CPU 检查从固定源码提取原工厂函数，使用全部原网格组装诊断场景。它不是本机完整 mjlab Scene 的验收结果。完整 Scene 测试仍待本机执行；当前针对性测试 8 passed、1 skipped。

[计划](../audits/stage-11-physics-plan.json)规定独立工厂只删除新建 spec 的 18 g 托盘子树，并给原始头壳碰撞体分配新接触位；上球只接触头壳和地面。不加平面、不提高摩擦、不锁整机头颈、不注册 RL 任务。

[审查数据](../audits/stage-11-physics-review.json)含完整质量、质心、3×3 惯量和 49 个静态点/姿态证据。机器人质量从 0.75524318 kg 变为 0.73724318 kg；含两球场景从 1.38524318 kg 变为 1.36724318 kg。质量及平行轴重组检查通过。

静态检查 42/49 通过，7/49 在 `y +12 mm` 触发接触位置 0.2 mm 门槛，最大约 0.249685 mm，法线最大约 0.697865°。完整提取模型的单点距离复核同样出现约 0.249660 mm 差异。独立逐面算法检查全部 16120 个原始面，复现原网格最近点；CPU 引擎点与凸包最近点一致到约 1.9e-8 m。这里是最近接触点的主要切向差异，不是同等深度的穿透，也不能据此宣布 Warp 接触机制已证明。

原始隔离运行还遭遇 `mj_saveLastXML: No XML model loaded`，失败 JSON 和错误日志保留；已改用编译模型 MJB 并验证重新加载，补了失败门槛阻止后续动力学的测试。没有重跑完整静态矩阵，也没有进行动力学重试。初始工具版本未在修复前记录代码哈希，保留此限制；交付版本有清单哈希。

动态 13 × 2 后端矩阵、穿透、有效摩擦、滑移、RTX 5060、动力学视频均 **NOT_RUN**。固定头材料测试永远不等于无辅助策略成功。摩擦 μ=0.6 沿用既有模拟假设，尚不是实体材料标定；condim=4 不提供滚动摩擦。所有既定阈值保留。

## 下一步准确命令

固定源码目录 `/home/lx/microduck-double-balance/workspace`，下载目录 `/home/lx/下载`。

```bash
python3 '/home/lx/下载/microduck-stage11-physics.py'
```

交付脚本先核对本机分支/基线、干净的既有跟踪文件、旧标签和 SSH remote，再校验内嵌增量 Git bundle，仅新增列明的六个文件。默认只运行本机已有 `.venv/bin/python` 的针对性测试和 `--static-only` 验证，不安装依赖、不联网、不推送、不训练、不做动态步。结果写入 `/home/lx/microduck-double-balance/artifacts/double-balance-stage11/physics/<时间戳>/`，生成带 SHA256 的小型复核 ZIP。已有结果不会自动重跑；重复执行只报告已有目录。参数 `--verify-only` 只核对，不写入仓库或运行检查。

脚本暂不创建本机提交：本阶段仍有阻塞，复核包会在独立本机归档仓库创建提交，打印准确的 Git SSH push 命令；由用户推送该归档分支，绝不合并到代码分支。先返回最后的 `Stage11Evidence` / `Stage11ReviewZip` 输出和正常 push 输出。收集本机静态结果后判断碰撞表示是否需要另行审查；不通过改阈值、提高摩擦、改变 solver 或删除测试点来继续。只有审查解除阻塞后，才讨论已规划动态矩阵的执行。不可默认把当前 CPU/Warp 未执行分支当成已经验证。

## 固定规则与已知错误

继续遵守[本机 Git SSH 规范](microduck-local-ssh-push-protocol.md)和[云 GPU/传输规范](microduck-cloud-gpu-and-transfer-protocol.md)。代码 `double-balance` 与模型/大轨迹归档分支分开，绝不合并归档分支；默认 Git SSH 上传/取文件。隔离开发通过增量 Git bundle 交付，不切换本机认证。后续本机创建提交/注释标签，用户 SSH 推送；正常 push 输出足够，不重复完整远端核验。

```bash
cd /home/lx/microduck-double-balance/workspace
git status --short --branch
git rev-parse HEAD
git rev-parse 'stage-10-complete^{}'
# 仅阶段评估、归档、交接和本机提交完成后，由用户执行：
git push origin double-balance
```

旧标签 `stage-10-complete` 固定在 `1a11f30cc7264d00dec7bce8f11449ded9164169`。不重跑旧 finalize/ci-fix/A/B/C/Stage 06 smoke。293900b 的 CI 36892445739 已成功（416 passed、6 skipped、3 warnings、17 subtests passed），不重新归档修复，更不能把旧 CI 认证归给 Stage 11。

常见错误：HEAD 与基线不符先报告实际 SHA，禁止 reset/force；已有目标文件若内容不符停止，禁止覆盖；版本不符禁止自动 uv sync 升降级；仓库暂存区/既有跟踪文件有修改时先保留现场；不存在 publication-confirmation 时只说明补记未应用，不倒填；验证 BLOCKED 不是策略失败率样本。精确重跑指令只能在审查具体失败之后给出，禁止无判别目标重复诊断。

主模型仍为 Stage 08 E/20260929/update_004000.pt，SHA256 `86d55c3703c18fcf4817db49c6e4dcf839b3f5195d68ae2c559db7e222bded97`。历史独立严格成功 652/768=84.90%；Stage 10 重复开发集不并入。B1/C1 事后检查缺口保留；浮点累加次序解释有证据，完整因果链仍未证明。

旧标准继续是 10 秒回合、终局连续稳定至少 5 秒、无辅助、下球速度上限 0.15 m/s；计时边界不改。正式迁移需要另行审查上球观测/初态/奖励/验收参考系，相同维度不是语义兼容。暂停头部纠偏，允许调整时转头、稳定后回正，不默认一直朝前。

RTX 5060 仅代码、MuJoCo 仿真、推理和视频。RTX 5090 状态 `OFF_CONFIRMED_BY_USER`，本阶段没有新云会话、关机提醒或操作。禁止自行启停、旧自动关机守护、删除尚未全部回传的 Stage 09 云原始轨迹。未来计算及必要回传 SHA256 完成后，立即提醒用户手动关机；提醒时间和用户实际确认分开记录。

任何后续训练必须先提交初始化检查点、归一化/Adam/学习率/iteration/common_step_counter/课程/辅助状态的恢复或重置规则，以及组数、种子、新增 PPO、评估间隔、云 GPU 时长费用和停止条件，另行获批。
