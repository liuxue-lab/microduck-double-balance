"""Independent geometry/rigid-body identities and the real compiled factory."""
from pathlib import Path
import importlib.util
import unittest
from unittest.mock import patch
import tempfile

import numpy as np

MODULE = Path(__file__).resolve().parents[1]/'src/mjlab_microduck/robot/head_contact.py'
spec=importlib.util.spec_from_file_location('stage11_head_contact_under_test',MODULE)
hc=importlib.util.module_from_spec(spec);spec.loader.exec_module(hc)


class GeometryTests(unittest.TestCase):
    def test_face_edge_vertex_and_degenerate_triangle(self):
        t=np.array([[[0,0,0],[1,0,0],[0,1,0]]],float)
        for p,expected in [([.2,.3,.7],[.2,.3,0]),([.8,.8,.2],[.5,.5,0]),([-1,-2,3],[0,0,0])]:
            q,_,_=hc.nearest_surface(p,t);np.testing.assert_allclose(q,expected,atol=1e-12)
        deg=np.array([[[0,0,0],[1,0,0],[1,0,0]]],float)
        q,_,_=hc.nearest_surface([.3,2,0],deg);np.testing.assert_allclose(q,[.3,0,0])

    def test_finite_sphere_on_inclined_plane(self):
        slope=.2
        t=np.array([[[-2,-2,-2*slope],[2,-2,2*slope],[2,2,2*slope]],
                    [[-2,-2,-2*slope],[2,2,2*slope],[-2,2,-2*slope]]])
        c,p,n,_=hc.sphere_center_above([0,0],t)
        self.assertAlmostEqual(c[2],.0205*np.sqrt(1+slope*slope),places=10)
        np.testing.assert_allclose(n,[-slope/np.sqrt(1+slope*slope),0,1/np.sqrt(1+slope*slope)],atol=1e-10)
        self.assertGreater(abs(p[0]),0)

    def test_closest_point_equivariance(self):
        tri=np.array([[[0,0,0],[1,0,0],[0,1,0]]],float); p=np.array([.2,.3,.7])
        r=hc.axis_rotation(1,.31); shift=np.array([2,3,4])
        q,d,_=hc.nearest_surface(p,tri)
        qq,dd,_=hc.nearest_surface(p@r.T+shift,tri@r.T+shift)
        np.testing.assert_allclose(qq,q@r.T+shift,atol=1e-12);self.assertAlmostEqual(d,dd)

    def test_true_no_slip_roll_has_nonzero_center_speed(self):
        slip=hc.contact_slip([.05,0,0],[0,2.5,0],[0,0,.02],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,1])
        np.testing.assert_allclose(slip,0,atol=1e-12)

    def test_rotating_support_point_not_site_velocity(self):
        slip=hc.contact_slip([0,.1,0],[0,0,0],[.05,0,.02],[0,0,0],[0,0,2],[0,0,0],[.05,0,0],[0,0,1])
        np.testing.assert_allclose(slip,0,atol=1e-12)

    def test_parallel_axis_off_diagonal_and_com(self):
        masses=[2.,3.]; centers=[[0,0,0],[1,2,3]]; inertias=[np.eye(3),2*np.eye(3)]
        result=hc.combine_inertias(masses,centers,inertias)
        np.testing.assert_allclose(result['com_m'],[.6,1.2,1.8])
        expected=3*np.eye(3)+1.2*(14*np.eye(3)-np.outer([1,2,3],[1,2,3]))
        np.testing.assert_allclose(result['inertia_com_kg_m2'],expected)

    def test_matrix_scope(self):
        self.assertEqual(len(hc.point_matrix())*len(hc.pose_matrix()),49)
        t=np.array([[[-1,-1,0],[1,-1,0],[1,1,0]],[[-1,-1,0],[1,1,0],[-1,1,0]]],float)
        cases=hc.dynamic_matrix(t,[0,0]);self.assertEqual(len(cases),13)
        self.assertEqual(len({x['name'] for x in cases}),13)


@unittest.skipUnless(importlib.util.find_spec('mujoco'), 'Requires MuJoCo')
class StopGateTests(unittest.TestCase):
    def test_geometry_failure_is_saved_and_never_steps(self):
        import sys, mujoco, json
        root=MODULE.parents[3]
        sys.path.insert(0,str(root/'src'))
        loader=importlib.util.spec_from_file_location('stage11_validator_under_test',root/'scripts/validate_head_contact_physics.py')
        val=importlib.util.module_from_spec(loader);loader.loader.exec_module(val)
        m=mujoco.MjModel.from_xml_string('<mujoco><option timestep="0.002"/><worldbody><site name="double_balance_tray_frame"/></worldbody></mujoco>')
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)
            with patch.object(val,'audit_full_scene',return_value={'status':'PASS'}), \
                 patch.object(val,'static_geometry',return_value=({'status':'BLOCKED'},m,np.zeros((1,3,3)))), \
                 patch.object(val,'run_case',side_effect=AssertionError('Dynamics forbidden after failed static gate')) as dynamics:
                result=val.run_physics(m,m,out)
            self.assertEqual(result['status'],'BLOCKED')
            self.assertIn('collision geometry gate',result['error'])
            dynamics.assert_not_called()
            self.assertEqual(mujoco.MjModel.from_binary_path(str(out/'material-fixture.mjb')).opt.timestep,.002)
            self.assertEqual(json.loads((out/'physics-review.json').read_text())['cases'],[])


@unittest.skipUnless(importlib.util.find_spec('mjlab') and importlib.util.find_spec('torch'),
                     'Requires the frozen full local project environment; geometry tests are independent')
class CompiledFactoryTests(unittest.TestCase):
    def test_actual_frozen_scene_factory_and_mass(self):
        from mjlab.scene import Scene
        cfg,old_scene,new_scene=hc.physics_scene_pair()
        old=Scene(old_scene,device='cpu').compile();new=Scene(new_scene,device='cpu').compile()
        self.assertEqual(old.nq,new.nq);self.assertEqual(old.nv,new.nv)
        self.assertEqual(new.neq,0)
        self.assertAlmostEqual(float(old.body_mass.sum()-new.body_mass.sum()),.018,places=10)
        self.assertTrue(any((new.geom(i).name or '').endswith(hc.HEAD_GEOM_NAME) for i in range(new.ngeom)))
        self.assertEqual(cfg.sim.mujoco.timestep,.002)


if __name__=='__main__': unittest.main()
