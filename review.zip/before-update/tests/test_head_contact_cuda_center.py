"""One-case budget/material/clock guards. Every GPU and CPU integration is mocked."""
import importlib.util,json,sys,tempfile,time,types,unittest
from pathlib import Path
from unittest.mock import patch
import mujoco
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('cuda_center_guards',ROOT/'scripts/diagnose_head_contact_cuda_center.py')
d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)

def model():
 return mujoco.MjModel.from_xml_string('<mujoco><option timestep=".002"/><worldbody><geom name="head" type="sphere" pos="10 0 0" size=".1"/><geom name="floor" type="plane" size="1 1 .1"/><body><freejoint/><geom name="sphere" type="sphere" size=".02" mass=".01" priority="1" condim="4" solref=".003 1" friction=".6 .005 .0001" solimp=".95 .99 .001 .5 2"/></body></worldbody></mujoco>')

CASE={'name':'release-center','center':[0,0,.03],'velocity':[0,0,0],'omega':[0,0,0]}
DEVICE=types.SimpleNamespace(is_cuda=True,name='NVIDIA GeForce RTX 5060 Laptop GPU')
class Array:
 def __init__(self,v,dtype=np.float32):self.value=np.asarray(v,dtype=dtype)
 def numpy(self):return self.value.copy()
class FakeStepper:
 behavior='normal'
 def __init__(self,m,initial,*_):
  self.model=m;self.device=DEVICE
  self.data=types.SimpleNamespace(qpos=Array([initial.qpos]),qvel=Array([initial.qvel]),qacc_warmstart=Array([initial.qacc_warmstart]),time=Array([0]),nacon=Array([1],np.int32),nefc=Array([4],np.int32))
  if self.behavior=='capture_advance':self.data.time.value[0]=.002
 def step(self):
  if self.behavior=='error':raise RuntimeError('injected launch/extraction failure')
  self.data.time.value[0]=np.float32(self.data.time.value[0]+np.float32(.002))
  if self.behavior=='bad_clock':self.data.time.value[0]=0
  if self.behavior=='capacity':self.data.nacon.value[0]=256
  q=self.data.qpos.numpy()[0];v=self.data.qvel.numpy()[0]
  if self.behavior=='nan':q[0]=np.nan
  return q,v,[{}]

def contact():
 return {'allowed':True,'other':'head','dim':4,'friction':[.6,.6,.005,.0001,.0001],'solref':[.003,1.],'solimp':[.95,.99,.001,.5,2.],
  'dist':-.0001,'pos':[0,0,.02],'frame':[0,0,1,0,1,0,-1,0,0],'force':[1,0,0,0,0,0],'geometry':{'v2_pass':True}}
def post(overlap=0):return {'contacts':[],'head_overlap_m':0.,'floor_overlap_m':overlap}

class Guards(unittest.TestCase):
 def setUp(self):
  p=patch.object(mujoco,'mj_step',side_effect=AssertionError('Real CPU step forbidden'));p.start();self.addCleanup(p.stop)
 def run_fake(self,behavior='normal',post_result=None,deadline=None):
  FakeStepper.behavior=behavior;seen=[]
  def accumulate(s,*_):s['head_contact_steps']+=1;return True
  with tempfile.TemporaryDirectory() as temp,patch.dict(sys.modules,{'warp':types.SimpleNamespace(get_device=lambda _:DEVICE)}),patch.object(d.v2,'WarpStepper',FakeStepper),patch.object(d.v2,'contact_rows',return_value=[contact()]),patch.object(d.fr,'post_geometry',return_value=post() if post_result is None else post_result),patch.object(d.fr,'accumulate',side_effect=accumulate):
   m=model();signature=d.floor.model_signature(m)
   result=d.run_case(m,np.zeros((1,3,3)),CASE,Path(temp),time.monotonic()+30 if deadline is None else deadline,
     lambda s:seen.append((s['steps'],s['attempted_steps'],s.get('unexpected_setup_advance_possible',False))))
   self.assertEqual(d.floor.model_signature(m),signature)
   z=np.load(Path(temp)/'cases/release-center/states.npz')
   if result['capture_primary_state_verified']:self.assertEqual(len(z['qpos']),result['steps']+1)
   return result,seen
 def test_exact_single_case_budget(self):
  self.assertEqual((d.DT,d.MAX_STEPS,d.WALL_SECONDS),(.002,1500,600));self.assertEqual(d.DT*d.MAX_STEPS,3.)
 def test_complete_mock_horizon_is_not_policy_success(self):
  r,_=self.run_fake();self.assertEqual(r['steps'],1500);self.assertEqual(r['status'],d.PASS);self.assertIsNone(r['policy_success']);self.assertEqual(r['new_ppo_updates'],0)
 def test_floor_arrival_censors_and_does_not_qualify_horizon(self):
  r,_=self.run_fake(post_result=post(.0001));self.assertEqual((r['steps'],r['status']),(1,'FLOOR_EVENT_CENSORED'));self.assertFalse(r['horizon_completed'])
 def test_floor_penetration_remains_blocked(self):
  r,_=self.run_fake(post_result=post(.00101));self.assertEqual((r['steps'],r['status']),(1,'FLOOR_PENETRATION_BLOCKED'))
 def test_launch_failure_preserves_attempt_uncertainty(self):
  r,seen=self.run_fake('error');self.assertEqual((r['steps'],r['attempted_steps']),(0,1));self.assertFalse(r['completed_step_count_exact']);self.assertIn((0,1,False),seen)
 def test_capture_advance_stops_without_authorizing_launch(self):
  r,_=self.run_fake('capture_advance');self.assertEqual(r['attempted_steps'],0);self.assertTrue(r['unexpected_setup_advance_possible']);self.assertFalse(r['completed_step_count_exact'])
 def test_deadline_prevents_first_launch(self):
  r,_=self.run_fake(deadline=time.monotonic()-1);self.assertEqual(r['attempted_steps'],0);self.assertIn('budget exhausted',r['error'])
 def test_bad_clock_capacity_nonfinite_stop_after_one_return(self):
  for mode in ('bad_clock','capacity','nan'):
   r,seen=self.run_fake(mode);self.assertEqual((r['steps'],r['attempted_steps']),(1,1));self.assertEqual(r['status'],'CUDA_CENTER_ERROR_STOP_REVIEW_REQUIRED');self.assertIn((1,1,False),seen)
 def test_float32_clock_is_counted_without_changing_nominal_timestep(self):
  t=0.
  for _ in range(1500):t=d.check_clock(t,float(np.float32(np.float32(t)+np.float32(.002))))
  self.assertGreater(abs(t-3.),0)
  with self.assertRaises(RuntimeError):d.check_clock(t,t)
 def test_only_local_5060_allowed(self):
  d.validate_device(DEVICE)
  for x in (types.SimpleNamespace(is_cuda=False,name='cpu'),types.SimpleNamespace(is_cuda=True,name='RTX 5090')):
   with self.assertRaises(RuntimeError):d.validate_device(x)
 def test_geometry_and_material_gates_unchanged(self):
  self.assertIsNone(d.validate_record([contact()],post()))
  for key,value in [('friction',[.7,.6,.005,.0001,.0001]),('solref',[.001,1.]),('dim',6),('dist',-.001001),('geometry',{'v2_pass':False})]:
   c=contact();c[key]=value
   with self.assertRaises(RuntimeError):d.validate_record([c],post())
 def test_descriptive_backend_comparison_is_not_a_pass_gate(self):
  with tempfile.TemporaryDirectory() as temp:
   p=Path(temp);(p/'archived-CPU-center').mkdir();(p/'cases/release-center').mkdir(parents=True)
   q=np.zeros((1501,7));v=np.zeros((1501,6));np.savez(p/'archived-CPU-center/states.npz',qpos=q,qvel=v,dt=.002)
   np.savez(p/'cases/release-center/states.npz',qpos=q[:4]+.1,qvel=v[:4]+.2,dt=.002)
   r=d.compare_saved(p,{'steps':3})
   self.assertEqual(r['status'],'DESCRIPTIVE_BACKEND_COMPARISON_ONLY');self.assertEqual(r['common_nominal_step_samples'],4);self.assertFalse(r['finest_floor_pair_gates_applied'])

if __name__=='__main__':unittest.main()
