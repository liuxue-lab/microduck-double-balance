"""Zero-integration reconstruction of returned CUDA center v2 evidence."""
from pathlib import Path
import gzip,hashlib,importlib.util,json
from unittest.mock import patch
import mujoco,numpy as np
root=Path('stage11-local-cuda-center-v2-review-20261004T101459Z');p=root/'archive/diagnostic';case=p/'cases/release-center'
read=lambda p:json.loads(p.read_text())
lines=lambda p:[json.loads(s) for s in p.read_text().splitlines()]
gz=lambda p:[json.loads(s) for s in gzip.open(p,'rt')]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('cuda_v2_review','stage11-build/scripts/diagnose_head_contact_cuda_center.py');d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
run,report=read(root/'run-summary.json'),read(p/'diagnostic-review.json');summary=report['cases'][0]
assert run['physics_integration_steps']==run['physics_attempted_steps']==summary['steps']==summary['analyzed_steps']==282
assert run['canonical_total_known_completed_steps']==run['canonical_total_attempted_upper_bound']==12983
assert summary['status']=='FLOOR_EVENT_CENSORED' and not summary['horizon_completed'] and summary['policy_success'] is None
assert run['execution_invariants_unchanged'] and not run['stage11_complete'] and run['new_ppo_updates']==0
manifest=read(root/'archive/package-manifest.json');assert manifest==read(Path('stage11-cuda-center-v2-package-manifest.json'))
assert read(p/'source-snapshot.json')==manifest['files']
assert sha(Path('stage11-build/scripts/diagnose_head_contact_cuda_center.py'))==report['diagnostic_source_sha256']
assert (p/'model-signature-before.json').read_bytes()==(p/'model-signature-after.json').read_bytes()
assert sha(p/'material-fixture.mjb')=='e6cd330bddc3a29abf9ce4eca4f308a2680e4910405725e5ce054cb0a19d2da0'
logs,raw,flat,partial=lines(case/'step-log.jsonl'),gz(case/'raw-contacts.jsonl.gz'),gz(case/'contacts.jsonl.gz'),lines(case/'states.partial.jsonl')
assert len(logs)==len(raw)==282 and len(partial)==283 and len(flat)==193
with np.load(case/'states.npz') as z:q,v,t,nominal=(z[k].copy() for k in ('qpos','qvel','device_time','time'))
assert q.shape==(283,7) and v.shape==(283,6)
np.testing.assert_array_equal(nominal,np.arange(283)*.002)
with np.load(p/'archived-CPU-center/states.npz') as z:cq,cv=z['qpos'].copy(),z['qvel'].copy()
pd=np.linalg.norm(cq[:283,:3]-q[:,:3],axis=1);vd=np.linalg.norm(cv[:283,:3]-v[:,:3],axis=1)
assert float(pd.max())==report['comparison']['max_position_difference_m'] and float(vd.max())==report['comparison']['max_linear_velocity_difference_m_s']
with np.load(p/'material-geometry.npz') as z:triangles=z['vertices'][z['faces']]
model=mujoco.MjModel.from_binary_path(str(p/'material-fixture.mjb'));signature=d.floor.model_signature(model)
derived=d.fr.new_summary(read(p/'archived-CPU-center/initial.json'));flags=[];endpoints=[];all_rows=[];post_geometry_max_error=0.
clock=0.;contact_index=0
with patch.object(mujoco,'mj_step',side_effect=AssertionError('No integration permitted in saved record review')):
 for i,(entry,r) in enumerate(zip(logs,raw)):
  assert entry['step']==r['step']==i
  clock=d.check_clock(clock,t[i+1])
  for key,value in [('qpos_before',q[i]),('qvel_before',v[i]),('qpos_after',q[i+1]),('qvel_after',v[i+1])]:np.testing.assert_array_equal(entry[key],value)
  for k in ('qpos','qvel'):np.testing.assert_array_equal(partial[i][k],q[i] if k=='qpos' else v[i])
  assert partial[i]['returned_steps']==i and partial[i]['device_time_s']==t[i]
  native=[{**c,**{k:np.asarray(c[k],dtype=np.float32) for k in ('pos','frame','force','friction','solref','solimp')},'dist':np.float32(c['dist'])} for c in r['contacts']]
  rows=d.analysis_rows(d.v2.contact_rows(model,q[i],v[i],native,i,'warp',triangles))
  assert len(rows)==len(entry['contacts'])
  for a,b in zip(rows,entry['contacts']):
   assert b==flat[contact_index];contact_index+=1
   for k in ('frame','normal_toward_ball','slip_world_m_s','normal_force_N','torsional_power_W','tangential_power_W','pyramidal_cone_utilization'):
    if a[k] is None:assert b[k] is None
    else:np.testing.assert_allclose(a[k],b[k],rtol=1e-9,atol=1e-12)
   for k in ('normal_error_deg','surface_distance_m','sphere_gap_error_m'):np.testing.assert_allclose(a['geometry'][k],b['geometry'][k],rtol=1e-9,atol=1e-12)
  data=mujoco.MjData(model);data.qpos[:]=q[i+1];data.qvel[:]=v[i+1];data.time=t[i+1]
  post=d.fr.post_geometry(model,mujoco.MjData(model),data,triangles)
  for k in ('floor_gap_m','head_overlap_m','floor_overlap_m','original_head_surface_gap_m'):
   diff=abs(post[k]-entry['post_geometry'][k]);post_geometry_max_error=max(post_geometry_max_error,diff);assert diff<1e-11
  endpoint=d.validate_record(rows,post);endpoints.append(endpoint);flags.append(d.fr.accumulate(derived,rows,post,i));all_rows.extend(rows)
assert d.floor.model_signature(model)==signature
assert endpoints[:-1]==[None]*281 and endpoints[-1]=='FLOOR_EVENT_CENSORED'
assert q[281,2]>.02 and q[282,2]<.02 and 0<.02-q[282,2]<.001
assert sum(flags)==193 and not any(flags[216:])
for key in ('head_contact_steps','floor_contact_steps','max_head_slip_m_s','max_head_penetration_m','max_post_head_overlap_m','max_floor_penetration_m','head_normal_impulse_Ns','head_tangential_world_impulse_Ns','head_tangential_work_J','head_torsional_work_J','max_positive_head_tangential_power_W','head_tangential_positive_power_samples','max_head_cone_utilization'):
 np.testing.assert_allclose(derived[key],summary[key],rtol=1e-9,atol=1e-12)
assert d.fr.contact_intervals(flags)==summary['head_contact_intervals']
assert sha(p/'cuda-center-saved.mp4')==report['video']['sha256']
assert len(list((root/'video-frames').glob('frame-*.png')))==report['video']['frames']==42
video={'all_saved_frames_visually_reviewed':42,'frame_steps':report['video']['frame_steps'],'sha256':report['video']['sha256'],
 'observation':'Ball rolls along unchanged fixed curved head, departs at the side, falls to floor. No tray visible. Final frame labelled564ms; not a policy video or full3s completion.',
 'limitation':'Snapshots do not measure sub-mm penetration; geometry is checked from records/mesh. Encoded playback1.68s is distinct from564ms physical prefix.'}
result={'status':'CUDA_CENTER_V2_PREFIX_REVIEWED_FLOOR_CENSORED','stage11_status':'MATERIAL_BLOCKED_REVIEW_REQUIRED','stage11_complete':False,
 'retrieval':read(root/'retrieval-provenance.json'),'canonical_total_known_completed_steps':12983,'returned_steps':282,'attempted_steps':282,'analyzed_steps':282,
 'new_review_integration_steps':0,'new_PPO':0,'full_robot_steps':0,'cloud_hours':0,'source69_files_match_delivered_package':True,
 'saved_contact_rows_reconstructed_from_native_raw':193,'saved_post_geometry_probes_reconstructed':282,'post_geometry_max_difference_m':post_geometry_max_error,
 'first_head_pre_step':5,'last_head_pre_step':215,'head_contact_sample_count':193,'longest_sampled_contiguous_head_interval_s':.146,
 'last_sampled_head_interval_end_s':.432,'floor_first_post_state_step':282,'floor_first_post_state_nominal_s':.564,
 'floor_post_overlap_m':float(.02-float(q[-1,2])),'floor_pre_contact_rows':0,'floor_interpretation':'Stopped on first post-state floor overlap; no floor solver response was integrated. Zero pre-floor contacts is not absence of floor arrival.',
 'max_head_penetration_m':derived['max_head_penetration_m'],'max_head_slip_m_s':derived['max_head_slip_m_s'],
 'positive_tangential_power_samples':derived['head_tangential_positive_power_samples'],'max_positive_tangential_power_W':derived['max_positive_head_tangential_power_W'],
 'tangential_work_J':derived['head_tangential_work_J'],'friction_material_calibration':False,
 'CPU_GPU_same_step_prefix_position_max_m':float(pd.max()),'CPU_GPU_same_step_prefix_linear_velocity_max_m_s':float(vd.max()),'backend_parity_acceptance_invented':False,
 'original_geometry_and_material_guards_passed_for_recorded_prefix':True,'horizon_completed':False,'policy_success':None,'video_review':video,
 'remaining_blockers':['Original material matrix:CPU9 and originalCUDA13 omissions retained; one independent floor-censored CUDA case does not complete them','Original floor penetration and C3/C4,C5/C6 sensitivity failures','Formal head task/reward/acceptance reference release requires separate review; no checkpoint/normalizer compatibility or training approval','Stage10B1/C1 posthoc gaps'],
 'next_decision':'Center diagnostic question is answered. Do not repeat center or automatically start C7. Consolidate material gates and choose a discriminating remaining-case scope before any new local dynamics.',
 'progress_estimate':{'percent':70,'kind':'subjective engineering work estimate, not measured acceptance ratio or policy success','basis':'Independent variant/static mass-inertia checks and interface/reset prototype available; material dynamic closure and final acceptance/publication remain incomplete.'}}
(root/'local-cuda-center-v2-review.json').write_text(json.dumps(result,indent=2,default=d.v2.serial)+'\n')
print(json.dumps({k:result[k] for k in ('status','canonical_total_known_completed_steps','saved_contact_rows_reconstructed_from_native_raw','saved_post_geometry_probes_reconstructed','floor_post_overlap_m','max_head_penetration_m','max_head_slip_m_s')},indent=2,default=d.v2.serial))
