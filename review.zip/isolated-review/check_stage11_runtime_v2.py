from pathlib import Path
import importlib.util,json,time,numpy as np,mujoco,warp as wp,mujoco_warp as mw
from mujoco_warp._src import forward as fw
sp=importlib.util.spec_from_file_location('runtime_v2_check','stage11-build/scripts/diagnose_head_contact_native_witness_runtime_v2.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
out=Path('stage11-runtime-v2-isolated-check');out.mkdir(exist_ok=False)
p=Path('stage11-local-candidate-runtime-review-20261004T123613Z/archive');old=Path('stage11-local-cuda-candidate-review-20261004T120651Z/archive')
model=mujoco.MjModel.from_binary_path(str(p/'diagnostic/material-fixture.mjb'));m.contract(model)
with np.load(p/'diagnostic/material-geometry.npz') as z:triangles=z['vertices'][z['faces']]
states=m.normal.selected_states(Path('stage11-local-cuda-friction-review-20261004T104109Z/archive'))
with np.load(p/'diagnostic/cases/slide-y-plus/states.npz') as z:states.append({'name':'YPLUS5','qpos':z['qpos'][5].copy(),'qvel':z['qvel'][5].copy(),'time':float(z['device_time'][5]),'source_state_index':5})
cases=m.select_pair_cases(old,p);runtime,kernel=m.runtime_modules();report={'pair_controls':[],'pair_query_attempts':0,'pair_queries_completed':0,'forward_controls':[],'forward_query_attempts':0,'forward_queries_completed':0}
with wp.ScopedDevice('cpu'),m.normal.forbid_integration(mw,fw):
 wm=mw.put_model(model);wm.opt.ls_parallel=True;before=m.normal.model_fingerprint(wm)
 m.pair_controls(wm,triangles,cases,out,report,time.monotonic()+300,kernel)
 m.saved_forward_controls(model,wm,triangles,states,out,report,time.monotonic()+300,wp,mw,runtime,kernel)
 assert before==m.normal.model_fingerprint(wm)
report.update(scope='Isolated WarpCPU static checks; no canonical CUDA/dynamics claim',integration_steps=0,new_PPO=0,model_unchanged=True)
m.save(out/'review.json',report)
print(json.dumps({'pair_queries':report['pair_queries_completed'],'forward_queries':report['forward_queries_completed'],'integration_steps':0,'pair_summary':[{'name':r['name'],'status':r['status'],'normal_error_deg':r.get('candidate_geometry',{}).get('normal_error_deg')} for r in report['pair_controls']],'forward_controls':[{'name':r['name'],'passthrough_exact':r['passthrough_exact'],'candidate_status':r['candidate_geometry_status']} for r in report['forward_controls']]},indent=2))
