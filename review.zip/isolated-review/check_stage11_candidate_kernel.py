from pathlib import Path
import importlib.util,json,time,numpy as np,mujoco,warp as wp,mujoco_warp as mw
from mujoco_warp._src import forward as fw
sp=importlib.util.spec_from_file_location('candidate','stage11-build/scripts/validate_head_contact_cuda_candidate.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
sp=importlib.util.spec_from_file_location('candidate_kernel','stage11-build/scripts/head_contact_candidate_kernel.py');w=importlib.util.module_from_spec(sp);sp.loader.exec_module(w)
p=Path('stage11-local-cuda-witness-review-20261004T114251Z/archive');out=Path('stage11-candidate-isolated-check');out.mkdir(exist_ok=False)
model=mujoco.MjModel.from_binary_path(str(p/'diagnostic/material-fixture.mjb'))
with np.load(p/'diagnostic/material-geometry.npz') as z:vertices=z['vertices'].copy();triangles=vertices[z['faces']]
cases=m.select_cases(p,vertices);report={'query_attempts':0,'queries_completed':0,'results':[]}
with wp.ScopedDevice('cpu'),m.normal.forbid_integration(mw,fw):
 wm=mw.put_model(model);before=m.normal.model_fingerprint(wm)
 m.run_queries(wm,cases,w,triangles,out,report,time.monotonic()+300)
 assert before==m.normal.model_fingerprint(wm)
report.update({'scope':'Isolated WarpCPU candidate/native static comparison; not canonical CUDA evidence','new_integration_steps':0,'PPO':0,'model_unchanged':True})
m.save(out/'review.json',report)
for r in report['results']:print(r['name'],r['status'],r['candidate_branch_used'],r.get('candidate_geometry',{}).get('normal_error_deg'),r['preserved'])
