"""Review saved CUDA records without any CPU/GPU integration or model change."""
from pathlib import Path
import gzip,hashlib,importlib.util,json
from unittest.mock import patch
import mujoco,numpy as np
root=Path('stage11-local-cuda-center-review-20261004T095858Z');p=root/'archive/diagnostic';case=p/'cases/release-center'
read=lambda f:json.loads(f.read_text())
lines=lambda f:[json.loads(s) for s in f.read_text().splitlines()]
gz=lambda f:[json.loads(s) for s in gzip.open(f,'rt')]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('cuda_return_review',Path('stage11-build/scripts/diagnose_head_contact_cuda_center.py'));d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
logs,raw=lines(case/'step-log.jsonl'),gz(case/'raw-contacts.jsonl.gz')
flat=gz(case/'contacts.jsonl.gz');states=lines(case/'states.partial.jsonl');run=read(root/'run-summary.json')
assert len(logs)==len(raw)==run['physics_integration_steps']==run['physics_attempted_steps']==6
assert len(states)==7 and len(flat)==1 and [x['step'] for x in logs]==list(range(6))
old=read(root/'archive/package-manifest.json');prior=read(Path('stage11-cuda-center-package-manifest.json'))
assert old==prior
snapshot=read(p/'source-snapshot.json')
assert all(snapshot[n]['sha256']==v['sha256'] for n,v in prior['files'].items())
assert (p/'model-signature-before.json').read_bytes()==(p/'model-signature-after.json').read_bytes()
assert sha(p/'material-fixture.mjb')=='e6cd330bddc3a29abf9ce4eca4f308a2680e4910405725e5ce054cb0a19d2da0'
with np.load(case/'states.npz') as z:
 q,v,t,nominal=(z[k].copy() for k in ('qpos','qvel','device_time','time'))
assert q.shape==(7,7) and v.shape==(7,6)
np.testing.assert_array_equal(nominal,np.arange(7)*.002)
clock=0.
for ti in t[1:]:clock=d.check_clock(clock,ti)
for i,s in enumerate(states):
 assert s['returned_steps']==i and s['device_time_s']==t[i]
 np.testing.assert_array_equal(s['qpos'],q[i]);np.testing.assert_array_equal(s['qvel'],v[i])
with np.load(p/'archived-CPU-center/states.npz') as z:
 cq,cv=z['qpos'].copy(),z['qvel'].copy()
pd=np.linalg.norm(cq[:7,:3]-q[:,:3],axis=1);vd=np.linalg.norm(cv[:7,:3]-v[:,:3],axis=1)
with np.load(p/'material-geometry.npz') as z:triangles=z['vertices'][z['faces']]
model=mujoco.MjModel.from_binary_path(str(p/'material-fixture.mjb'));before=d.floor.model_signature(model)
summary=d.fr.new_summary(read(p/'archived-CPU-center/initial.json'));flags=[];recalculated=[]
with patch.object(mujoco,'mj_step',side_effect=AssertionError('No integration authorized in saved-record review')):
 for i,(entry,r) in enumerate(zip(logs,raw)):
  assert r['step']==i
  np.testing.assert_array_equal(entry['qpos_before'],q[i]);np.testing.assert_array_equal(entry['qvel_after'],v[i+1])
  # JSON loses ndarray dtype. Restore the recorded Warp float32 representation.
  native=[{**c,**{k:np.asarray(c[k],dtype=np.float32) for k in ('pos','frame','force','friction','solref','solimp')},'dist':np.float32(c['dist'])} for c in r['contacts']]
  regenerated=d.v2.contact_rows(model,q[i],v[i],native,i,'warp',triangles)
  assert len(regenerated)==len(entry['contacts'])
  for a,b in zip(regenerated,entry['contacts']):
   for key in ('normal_toward_ball','slip_world_m_s','normal_force_N','torsional_power_W','tangential_power_W'):
    np.testing.assert_allclose(a[key],b[key],rtol=1e-10,atol=1e-12)
   for key in ('normal_error_deg','surface_distance_m','sphere_gap_error_m'):
    np.testing.assert_allclose(a['geometry'][key],b['geometry'][key],rtol=1e-10,atol=1e-12)
  data=mujoco.MjData(model);data.qpos[:]=q[i+1];data.qvel[:]=v[i+1];data.time=t[i+1]
  post=d.fr.post_geometry(model,mujoco.MjData(model),data,triangles)
  for k in ('floor_gap_m','head_overlap_m','floor_overlap_m','original_head_surface_gap_m'):
   np.testing.assert_allclose(post[k],entry['post_geometry'][k],atol=1e-12,rtol=1e-10)
  rows=d.analysis_rows(regenerated);assert d.validate_record(rows,post) is None
  flags.append(d.fr.accumulate(summary,rows,post,i));recalculated.extend(regenerated)
 # Also check every previously saved CPU contact, without re-running the CPU case.
 cpu_contacts=gz(p/'archived-CPU-center/contacts.jsonl.gz')
 for row in cpu_contacts:
  d.validate_record(d.analysis_rows([row]),{'contacts':[],'head_overlap_m':0.,'floor_overlap_m':0.})
assert d.floor.model_signature(model)==before
summary.update(status='SAVED_PREFIX_REVIEW_ONLY',steps=6,attempted_steps=6,analyzed_steps=6,elapsed_simulation_s=.012,
               head_contact_intervals=d.fr.contact_intervals(flags),no_head_contact_intervals=d.fr.contact_intervals([not f for f in flags]))
first=recalculated[0];frame=np.asarray(first['frame']);sign=1 if first['geom'][1]==model.geom('sphere').id else -1
force_world=sign*(frame.T@np.asarray(first['force'])[:3])
predicted=v[5,:3]+.002*(force_world/.01+np.array([0,0,-9.81]))
result={'status':'CUDA_CENTER_CHECKER_DEFECT_CONFIRMED_AND_SAVED_PREFIX_REVIEWED','stage11_status':'MATERIAL_BLOCKED_REVIEW_REQUIRED','stage11_complete':False,
 'retrieval':read(root/'retrieval-provenance.json'),'canonical_completed_steps':12701,'new_steps_from_return':6,'attempted_steps_from_return':6,'new_review_integration_steps':0,'new_PPO':0,
 'record_coverage':{'state_samples':7,'returned_steps':6,'raw_contact_records':len(flat),'step_logs':6,'CPU_saved_contact_records_checked':len(cpu_contacts),'static_post_geometry_forwards':6},
 'original_error':'np.r_ cannot concatenate scalar/vector fields with CUDA (3,3) frame; next frozen CPU accumulator also assumed flat frame',
 'test_gap':'Original mock used a flat frame and mocked the accumulator. New tests use the real saved CUDA contact and run the actual accumulator.',
 'old_summary_preserved':True,'old_summary_head_contact_steps':0,'reviewed_head_contact_steps':sum(flags),'reviewed_head_contact_pre_step':5,'nominal_contact_time_s':.01,
 'reviewed_prefix_s':.012,'all_six_logged_steps_pass_original_material_and_geometry_guards_after_representation_fix':True,
 'derived_summary_not_replacing_original':summary,'first_contact_geometry':first['geometry'],
 'force_linear_velocity_residual_max_m_s':float(abs(predicted-v[6,:3]).max()),
 'CPU_GPU_saved_prefix':{'position_max_m':float(pd.max()),'linear_velocity_max_m_s':float(vd.max()),'new_parity_pass_threshold':False,'CPU_replayed_steps':0},
 'device_clock_max_nominal_difference_s':float(abs(t-nominal).max()),
 'source_manifest_matches_delivered_66_files':True,'model_signature_unchanged':True,
 'video':{'sha256':sha(p/'cuda-center-saved.mp4'),'all_decoded_frames_visually_reviewed':3,'saved_steps':[0,5,6],'timestamps_s':[0,.01,.012],'encoding_playback_duration_s':.12,'physical_prefix_s':.012,'finding':'Fixed crown and ball, no tray; three labelled snapshots consistent with saved contact at 10ms; no sustained retention or policy claim; image cannot measure micrometer geometry.'},
 'remaining':'CUDA material horizon untested after 12ms; original material/floor sensitivity and missing matrix cases remain blocked; full robot/task not released; zero PPO.',
 'next':'Representation-only adapter fix plus same original one-case RTX5060 diagnostic, separate fresh initialization and accounting; no state-splice because full solver state was not saved.'}
(root/'local-cuda-center-review.json').write_text(json.dumps(result,indent=2,default=d.v2.serial)+'\n')
print(json.dumps({k:result[k] for k in ('status','canonical_completed_steps','record_coverage','reviewed_head_contact_steps','force_linear_velocity_residual_max_m_s','CPU_GPU_saved_prefix')},indent=2))
