"""Reconstruct saved CUDA friction evidence with no integration."""
from pathlib import Path
import gzip,hashlib,importlib.util,json
from unittest.mock import patch
import mujoco,numpy as np
root=Path('stage11-local-cuda-friction-review-20261004T104109Z');p=root/'archive/diagnostic'
read=lambda p:json.loads(p.read_text())
lines=lambda p:[json.loads(s) for s in p.read_text().splitlines()]
gz=lambda p:[json.loads(s) for s in gzip.open(p,'rt')]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('cuda_friction_review','stage11-build/scripts/diagnose_head_contact_cuda_friction.py');d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
run,report=read(root/'run-summary.json'),read(p/'diagnostic-review.json')
assert run['physics_integration_steps']==run['physics_attempted_steps']==371
assert run['canonical_total_known_completed_steps']==run['canonical_total_attempted_upper_bound']==13354
assert run['execution_invariants_unchanged'] and not run['stage11_complete'] and run['new_ppo_updates']==0
manifest=read(root/'archive/package-manifest.json');assert manifest==read(Path('stage11-cuda-friction-package-manifest.json'))
assert read(p/'source-snapshot.json')==manifest['files']
assert sha(Path('stage11-build/scripts/diagnose_head_contact_cuda_friction.py'))==report['diagnostic_source_sha256']
assert (p/'model-signature-before.json').read_bytes()==(p/'model-signature-after.json').read_bytes()
assert sha(p/'material-fixture.mjb')=='e6cd330bddc3a29abf9ce4eca4f308a2680e4910405725e5ce054cb0a19d2da0'
with np.load(p/'material-geometry.npz') as z:triangles=z['vertices'][z['faces']]
model=mujoco.MjModel.from_binary_path(str(p/'material-fixture.mjb'));signature=d.floor.model_signature(model)
case_reviews=[];bad=[];static=[]
with patch.object(mujoco,'mj_step',side_effect=AssertionError('No integration permitted in saved review')):
 for summary in report['cases']:
  case=p/'cases'/summary['name'];logs,raw,flat,partial=lines(case/'step-log.jsonl'),gz(case/'raw-contacts.jsonl.gz'),gz(case/'contacts.jsonl.gz'),lines(case/'states.partial.jsonl')
  with np.load(case/'states.npz') as z:q,v,t,nominal=(z[k].copy() for k in ('qpos','qvel','device_time','time'))
  assert len(logs)==len(raw)==summary['steps'] and len(partial)==len(q)==summary['steps']+1
  np.testing.assert_array_equal(nominal,np.arange(len(q))*.002)
  derived=d.fr.new_summary(read(p/'archived-CPU-friction'/summary['name']/'initial.json'));flags=[];clock=0.;idx=0;post_error=0.;failures=[]
  for i,(entry,r) in enumerate(zip(logs,raw)):
   assert entry['step']==r['step']==i;clock=d.check_clock(clock,t[i+1])
   for key,val in [('qpos_before',q[i]),('qvel_before',v[i]),('qpos_after',q[i+1]),('qvel_after',v[i+1])]:np.testing.assert_array_equal(entry[key],val)
   for k in ('qpos','qvel'):np.testing.assert_array_equal(partial[i][k],q[i] if k=='qpos' else v[i])
   assert partial[i]['returned_steps']==i and partial[i]['device_time_s']==t[i]
   native=[{**c,**{k:np.asarray(c[k],dtype=np.float32) for k in ('pos','frame','force','friction','solref','solimp')},'dist':np.float32(c['dist'])} for c in r['contacts']]
   rows=d.analysis_rows(d.v2.contact_rows(model,q[i],v[i],native,i,'warp',triangles))
   assert len(rows)==len(entry['contacts'])
   for a,b in zip(rows,entry['contacts']):
    assert b==flat[idx];idx+=1
    for k in ('frame','normal_toward_ball','slip_world_m_s','normal_force_N','torsional_power_W','tangential_power_W','pyramidal_cone_utilization'):
     if a[k] is None:assert b[k] is None
     else:np.testing.assert_allclose(a[k],b[k],rtol=1e-9,atol=1e-12)
    for k in ('normal_error_deg','surface_distance_m','sphere_gap_error_m'):np.testing.assert_allclose(a['geometry'][k],b['geometry'][k],rtol=1e-9,atol=1e-12)
   data=mujoco.MjData(model);data.qpos[:]=q[i+1];data.qvel[:]=v[i+1];data.time=t[i+1]
   post=d.fr.post_geometry(model,mujoco.MjData(model),data,triangles)
   for k in ('floor_gap_m','head_overlap_m','floor_overlap_m','original_head_surface_gap_m'):
    diff=abs(post[k]-entry['post_geometry'][k]);post_error=max(post_error,diff);assert diff<1e-11
   try:endpoint=d.validate_record(rows,post)
   except RuntimeError as exc:
    assert summary['name']=='slide-x-minus' and i==50 and str(exc)=='Head v2 geometry gate failed'
    failures.append(i);bad.append({'case':summary['name'],'pre_step':i,'error':str(exc),'entry':entry})
    continue
   flags.append(d.fr.accumulate(derived,rows,post,i))
  assert idx==len(flat) and len(flags)==summary['analyzed_steps']
  for key in ('head_contact_steps','floor_contact_steps','max_head_slip_m_s','max_head_penetration_m','max_post_head_overlap_m','max_floor_penetration_m','head_normal_impulse_Ns','head_tangential_world_impulse_Ns','head_tangential_work_J','head_torsional_work_J','max_positive_head_tangential_power_W','head_tangential_positive_power_samples','max_head_cone_utilization'):
   np.testing.assert_allclose(derived[key],summary[key],rtol=1e-9,atol=1e-12)
  assert d.fr.contact_intervals(flags)==summary['head_contact_intervals']
  case_reviews.append({'name':summary['name'],'returned':len(logs),'analyzed':len(flags),'native_contact_rows_reconstructed':len(flat),'head_contact_steps_in_original_summary':summary['head_contact_steps'],'gate_failure_pre_steps':failures,'post_geometry_max_reconstruction_error_m':post_error,'status':summary['status']})
  if summary['name']=='slide-x-minus':
   with np.load(p/'archived-CPU-friction/slide-x-minus/states.npz') as z:cq,cv=z['qpos'].copy(),z['qvel'].copy()
   for name,qq,vv in [('GPU49',q[49],v[49]),('GPU50',q[50],v[50]),('GPU51',q[51],v[51]),('CPU50-native64',cq[50],cv[50]),('CPU50-rounded32',cq[50].astype(np.float32),cv[50].astype(np.float32))]:
    data=mujoco.MjData(model);data.qpos[:]=qq;data.qvel[:]=vv
    before=data.qpos.copy(),data.qvel.copy(),data.time;mujoco.mj_forward(model,data)
    np.testing.assert_array_equal(data.qpos,before[0]);np.testing.assert_array_equal(data.qvel,before[1]);assert data.time==before[2]
    contacts=[]
    for j,c in enumerate(data.contact):
     force=np.zeros(6);mujoco.mj_contactForce(model,data,j,force)
     contacts.append({'geom':c.geom.copy(),'dist':float(c.dist),'pos':c.pos.copy(),'frame':c.frame.copy(),'force':force})
    static.append({'name':name,'qpos':qq,'qvel':vv,'ncon':data.ncon,'contacts':contacts,'qacc':data.qacc.copy(),'warning':data.warning.number.copy()})
assert len(bad)==1 and d.floor.model_signature(model)==signature
b=bad[0]['entry'];r=b['contacts'][0];native=gz(p/'cases/slide-x-minus/raw-contacts.jsonl.gz')[50]['contacts'][0]
frame=np.asarray(native['frame'],dtype=np.float64).reshape(3,3);force=np.asarray(native['force'],dtype=np.float64)
# Native frame force is force on geom2; sphere is geom1 for this record.
assert native['geom']==[2,1] and model.geom('sphere').id==2
f=-frame.T@force[:3];torque=-frame.T@force[3:];dt=model.opt.timestep;mass=model.body_mass[model.geom_bodyid[2]]
dv=np.asarray(b['qvel_after'][:3])-np.asarray(b['qvel_before'][:3]);pred=(f/mass+model.opt.gravity)*dt
np.testing.assert_allclose(dv,pred,atol=3e-9,rtol=1e-6)
q0=np.asarray(b['qpos_before']);rot=np.zeros(9);mujoco.mju_quat2Mat(rot,q0[3:]);rot=rot.reshape(3,3)
w0=rot@np.asarray(b['qvel_before'][3:]);w1same=rot@np.asarray(b['qvel_after'][3:])
moment=np.cross(np.asarray(native['pos'])-q0[:3],f)+torque
ang_pred=moment/model.body_inertia[model.geom_bodyid[2],0]*dt
np.testing.assert_allclose(w1same-w0,ang_pred,atol=2e-6,rtol=1e-5)
for video in report['videos']:
 assert sha(p/video['file'])==video['sha256']
 assert len(list((root/'video-frames'/video['file'].removesuffix('-saved.mp4')).glob('frame-*.png')))==video['frames']
result={'status':'CUDA_FRICTION_REVIEWED_REAL_NORMAL_FAILURE','stage11_status':'MATERIAL_BLOCKED_REVIEW_REQUIRED','stage11_complete':False,'canonical_total_known_completed_steps':13354,'new_review_integration_steps':0,'new_PPO':0,'full_robot_steps':0,'cloud_hours':0,'source73_files_match_delivered_package':True,'retrieval':read(root/'retrieval-provenance.json'),'cases':case_reviews,'not_run_cases':report['not_run_cases'],'failed_record':bad[0],
 'impulse_check':{'native_force_on_sphere_world_N':f,'native_torque_on_sphere_world_Nm':torque,'delta_linear_velocity_observed':dv,'delta_linear_velocity_predicted':pred,'linear_max_error':float(np.max(np.abs(dv-pred))),'delta_angular_velocity_world_observed':w1same-w0,'delta_angular_velocity_world_predicted':ang_pred,'angular_max_error':float(np.max(np.abs(w1same-w0-ang_pred))),'qvel_angular_basis':'both pre/post generalized angular velocities expressed in pre-step sphere local basis for integrator impulse check','conclusion':'Abnormal normal creates a real lateral and angular impulse; nanometre contact distance is not harmless.'},
 'CPU_same_saved_state_zero_integration_forwards':static,'video_review':{'frames':55,'videos':2,'all_frames_visually_reviewed':True,'plus':'Ball rolls on head, departs and reaches floor at nominal0.640s; post overlap2.311mm violates1mm gate.','minus':'Stops at nominal0.102s on head with abnormal y-directed normal label at0.100s. No tray; fixed-head material only.','limits':'Video cannot establish micrometre/nanometre overlap or resolve12micrometre sideways displacement. No policy or full-horizon success.'},
 'mechanism_hypothesis':'Pinned local Warp3.8.1 ccd shrinks sphere then inflates GJK witness; convex normal normalizes difference of world-space inflated witnesses. Near-touch float32 cancellation is plausible. Actual pre/post-inflation witnesses were not saved; full causal chain is unproven.',
 'next_scope':'Zero-integration native CUDA collision/forward on saved GPU49/50/51 and CPU50 states, source and primary-state guards, no runtime patch or tolerance change. Four unrun friction cases remain unrun.',
 'unresolved':['Original material CPU9/CUDA13 omissions retained','Floor original2ms penetration and C3/C4,C5/C6 sensitivity failures; noC7','New CUDA slide-x-minus real90degree normal failure','No formal reference/reward/acceptance/checkpoint/normalizer release, PPO0','Stage10B1/C1 posthoc gaps'],
 'progress_estimate':{'percent':70,'kind':'subjective engineering-work estimate unchanged; not acceptance or policy success'}}
(root/'local-cuda-friction-review.json').write_text(json.dumps(result,indent=2,default=d.v2.serial)+'\n')
print(json.dumps({'cases':case_reviews,'impulse_check':result['impulse_check'],'CPU_static_contacts':[{'name':s['name'],'ncon':s['ncon'],'contacts':s['contacts']} for s in static]},indent=2,default=d.v2.serial))
