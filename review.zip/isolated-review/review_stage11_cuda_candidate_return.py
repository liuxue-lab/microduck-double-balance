"""Reconstruct returned static CUDA candidate records without integration."""
from pathlib import Path
import importlib.util,json,hashlib,numpy as np
root=Path('stage11-local-cuda-candidate-review-20261004T120651Z');p=root/'archive/diagnostic'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sp=importlib.util.spec_from_file_location('candidate_review','stage11-build/scripts/validate_head_contact_cuda_candidate.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
run,report=read(root/'run-summary.json'),read(p/'diagnostic-review.json')
assert run['physics_integration_steps']==run['physics_attempted_steps']==report['diagnostic_completed_steps']==report['diagnostic_attempted_steps']==0
assert run['canonical_total_known_completed_steps']==report['canonical_total_known_completed_steps']==13354
assert run['query_attempts']==run['queries_completed']==report['query_attempts']==report['queries_completed']==11
assert run['execution_invariants_unchanged'] and report['CPU_model_unchanged'] and report['GPU_model_unchanged'] and report['source_files_unchanged']
assert not report['not_completed_cases'] and not report['installed_dependency_patch'] and not report['candidate_used_by_integrator_or_solver']
manifest=read(root/'archive/package-manifest.json');assert manifest==read(Path('stage11-cuda-candidate-package-manifest.json'))
assert read(p/'source-snapshot.json')==manifest['files']
for n,meta in manifest['files'].items():assert sha(Path('stage11-build')/n)==meta['sha256']
assert report['diagnostic_source_sha256']==sha(Path('stage11-build/scripts/validate_head_contact_cuda_candidate.py'))
for prefix in ('model-signature','device-model'):assert (p/(prefix+'-before.json')).read_bytes()==(p/(prefix+'-after.json')).read_bytes()
with np.load(p/'material-geometry.npz') as z:triangles=z['vertices'][z['faces']]
results=[]
for name,item in zip(m.CASE_NAMES,report['results'],strict=True):
 case=read(p/'cases'/name/'input.json');case['geom_xpos']=np.asarray(case['geom_xpos'],np.float32);case['geom_xmat']=np.asarray(case['geom_xmat'],np.float32)
 raw=read(p/'cases'/name/'raw-result.json');raw={**raw,**{k:np.asarray(raw[k],np.float32) for k in ('scalars','vectors','frame','candidate_frame')}}
 rebuilt=m.analyze(case,raw,triangles);rebuilt=json.loads(json.dumps(rebuilt,default=m.v2.serial))
 assert rebuilt==item==read(p/'cases'/name/'analysis.json')
 assert all(rebuilt['preserved'].values()) and rebuilt['original_fields_match_saved_CUDA'] is not False
 if name in m.BASE_CASES:assert rebuilt['original_fields_match_saved_CUDA']
 if rebuilt['candidate_branch_used']:
  s=np.asarray(raw['scalars'],np.float32);v=np.asarray(raw['vectors'],np.float32);direction=v[16].astype(float);direction/=np.linalg.norm(direction)
  np.testing.assert_allclose(np.asarray(raw['candidate_frame'])[0],direction,rtol=2e-7,atol=1e-12)
  assert s[0]==s[9] and np.array_equal(v[0],v[12]) and np.array_equal(v[1],v[13])
 results.append(rebuilt)
contacts=[r for r in results if r['status']=='CANDIDATE_STATIC_CONTACT_GATE_PASS_REVIEW_REQUIRED']
assert len(contacts)==6 and sum(r['status']=='NO_CONTACT_CONTROL_PRESERVED' for r in results)==4
assert results[-1]['status']=='DEEP_BRANCH_PARITY_ONLY_NOT_PHYSICAL_PASS'
result={'status':'ISOLATED_STATIC_CUDA_NORMAL_CANDIDATE_REVIEWED','stage11_status':'MATERIAL_BLOCKED_REVIEW_REQUIRED','stage11_complete':False,'retrieval':read(root/'retrieval-provenance.json'),'queries_reviewed':11,'ordinary_contact_gates_passed':6,'no_contact_controls_preserved':4,'deep_fallback_parity_only':1,'max_ordinary_contact_normal_error_deg':max(r['candidate_geometry']['normal_error_deg'] for r in contacts),'canonical_integration_total':13354,'new_review_integration_steps':0,'new_PPO':0,'source87_files_and_CPU_GPU_models_unchanged':True,'results':results,'limits':['No candidate solver/integrator evidence yet','Deep fallback control is not a physical penetration pass','Original floor2ms/sensitivity issues and missing cases remain','No formal physics/task migration or policy success'], 'next_scope':'Independent material runtime candidate: original forward position sequence with a guarded normal-frame replacement after collision and before constraints. Check exact native distance/position/presence before any replacement. Then bounded original six friction prefixes; no installed dependency patch or formal adoption.'}
(root/'local-cuda-candidate-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('results','retrieval')},indent=2))
