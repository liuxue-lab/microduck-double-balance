"""Saved runtime records reconstruction; no integrator calls."""
from pathlib import Path
import json,gzip,hashlib,importlib.util,numpy as np,mujoco
from unittest.mock import patch
root=Path('stage11-local-candidate-runtime-review-20261004T123613Z');p=root/'archive/diagnostic'
read=lambda p:json.loads(p.read_text());gz=lambda p:[json.loads(s) for s in gzip.open(p,'rt')];lines=lambda p:[json.loads(s) for s in p.read_text().splitlines()];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sp=importlib.util.spec_from_file_location('runtime_review','stage11-build/scripts/diagnose_head_contact_candidate_runtime.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
run,report=read(root/'run-summary.json'),read(p/'diagnostic-review.json');manifest=read(root/'archive/package-manifest.json')
assert manifest==read(Path('stage11-candidate-runtime-package-manifest.json'))=={'files':read(p/'source-snapshot.json'),**{k:v for k,v in manifest.items() if k!='files'}}
assert run['physics_integration_steps']==run['physics_attempted_steps']==578 and run['canonical_total_known_completed_steps']==13932
assert run['execution_invariants_unchanged'] and all(report[k] for k in ('CPU_model_unchanged','GPU_model_unchanged','source_files_unchanged','input_files_unchanged','dependency_sources_unchanged'))
for n,meta in manifest['files'].items():assert sha(Path('stage11-build')/n)==meta['sha256']
assert report['diagnostic_source_sha256']==sha(Path('stage11-build/scripts/diagnose_head_contact_candidate_runtime.py'))
for prefix in ('model-signature','device-model'):assert (p/(prefix+'-before.json')).read_bytes()==(p/(prefix+'-after.json')).read_bytes()
model=mujoco.MjModel.from_binary_path(str(p/'material-fixture.mjb'));m.contract(model)
with np.load(p/'material-geometry.npz') as z:triangles=z['vertices'][z['faces']]
controls=[]
for c in report['forward_controls']:
 d=p/'forward-controls'/c['name'];a,b,k=(read(d/(n+'.json')) for n in ('native','passthrough','candidate'))
 m.parity(a['records'],b['records']);np.testing.assert_array_equal(a['qacc'],b['qacc'])
 controls.append({'name':c['name'],'native_passthrough_exact':True,'candidate_status':c['candidate_geometry_status']['status'],'native_qacc':a['qacc'],'candidate_qacc':k['qacc']})
assert len(controls)==4 and report['forward_queries_completed']==report['forward_query_attempts']==12
cases=[];failure=None
with patch.object(mujoco,'mj_step',side_effect=RuntimeError('Saved review forbids integration')):
 for summary in report['cases']:
  name=summary['name'];d=p/'cases'/name
  logs,raw,flat,hooks,partials=lines(d/'step-log.jsonl'),gz(d/'raw-contacts.jsonl.gz'),gz(d/'contacts.jsonl.gz'),gz(d/'normal-candidate.jsonl.gz'),lines(d/'states.partial.jsonl')
  queries=[x['raw'] for x in hooks if 'raw' in x];checked=[x['checked'] for x in hooks if 'checked' in x]
  with np.load(d/'states.npz') as z:q,v,t=(z[k].copy() for k in ('qpos','qvel','device_time'))
  assert len(logs)==len(raw)==summary['steps']==summary['analyzed_steps'] and len(q)==len(partials)==summary['steps']+1
  assert len(queries)==summary['forward_attempts'] and len(checked)==summary['forward_completed']
  for i,h in enumerate(queries):
   r=h['pair_result'];r={**r,**{k:np.asarray(r[k],np.float32) for k in ('scalars','vectors','frame','candidate_frame')}}
   try:a=m.hook_decision(h['native_contacts'],r,np.asarray(h['geom_xpos'],np.float32),np.asarray(h['geom_xmat'],np.float32),triangles)
   except RuntimeError as exc:
    assert name=='slide-y-plus' and i==5 and str(exc)=='Candidate changed distance, witnesses or contact presence'
    s,vv=r['scalars'],r['vectors'];native=h['native_contacts'][0]
    assert float(s[0])==native['dist'] and np.array_equal(vv[9],native['pos']) and np.array_equal(r['frame'],native['frame'])
    failure={'case':name,'pre_step':5,'integration_steps_before_stop':5,'integration_of_failed_forward':False,'native_live_matches_native_kernel':True,'candidate_distance_delta_m':float(s[9])-float(s[0]),'candidate_witness1_delta_m':vv[12].astype(float)-vv[0],'candidate_witness2_delta_m':vv[13].astype(float)-vv[1],'candidate_midpoint_delta_m':vv[15].astype(float)-vv[9],'candidate_and_native_contact_present':True,'error':str(exc)}
   else:
    assert i<len(checked);assert json.loads(json.dumps(a,default=m.v2.serial))==checked[i]['analysis']
  derived=m.fr.new_summary(read(p/'archived-CPU-friction'/name/'initial.json'));flags=[];idx=0;clock=0.;normal_errors=[];max_dv_error=0.
  for i,(log,r) in enumerate(zip(logs,raw)):
   clock=m.cc.check_clock(clock,float(t[i+1]));assert log['step']==r['step']==i
   for key,val in [('qpos_before',q[i]),('qvel_before',v[i]),('qpos_after',q[i+1]),('qvel_after',v[i+1])]:np.testing.assert_array_equal(log[key],val)
   native=[{**c,**{k:np.asarray(c[k],np.float32) for k in ('pos','frame','force','friction','solref','solimp')},'dist':np.float32(c['dist'])} for c in r['contacts']]
   rows=m.cc.analysis_rows(m.v2.contact_rows(model,q[i],v[i],native,i,'warp',triangles))
   assert len(rows)==len(log['contacts'])
   for a,b in zip(rows,log['contacts']):
    assert b==flat[idx];idx+=1
    for key in ('slip_world_m_s','normal_toward_ball','tangential_power_W','torsional_power_W','pyramidal_cone_utilization'):
     if a[key] is None:assert b[key] is None
     else:np.testing.assert_allclose(a[key],b[key],rtol=1e-9,atol=1e-12)
    normal_errors.append(a['geometry']['normal_error_deg']);assert m.v2.selected_geometry_pass(a['geometry'],'v2')
   state=mujoco.MjData(model);state.qpos[:]=q[i+1];state.qvel[:]=v[i+1];state.time=t[i+1]
   post=m.fr.post_geometry(model,mujoco.MjData(model),state,triangles)
   for key in ('head_overlap_m','floor_overlap_m','original_head_surface_gap_m'):np.testing.assert_allclose(post[key],log['post_geometry'][key],rtol=0,atol=1e-11)
   endpoint=m.cf.validate_record(rows,post);flags.append(m.fr.accumulate(derived,rows,post,i))
   force=np.zeros(3)
   for c in native:
    assert np.array_equal(c['geom'],[2,1]);force-=np.asarray(c['frame'],float).T@np.asarray(c['force'][:3],float)
   pred=(model.opt.gravity+force/.01)*.002;dv=v[i+1,:3].astype(float)-v[i,:3]
   max_dv_error=max(max_dv_error,float(np.max(np.abs(dv-pred))))
  assert idx==len(flat)
  for key in ('head_contact_steps','floor_contact_steps','max_head_slip_m_s','max_head_penetration_m','max_post_head_overlap_m','max_floor_penetration_m','head_normal_impulse_Ns','head_tangential_world_impulse_Ns','head_tangential_work_J','head_torsional_work_J','max_positive_head_tangential_power_W','head_tangential_positive_power_samples','max_head_cone_utilization'):
   np.testing.assert_allclose(derived[key],summary[key],rtol=1e-9,atol=1e-12)
  assert m.fr.contact_intervals(flags)==summary['head_contact_intervals']
  case_review={'name':name,'returned_and_analyzed':summary['steps'],'forward_attempts':len(queries),'forward_completed':len(checked),'head_contact_rows':len(flat),'head_normal_error_max_deg':max(normal_errors,default=0),'force_to_observed_delta_v_max_error_m_s':max_dv_error,'status':summary['status'],'max_floor_overlap_m':summary['max_floor_penetration_m']}
  if name=='slide-x-minus':
   case_review['candidate_pre50_to51_delta_y_velocity_m_s']=float(v[51,1]-v[50,1]);case_review['max_absolute_y_velocity_first52states_m_s']=float(np.max(np.abs(v[:52,1])))
   with np.load('stage11-local-cuda-friction-review-20261004T104109Z/archive/diagnostic/cases/slide-x-minus/states.npz') as z:ov=z['qvel']
   case_review['historical_original_pre50_to51_delta_y_velocity_m_s']=float(ov[51,1]-ov[50,1])
   case_review['comparison_limit']='Fresh candidate prefix changes previous normals; not an identical full-state counterfactual at step50. Saved forward controls separately isolate frame change.'
  cases.append(case_review)
assert failure is not None
result={'status':'CANDIDATE_RUNTIME_REVIEWED_PARTIAL_DYNAMIC_PROGRESS_AND_EXACT_PRESERVATION_BLOCK','stage11_status':'MATERIAL_BLOCKED_REVIEW_REQUIRED','stage11_complete':False,'retrieval':read(root/'retrieval-provenance.json'),'new_returned_steps':578,'canonical_integration_total':13932,'new_review_integration_steps':0,'PPO':0,'source92_files_and_models_unchanged':True,'forward_controls':controls,'cases':cases,'failed_raw_query':failure,'not_run_cases':report['not_run_cases'],'videos':report['videos'],'video_review':'PENDING','next_design':'Use the exact native head witness and sphere center to construct a robust candidate normal, retaining native CCD distance/witnesses/contact presence by construction. Restrict to finite shallow contacts, preserve deep/no-contact fallback, and revalidate without loosening exact preservation gates.','remaining':['Floor2ms first-impact and sensitivity blockers','Candidate v1 repeated-GJK preservation failure on first positiveY contact','Full material acceptance and original omissions remain','Formal head task migration and unassisted policy objective unreleased; Stage10B1/C1 gaps remain']}
(root/'local-candidate-runtime-review.json').write_text(json.dumps(result,indent=2,default=m.v2.serial)+'\n')
print(json.dumps({'cases':cases,'failed_raw_query':failure,'canonical_total':13932},indent=2,default=m.v2.serial))
