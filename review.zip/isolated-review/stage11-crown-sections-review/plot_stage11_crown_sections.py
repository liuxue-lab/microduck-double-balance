from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'stage11-crown-sections-review'
report=json.loads((OUT/'crown-section-review.json').read_text())
data=json.loads((OUT/'sections.json').read_text())['rows']
floor=json.loads((OUT/'floor-first-step-review.json').read_text())
z=np.load(ROOT/'stage11-local-friction-review-20261003T183812Z/archive/diagnostic/material-geometry.npz')
pose=json.loads((ROOT/'stage11-local-prototype-review-20261003T205659Z/archive/prototype/prototype-static-configurations.json').read_text())[0]
v=(z['vertices']-np.array(pose['origin']))@np.array(pose['rotation']);f=z['faces']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig=plt.figure(figsize=(12.6,9.1),layout='constrained')
gs=fig.add_gridspec(2,2)
ax=fig.add_subplot(gs[0,0],projection='3d',computed_zorder=False)
ax.plot_trisurf(v[:,0]*1000,v[:,1]*1000,v[:,2]*1000,triangles=f,color='#b9ceda',linewidth=0,antialiased=False,alpha=.96,shade=True)
ends=np.array(report['ridge']['material_endpoints_m'])*1000
ax.plot(ends[:,0],ends[:,1],ends[:,2],color='#c74524',lw=4,label='29.82 mm top edge',zorder=10)
ax.scatter([0],[0],[0],color='#20252b',s=32,label='Existing reference',depthshade=False,zorder=11)
ax.set(xlabel='Material X (mm)',ylabel='Material Y (mm)',zlabel='Material Z (mm)')
ax.set_title('A  Saved head mesh in the levelled hypothesis',loc='left',pad=8)
ax.view_init(elev=28,azim=-60);ax.set_box_aspect((1.25,.92,.58));ax.legend(loc='upper left',fontsize=8)

ax=fig.add_subplot(gs[0,1])
colors={'actual_HOME':'#315f9b','hypothetical_tangent_levelled':'#c74524'}
labels={'actual_HOME':'Saved HOME orientation','hypothetical_tangent_levelled':'Hypothetical tangent levelled'}
for frame in colors:
    rows=[r for r in data if r['frame']==frame and r['axis']=='x']
    ax.plot([r['offset_m']*1000 for r in rows],[r['height_change_m']*1000 for r in rows],label=labels[frame],c=colors[frame],lw=2)
ax.axhline(0,c='#777777',lw=.7);ax.axvline(0,c='#aaaaaa',lw=.7)
ax.axvspan(ends[0,0],ends[1,0],color='#c74524',alpha=.07)
ax.set(xlabel='Longitudinal offset in each frame (mm)',ylabel='Ball center height change (mm)',title='B  Levelled reference has no longitudinal well')
ax.grid(alpha=.18);ax.legend(fontsize=8,loc='lower right')

ax=fig.add_subplot(gs[1,0])
for axis,color,label in [('x','#315f9b','Along the ridge'),('y','#c74524','Across the ridge')]:
    rows=[r for r in data if r['frame']=='hypothetical_tangent_levelled' and r['axis']==axis and abs(r['offset_m'])<=.001]
    ax.plot([r['offset_m']*1000 for r in rows],[r['height_change_m']*1e6 for r in rows],'o-',lw=2,ms=4,c=color,label=label)
ax.axhline(0,c='#777777',lw=.7)
ax.set(xlabel='Offset from reference (mm)',ylabel='Ball center height change (micrometers)',title='C  Transverse motion lowers gravitational potential')
ax.grid(alpha=.18);ax.legend(fontsize=9,loc='lower center')

ax=fig.add_subplot(gs[1,1])
a0=floor['saved_cases'][0];values=[a0['initial_gap_m']*1000,a0['saved_next_gap_m']*1000]
bars=ax.bar(['Saved pre-step','After one 2 ms step'],values,color=['#315f9b','#c74524'],width=.5)
ax.axhline(0,c='#555555',lw=1);ax.axhline(-1,c='#a62929',ls='--',lw=1.1,label='Unchanged -1 mm penetration limit')
for b,value in zip(bars,values):
    ax.text(b.get_x()+b.get_width()/2,value+(.10 if value>=0 else -.12),f'{value:+.3f} mm',ha='center',va='bottom' if value>=0 else 'top',fontweight='bold')
ax.set(ylabel='Sphere-floor gap (mm)',ylim=(-3.45,1.1),title='D  Original first-step overshoot precedes reaction')
ax.text(.5,.14,'No contact force at the saved pre-step state',ha='center',transform=ax.transAxes,fontsize=8)
ax.legend(loc='lower center',fontsize=8)
fig.suptitle('Stage 11: two physical questions resolved from saved evidence',fontsize=15,fontweight='bold')
fig.supxlabel('202 mesh section samples; sphere radius 20 mm. Local edge rounding is not measured smooth-head curvature.\nNo new simulation, PPO, task change, or policy success claim.',fontsize=9)
fig.savefig(OUT/'crown-and-floor-review.png',dpi=180)
fig.savefig(OUT/'crown-and-floor-review.pdf')
plt.close(fig)
print(str(OUT/'crown-and-floor-review.png'))
