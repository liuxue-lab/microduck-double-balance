"""Saved A0/C3/C4 free-flight arithmetic only; no new simulation."""
from pathlib import Path
import gzip
import hashlib
import json
import numpy as np

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'stage11-crown-sections-review';OUT.mkdir(exist_ok=True)
inputs={}
def record(path):
    b=path.read_bytes();meta={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
    archive=next(p for p in path.parents if p.name=='archive')
    inventory=json.loads((archive/'evidence-inventory.json').read_text())
    assert inventory[str(path.relative_to(archive))]==meta
    inputs[str(path.relative_to(ROOT))]=meta
    return path

records=[]
for case,folder in [('A0','stage11-local-floor-review-20261003T141958Z'),
                    ('C3','stage11-local-refinement-review-20261003T173938Z'),
                    ('C4','stage11-local-refinement-review-20261003T173938Z')]:
    d=ROOT/folder/'archive/diagnostic/cases'/case
    z=np.load(record(d/'states.npz'),allow_pickle=False)
    init=json.loads(record(d/'initialization.json').read_text())
    with gzip.open(record(d/'contacts.jsonl.gz'),'rt') as f: first=json.loads(next(f))
    assert init['initial_contacts']==0 and first['contacts']==[] and first['raw_contacts']==[]
    np.testing.assert_array_equal(z['qpos'][0],init['qpos'])
    np.testing.assert_array_equal(z['qvel'][0],init['qvel'])
    dt=float(z['dt']); gap=float(z['qpos'][0,2]-.02); vz=float(z['qvel'][0,2]); g=9.81
    expected_v=vz-g*dt
    expected_gap=gap+dt*expected_v
    v_error=abs(float(z['qvel'][1,2])-expected_v)
    q_error=abs(float(z['qpos'][1,2]-.02)-expected_gap)
    assert v_error<1e-14 and q_error<1e-14
    records.append({'case':case,'dt_s':dt,'initial_gap_m':gap,'initial_vz_m_s':vz,
                    'pre_step_contacts':0,'saved_next_gap_m':float(z['qpos'][1,2]-.02),
                    'predicted_next_gap_m':expected_gap,'velocity_residual_m_s':v_error,
                    'gap_residual_m':q_error})
a0=records[0];u=-a0['initial_vz_m_s'];gap=a0['initial_gap_m'];g=9.81;limit=.001
# Stable quadratic solution for g*h*h+u*h<=gap+limit.
bound=lambda clearance: 2*(clearance+limit)/(np.sqrt(u*u+4*g*(clearance+limit))+u)
bound_known=bound(gap);bound_phase=bound(0.)
assert abs(gap-u*bound_known-g*bound_known**2+limit)<1e-15
table=[]
for dt in [.002,.001,.0005,.00025,.000125,.0000625]:
    table.append({'dt_s':dt,'arbitrary_phase_limit_free_flight_overshoot_m':u*dt+g*dt*dt,
                   'original_start_one_step_overlap_m':max(0,u*dt+g*dt*dt-gap),
                   'necessary_arbitrary_phase_1mm_condition':u*dt+g*dt*dt<=limit})
review={
    'result':'SAVED_FLOOR_FIRST_STEP_ARITHMETIC_RECONCILED',
    'inputs':inputs,'saved_cases':records,
    'formula':'v_next=v-g*h; gap_next=gap+h*v_next (saved semi-implicit Euler free-flight update)',
    'initial_downward_speed_m_s':u,'penetration_limit_m':limit,
    'necessary_max_first_step_for_saved_start_s':float(bound_known),
    'necessary_max_step_for_near_zero_gap_phase_at_same_speed_s':float(bound_phase),
    'illustrations_only':table,
    'conclusions':[
        'The first A0 penetration is already 2.667188375818mm after a contact-free update at h=2ms. It precedes any floor reaction in that step.',
        'Changing only contact stiffness or friction cannot prevent this same first-step overshoot while preserving the saved start, zero margin/contact activation, update scheme and 2ms timestep.',
        'For this exact saved start, h must be at most the reported ~1ms bound merely to keep that one free step within 1mm. For an arbitrarily small positive starting gap at the same speed, the necessary bound is ~0.61ms.',
        'These are necessary free-flight sampling conditions, not sufficient contact penetration or convergence criteria. Smaller steps still require the unchanged full material and C3/C4-style convergence checks.',
    ],
    'limits':['Not a global speed bound, selected new timestep, contact calibration or candidate pass',
              'Positive contact margin, continuous collision treatment, a different integrator or initial state changes the premise and requires a separate model/task review',
              'No new C5, parameter sweep, time alignment, threshold relaxation or shortened acceptance horizon'],
    'new_integration_steps':0,'canonical_total_steps':7895,'new_PPO':0,'cloud_hours':0,
    'stage11_status':'MATERIAL_BLOCKED_REVIEW_REQUIRED','stage11_complete':False,
    'formal_task_migration':False,
}
(OUT/'floor-first-step-review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'cases':records,'saved_start_max_dt_ms':bound_known*1000,
                  'near_zero_gap_phase_max_dt_ms':bound_phase*1000,'new_steps':0},indent=2))
