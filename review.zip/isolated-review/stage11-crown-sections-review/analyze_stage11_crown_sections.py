"""Saved mesh geometry only: finite-sphere height sections, no physics engine."""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import time
import numpy as np

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'stage11-crown-sections-review'
OUT.mkdir(exist_ok=True)
INPUTS = {
    'stage11-local-friction-review-20261003T183812Z/archive/diagnostic/material-geometry.npz': 'b2b22ae8e2798b18b292bfc3c181475dde03e5f0030e93839f4447122fb1dcc5',
    'stage11-local-prototype-review-20261003T205659Z/archive/prototype/prototype-static-configurations.json': 'fa37d385832771e401443a9c2a72572e6efb3e870917cced76b99ad3362150a0',
    'stage11-local-reference-review-20261003T195947Z/archive/reference/candidate-references.json': '7d396087f948620dc5c5ca67e97fddd72a25e09dd120c90cbc826ffc939bc7cb',
    'stage11-build/src/mjlab_microduck/robot/head_contact.py': '8a2446aa27d8e420e6e26e5e9985ab24cb774036936f393de680857edfd0af64',
}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def save(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False)+'\n')

save('analysis-scope.json', {
    'question': 'Does the existing finite-radius sphere reference become a passive local potential well when its material tangent frame is hypothetically levelled?',
    'kind': 'Saved original mesh arithmetic; no engine import, model construction, forward, reset or integration',
    'actual_HOME': 'Uses world vertical as saved',
    'levelled_hypothesis': 'Rigidly express the saved mesh in the existing material reference frame, then assume gravity along minus that frame Z solely for geometry/potential interpretation. This is not a new robot joint command or initial pose.',
    'sphere_radius_m': .02, 'analysis_contact_gap_m': 0,
    'original_reset_clearance_unchanged_m': .0005,
    'sections': 'X: -20..30mm by 1mm, Y: -20..20mm by 1mm; extra ±.25/.5mm and exact ridge endpoints. Inspection windows are not an accepted crown/recovery boundary.',
    'mesh_extrema_numerical_tolerance_m': 1e-12,
    'root_bracket_width_target_m': 1e-12,
    'same_mesh_oracle_distance_tolerance_m': 3e-12,
    'max_wall_seconds': 300,
    'new_integration_steps': 0, 'new_PPO': 0, 'cloud_hours': 0,
    'formal_task_migration': False, 'selected_new_reference': None,
    'inputs': INPUTS,
})
for rel, expected in INPUTS.items():
    assert sha(ROOT/rel) == expected, rel
spec = importlib.util.spec_from_file_location('frozen_numpy_geometry', ROOT/'stage11-build/src/mjlab_microduck/robot/head_contact.py')
oracle = importlib.util.module_from_spec(spec); spec.loader.exec_module(oracle)
start = time.monotonic()

class ColumnGeometry:
    """Cache exact triangle projection terms after a conservative XY AABB prune."""
    def __init__(self, triangles, xy, radius):
        self.all = triangles
        mn = triangles[:, :, :2].min(axis=1); mx = triangles[:, :, :2].max(axis=1)
        xy_distance = np.maximum(np.maximum(mn-xy, xy-mx), 0.)
        self.ids = np.flatnonzero(np.sum(xy_distance**2, axis=1) <= (radius+1e-12)**2)
        assert len(self.ids)
        self.triangles = triangles[self.ids]
        self.a, self.b, self.c = (self.triangles[:, i] for i in range(3))
        self.ab, self.ac = self.b-self.a, self.c-self.a
        self.normal = np.cross(self.ab, self.ac)
        self.nn = np.einsum('ij,ij->i', self.normal, self.normal)
        self.aa = np.einsum('ij,ij->i', self.ab, self.ab)
        self.bb = np.einsum('ij,ij->i', self.ac, self.ac)
        self.cc = np.einsum('ij,ij->i', self.ab, self.ac)
        self.den = self.aa*self.bb-self.cc*self.cc
        self.edges = [(a, b-a, np.sum((b-a)**2, axis=1)) for a,b in
                      ((self.a,self.b), (self.b,self.c), (self.c,self.a))]

    def distance(self, point):
        signed = np.sum((point-self.a)*self.normal, axis=1)
        projected = point-self.normal*np.divide(signed, self.nn, out=np.zeros_like(signed), where=self.nn>1e-30)[:,None]
        ap = projected-self.a
        x = np.sum(ap*self.ab, axis=1); y = np.sum(ap*self.ac, axis=1)
        u = np.divide(self.bb*x-self.cc*y, self.den, out=np.zeros_like(x), where=np.abs(self.den)>1e-30)
        v = np.divide(self.aa*y-self.cc*x, self.den, out=np.zeros_like(y), where=np.abs(self.den)>1e-30)
        valid = (self.nn>1e-30) & (u>=0) & (v>=0) & (u+v<=1)
        d2 = np.where(valid, np.sum((point-projected)**2, axis=1), np.inf)
        for a, edge, length2 in self.edges:
            t = np.clip(np.divide(np.sum((point-a)*edge,axis=1),length2,out=np.zeros_like(length2),where=length2>0),0,1)
            d2 = np.minimum(d2,np.sum((point-a-t[:,None]*edge)**2,axis=1))
        return float(np.sqrt(d2.min()))

def support_height(xy, triangles, radius=.02):
    # Every examined center is above EVERY mesh vertex. On this restricted
    # interval distance to the whole mesh increases monotonically with z.
    lo=float(triangles[:,:,2].max()); hi=lo+radius+.001
    geom=ColumnGeometry(triangles,np.asarray(xy),radius)
    assert geom.distance(np.array([*xy,lo])) < radius, 'No proved above-all-vertices bracket'
    assert geom.distance(np.array([*xy,hi])) > radius
    while hi-lo>1e-12:
        mid=(lo+hi)/2
        if geom.distance(np.array([*xy,mid])) < radius: lo=mid
        else: hi=mid
    center=np.array([*xy,hi])
    # Separate, unpruned, frozen algorithm independently verifies every root.
    witness,distance,face=oracle.nearest_surface(center,triangles)
    assert abs(distance-radius)<3e-12 and center[2]>triangles[:,:,2].max()
    normal=(center-witness)/distance
    return {'center':center.tolist(),'witness':witness.tolist(),'normal':normal.tolist(),
            'face':int(face),'gap_m':float(distance-radius),'retained_triangles':len(geom.ids)}

# Analytic plane and symmetric ridge fixtures test sign/branch/radius behavior.
plane=np.array([[[-.1,-.1,0],[.1,-.1,0],[.1,.1,0]], [[-.1,-.1,0],[.1,.1,0],[-.1,.1,0]]])
np.testing.assert_allclose(support_height([0,0],plane)['center'][2],.02,atol=1e-12,rtol=0)
ridge=np.array([[[-.1,0,0],[.1,0,0],[0,.1,-.01]], [[-.1,0,0],[0,-.1,-.01],[.1,0,0]]])
for y in [-.00025,.00025]:
    z=support_height([0,y],ridge)['center'][2]
    np.testing.assert_allclose(z,np.sqrt(.02**2-y*y),atol=1e-12,rtol=0)

mesh=np.load(ROOT/next(iter(INPUTS)),allow_pickle=False)
vertices=mesh['vertices'].copy(); faces=mesh['faces'].copy()
poses=json.loads((ROOT/list(INPUTS)[1]).read_text());home=next(p for p in poses if p['pose']=='home')
R=np.array(home['rotation']); origin=np.array(home['origin']); n=R[:,2]
material=(vertices-origin)@R
top=np.flatnonzero(abs(material[:,2]-material[:,2].max())<1e-12)
assert len(top)==2
top=top[np.argsort(material[top,0])]
ends=material[top]; incident=np.flatnonzero(np.isin(faces,top).sum(1)==2)
assert len(incident)==2 and ends[0,0]<0<ends[1,0]
edge=ends[1]-ends[0]; on_edge=ends[0]+np.clip(-(ends[0]@edge)/(edge@edge),0,1)*edge
assert np.linalg.norm(on_edge)<1e-12
facet_normals=[]
for face in incident:
    a,b,c=material[faces[face]]; normal=np.cross(b-a,c-a); normal/=np.linalg.norm(normal)
    assert normal[2]>0
    facet_normals.append(normal.tolist())

frames={'actual_HOME':(vertices,origin[:2]+.02*n[:2]), 'hypothetical_tangent_levelled':(material,np.zeros(2))}
rows=[]; baselines={}
for frame,(verts,base_xy) in frames.items():
    triangles=verts[faces];base=support_height(base_xy,triangles);baselines[frame]=base
    for axis in range(2):
        mm=list(range(-20,31 if axis==0 else 21))+[-.5,-.25,.25,.5]
        if frame=='hypothetical_tangent_levelled' and axis==0: mm+=list(ends[:,0]*1000)
        for offset_mm in sorted(set(mm)):
            assert time.monotonic()-start<300,'Geometry wall limit exceeded'
            xy=base_xy.copy();xy[axis]+=offset_mm/1000
            entry=support_height(xy,triangles)
            entry.update(frame=frame,axis='xy'[axis],offset_m=offset_mm/1000,
                         height_change_m=entry['center'][2]-base['center'][2],
                         gravity_potential_change_J=.01*9.81*(entry['center'][2]-base['center'][2]))
            rows.append(entry)
    print(frame,'section samples',sum(r['frame']==frame for r in rows),flush=True)

def get(frame,axis,offset):
    return next(r for r in rows if r['frame']==frame and r['axis']==axis and abs(r['offset_m']-offset)<1e-15)
local={}
for frame in frames:
    vals={}
    for axis in 'xy':
        entries=[]
        for h in [.00025,.0005,.001]:
            plus=get(frame,axis,h);minus=get(frame,axis,-h)
            entries.append({'probe_m':h,'plus_height_change_m':plus['height_change_m'],
                            'minus_height_change_m':minus['height_change_m'],
                            'central_height_slope':(plus['height_change_m']-minus['height_change_m'])/(2*h),
                            'second_height_difference_per_m':(plus['height_change_m']+minus['height_change_m'])/(h*h)})
        vals[axis]=entries
    local[frame]=vals
for x in [-.001,0,.001]:
    assert abs(get('hypothetical_tangent_levelled','x',x)['height_change_m'])<2e-12
for y in [-.00025,.00025]:
    z=get('hypothetical_tangent_levelled','y',y)['center'][2]
    np.testing.assert_allclose(z,np.sqrt(.02**2-y*y),atol=2e-12,rtol=0)

save('sections.json',{'baselines':baselines,'rows':rows})
save('crown-section-review.json',{
    'result':'SAVED_CROWN_SECTIONS_REVIEW_COMPLETE',
    'stage11_status':'MATERIAL_BLOCKED_REVIEW_REQUIRED','stage11_complete':False,
    'hypothesis':'Existing material tangent levelled; no robot joint configuration was executed or selected',
    'inputs':INPUTS,'original_mesh_vertices':len(vertices),'original_mesh_faces':len(faces),
    'ridge':{'vertex_ids':top.tolist(),'material_endpoints_m':ends.tolist(),
             'length_m':float(np.linalg.norm(edge)),'incident_faces':incident.tolist(),
             'incident_normals_material':facet_normals,'reference_distance_to_edge_m':float(np.linalg.norm(on_edge)),
             'max_vertex_height_above_reference_m':float(material[:,2].max()),
             'definition':'Contact set with the global material-Z supporting plane at numerical tolerance 1e-12m; not an admissible task boundary'},
    'sample_count':len(rows),'all_final_roots_checked_against_unpruned_frozen_oracle':True,
    'max_root_distance_error_m':max(abs(r['gap_m']) for r in rows),
    'analytic_checks':{'horizontal_plane':True,'two_synthetic_ridge_offsets':True,
                       'actual_mesh_central_ridge_offsets_match_radius_cap':True,
                       'actual_mesh_longitudinal_height_constant_at_minus1_zero_plus1mm':True},
    'local_sections':local,
    'physical_interpretation':[
        'At saved HOME the existing reference has a nonzero longitudinal gravity-height slope.',
        'In the hypothetical levelled geometry, the reference lies on an original ~29.8mm top mesh edge; there is no local bowl.',
        'Near that point longitudinal height is constant while transverse height decreases on either side. A fixed-head, friction-only point-contact sphere has no geometric restoring potential there.',
        'The local 20mm-radius cap is produced by a finite sphere contacting the faceted mesh edge; do not reinterpret its curvature as measured real-head curvature.',
        'A geometric instability is compatible with active balancing; no controller feasibility, region of attraction, or policy success follows from this analysis.',
        'The saved HOME highest vertex is near the positive-X mesh extent and is not automatically a useful balance target.',
    ],
    'unchanged_blockers':['floor penetration','C3/C4 convergence failures','original 9CPU/13CUDA unrun material cases','formal crown/recovery boundary','full Manager lifecycle','formal observation/reset/reward/acceptance semantics'],
    'selected_new_reference':None,'formal_task_migration':False,'policy_success':None,
    'new_integration_steps':0,'canonical_total_steps':7895,'new_PPO':0,'cloud_hours':0,
    'wall_seconds':time.monotonic()-start,
})
with (OUT/'sections.csv').open('w',newline='') as f:
    fields=['frame','axis','offset_m','height_change_m','gravity_potential_change_J','gap_m','face']
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
    for r in rows:w.writerow({k:r[k] for k in fields})
for rel,expected in INPUTS.items():assert sha(ROOT/rel)==expected
print(json.dumps({'ridge_length_mm':float(np.linalg.norm(edge))*1000,'sample_count':len(rows),
                  'local':local,'new_steps':0,'wall_seconds':time.monotonic()-start},indent=2))
