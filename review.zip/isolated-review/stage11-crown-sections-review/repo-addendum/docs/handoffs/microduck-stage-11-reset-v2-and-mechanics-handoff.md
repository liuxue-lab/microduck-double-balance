# Stage 11 reset v2 and saved-mechanics continuation

2026-10-04. This addendum is prepared in the review workspace, not yet applied to the laptop repository. It supersedes the previous handoff's pending reset-v2 result while retaining all historical failures. No installer, simulation, canonical commit, tag or push is performed by this review package.

Stage11Status=MATERIAL_BLOCKED_REVIEW_REQUIRED; stage incomplete. Canonical known material/diagnostic integration steps=7895; new integration=0; PPO=0; cloud hours=0; full-robot dynamics=0. Engineering progress remains approximately 60% as a qualitative estimate only. No policy success claim.

The user's successful SSH push of `stage11-head-reset-v2-transfer-20261004t080631z` is accepted without a full remote recheck. Pinned artifact commit `e0184a7eaede583d3a0a5845a14e8c12e643655b`; ZIP SHA256 `031344e1e157f8ff462b059c66d87af58865e57cadbd8c07b2be3dd79b15930d`, 606948 bytes. All 73 inventory entries verified. Laptop evidence: `/home/lx/microduck-double-balance/artifacts/double-balance-stage11/head-reset-v2/20261004T080631Z`.

Native RTX5060 v2 completed 12 tests, 9 forwards, 3 reset calls and 6 selected samples across 3 worlds, no integration. All 52 delivered source files and 20 dependency sources match, plus 5 captured actuator-related modules. All 328 device model/option array hashes and 42 CPU physical array hashes are unchanged. Saved-array recomputation confirms selected velocity clearing, native joints/poses, nonselected qpos/qvel/ctrl/time/wrench isolation and anchor preservation. Material coordinate residual <=5.7946937470632065e-8 m; feature recomputation error <=1.8215321198056245e-6. These numerical checks are not physical or acceptance thresholds.

Native exact-mesh clearance report is 0.49997294–0.49997575 mm. Per-world geom transforms and complete mesh are absent from this return, so this review does not claim independent mesh-distance recomputation. Complete nonselected material velocity derivative cannot be reconstructed independently from this archive because site linear velocity was not saved. Three raw contact arrays are empty, so this adds no contact-force validation. Full Manager/startup/BAM/action/auto-reset/episode lifecycle remains untested. Source-frozen guards remain.

Correction to prior handoff: `BallHoldAction.__init__` sets hold to `cfg.levels[0]`; `BallHoldAction.reset` is a no-op. The direct IO harness retained hold=[1,1,1] and applied zero wrench because actions were not executed. Never silently clear bookkeeping or call this an unassisted-policy success. Preserve v1 setup failure `Unexpected renderer/raycast context`; v2 correctly permits the inherited raycast-only foot_height_scan resource and no cameras, without changing sensors or physics.

See `docs/audits/stage-11-head-reset-v2-return-review.json` and `docs/audits/stage-11-head-support-wrench-review.json`.

Saved mechanics review consumed 1684 existing pre-integration records and all 1150 head contacts. Each such record has one head contact, condim4, effective friction [.6,.6,.005,.0001,.0001] and exactly zero local rolling couples. Saved sphere mass=.010 kg, radius=.020 m, isotropic inertia=1.6e-6 kg m². Seven previously inspected normals are tilted; HOME tilt=4.39088837416914 degrees. Under the stated ideal stationary single-contact/gravity-only assumption, translational balance leaves a tangent torque of 0.0001502116381786443 Nm at HOME which a normal torsional couple cannot cancel. No-slip rolling is distinct from rest. Positive normal force, small slip or a friction-cone check alone is not a stability criterion. This does not rule out another free head configuration or dynamic control, and does not identify all endpoint causes.

The optional ideal local-plane acceleration illustration (~.536470136 m/s² at HOME) is algebra, not a soft-contact rollout or material measurement. Pyramidal cone semantics are kept separate from Euclidean force ratios. No hidden plane, rolling-friction activation, friction increase, joint lock or target change. A dimensionally ill-conditioned development linear solve had a 1.536965e-15 algebra comparison discrepancy; equations were rescaled and the original comparison tolerance retained. This was not a physical check or threshold relaxation.

Remaining blockers: original floor penetration; C3/C4 position .203633604 mm > .2 mm and velocity .21102286 m/s > .05 m/s despite the other two checks passing; six censored friction cases; original 9 CPU/13 CUDA material cases not run; true crown/recovery region; formal reference/observation/reward/acceptance migration; complete native Manager lifecycle. Do not automatically run C5, old material cases, previous installers or additional same-purpose static checks. Next physics work requires a concrete independently bounded candidate and a discriminating question; formal physics/task changes and training remain outside current authorization. No completion tag or stage-end code commit yet.

Keep strict 10 s episodes, terminal continuous stable >=5 s, no assistance, lower-ball speed <=.15 m/s and the exact prior timing boundaries. Static checks, CI and fixed-head material do not prove strategy success. Head correction remains paused; adjustment turns are allowed, with no always-forward penalty. 61 actor dimensions do not establish old checkpoint or normalization semantic compatibility.

Standing protocols: `docs/handoffs/microduck-local-ssh-push-protocol.md` and `docs/handoffs/microduck-cloud-gpu-and-transfer-protocol.md`. Canonical repository `/home/lx/microduck-double-balance/workspace`, downloads `/home/lx/下载`; code branch double-balance HEAD reported unchanged at `056eaf2b0c78261f34e3fa581858c8573cab981e`; SSH origin `git@github.com:liuxue-lab/microduck-double-balance.git`. Stage10 annotated tag target `1a11f30cc7264d00dec7bce8f11449ded9164169` is immutable. Code and model/raw archive branches remain separate; never merge transfer branches. Unknown local changes stop without force/reset/overwrite.

Main checkpoint Stage08 E/20260929/update_004000.pt SHA256 `86d55c3703c18fcf4817db49c6e4dcf839b3f5195d68ae2c559db7e222bded97`; historical independent 652/768=84.90%, no diagnostic additions. Preserve Stage10 B1/C1 post-hoc evidence gaps and the distinction between floating-point accumulation mechanism evidence and a fully proved causal chain. No Stage10 cleanup or old CI rerun.

RTX5060 is for local code, MuJoCo simulation/inference and video. RTX5090 remains OFF_CONFIRMED_BY_USER; no new cloud operation, reminder or confirmation. Never start/stop an instance, revive the failed shutdown daemon, rerun Stage06 smoke or delete incompletely returned Stage09 cloud raw trajectories. After future approved cloud compute and required SHA256-verified returns, immediately remind the user to shut down manually; record reminder and actual confirmation separately. Any training still needs explicit checkpoint/normalizer/Adam/LR/iteration/common_step_counter/curriculum/assistance restoration rules, groups/seeds/new-PPO/evaluation/cloud-hours/cost budgets and stopping conditions.

Current next operation: none required on laptop for this review. Carry these three new documentation files into the next normal code addendum. Do not rerun reset-v2 to generate another archive. The following is a read-only convenience command if local state later needs inspection, not a required remote verification:

```bash
git -C /home/lx/microduck-double-balance/workspace status --short
```

For a future explicitly prepared archive, the established user-only push shape remains:

```bash
git -C /home/lx/microduck-double-balance/artifacts/double-balance-stage11/transfer/<UTC> push origin HEAD:refs/heads/<printed-stage11-transfer-branch>
```

Placeholders above are documentation, not a current executable push request. A normal success result is sufficient; do not repeat full remote verification. Shell prompts and wrapped/truncated command prefixes are not part of commands. The repeated renderer-context setup error is already resolved; preserve evidence and inspect new errors instead of launching old scripts.
