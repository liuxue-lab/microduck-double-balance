from pathlib import Path
import importlib.util,json,time,numpy as np,mujoco,warp as wp,mujoco_warp as mw
from mujoco_warp._src import forward as fw
sp=importlib.util.spec_from_file_location('runtime_check','stage11-build/scripts/diagnose_head_contact_candidate_runtime.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
out=Path('stage11-runtime-isolated-check');out.mkdir(exist_ok=False)
p=Path('stage11-local-cuda-candidate-review-20261004T120651Z/archive/diagnostic')
model=mujoco.MjModel.from_binary_path(str(p/'material-fixture.mjb'));m.contract(model)
with np.load(p/'material-geometry.npz') as z:triangles=z['vertices'][z['faces']]
states=m.normal.selected_states(Path('stage11-local-cuda-friction-review-20261004T104109Z/archive'))
runtime,kernel=m.runtime_modules();report={'forward_controls':[],'forward_query_attempts':0,'forward_queries_completed':0}
with wp.ScopedDevice('cpu'),m.normal.forbid_integration(mw,fw):
 wm=mw.put_model(model);wm.opt.ls_parallel=True;before=m.normal.model_fingerprint(wm)
 m.saved_forward_controls(model,wm,triangles,states,out,report,time.monotonic()+300,wp,mw,runtime,kernel)
 assert before==m.normal.model_fingerprint(wm)
report.update(scope='Isolated WarpCPU forward only; not canonical CUDA dynamics',integration_steps=0,new_PPO=0,model_unchanged=True)
m.save(out/'review.json',report)
print(json.dumps({'forward_queries':report['forward_queries_completed'],'integration_steps':0,'controls':[{'name':r['name'],'passthrough_exact':r['passthrough_exact'],'candidate_status':r['candidate_geometry_status']} for r in report['forward_controls']]},indent=2))
