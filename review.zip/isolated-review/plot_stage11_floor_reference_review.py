from pathlib import Path
import json,gzip
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
r=Path('stage11-local-floor-reference-review-20261004T092507Z');a=r/'archive/diagnostic'
report=json.loads((r/'local-floor-reference-review.json').read_text())
fig,ax=plt.subplots(2,2,figsize=(12,7.3),layout='constrained')
for name,dt,path,color in [('C4',.0000625,Path('stage11-local-refinement-review-20261003T173938Z/archive/diagnostic/cases/C4'),'#8b8c89'),('C5',.00003125,a/'cases/C5','#1769aa'),('C6',.000015625,a/'cases/C6','#d85a24')]:
 with np.load(path/'states.npz') as z:q,v=z['qpos'],z['qvel']
 t=.39+np.arange(len(q))*dt
 rows=[json.loads(l) for l in gzip.open(path/'contacts.jsonl.gz','rt')]
 force=np.array([sum(c['normal_force_N'] for c in x['contacts']) for x in rows])
 label=f'{name}: {dt*1e6:g} µs'
 ax[0,0].plot(t,(q[:,2]-.02)*1000,label=label,color=color,lw=1.3)
 ax[0,1].plot(t,v[:,2],label=label,color=color,lw=1.3)
 ax[1,0].plot(t[:-1],force,label=label,color=color,lw=1.3)
 ax[1,1].plot(t,v[:,2],label=label,color=color,lw=1.3)
for panel in ax.flat:panel.grid(alpha=.2);panel.set_xlabel('Nominal physical time (s)')
ax[0,0].set(title='Sphere bottom gap over the full saved 50 ms',ylabel='Floor gap (mm)',xlim=(.39,.44));ax[0,0].axhline(0,color='black',lw=.6);ax[0,0].legend(frameon=False,fontsize=9)
ax[0,1].set(title='Vertical velocity: first impact and rebound',ylabel='Vertical velocity (m/s)',xlim=(.39,.398))
ax[1,0].set(title='Recorded normal force at first impact',ylabel='Normal force (N)',xlim=(.3903,.3948))
ax[1,1].set(title='Second impact: C5 arrives about 1.234 ms earlier',ylabel='Vertical velocity (m/s)',xlim=(.433,.437),ylim=(-.22,.045))
fig.suptitle('Stage 11 C5/C6: complete traces, unchanged thresholds, sensitivity still blocked',fontsize=13)
fig.savefig(r/'floor-reference-comparison.png',dpi=160);fig.savefig(r/'floor-reference-comparison.pdf')
plt.close(fig)
