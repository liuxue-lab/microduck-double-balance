"""Review returned, saved native reset arrays; never constructs or steps an engine."""
from pathlib import Path
import hashlib
import json
import numpy as np

ROOT = Path(__file__).resolve().parent
R = ROOT / 'stage11-local-reset-v2-review-20261004T080631Z'
A = R / 'archive'
D = A / 'reset'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())

m = read(A / 'package-manifest.json')
assert m == read(ROOT / 'stage11-reset-v2-package-manifest.json')
assert sha(A / 'microduck-stage11-head-reset-v2.bundle') == m['bundle_sha256']
for name, meta in m['files'].items():
    assert sha(ROOT / 'stage11-build' / name) == meta['sha256'], name
dependencies = 0
for filename, prefix in [('dependency-sources.json', ''),
                         ('additional-dependency-sources.json', ''),
                         ('reset-dependency-sources.json', 'mjlab/')]:
    for name, meta in read(D / filename).items():
        assert meta['matches']
        assert meta['sha256'] == meta['reviewed_sha256'] == sha(D / 'installed-source' / (prefix + name))
        dependencies += 1
for name, meta in read(D / 'actuator-sources.json').items():
    source = D / 'actuator-source' / Path(*name.split('.')).with_suffix('.py')
    assert sha(source) == meta['sha256'] and source.stat().st_size == meta['bytes']
device_before = read(D / 'device-model-signatures-before.json')
assert device_before == read(D / 'device-model-signatures-after.json')
physical = read(D / 'physical-array-signatures.json')
assert physical == read(ROOT / 'stage11-local-tensor-review-20261004T071751Z/archive/tensor/physical-array-signatures.json')

idx = read(D / 'native-indexing.json')
origins = np.array(idx['origins'])
qadr = np.array(idx['robot_joint_qadr'])
defaults = np.array(idx['default_joint_pos'])
ids = read(D / 'compiled-identities.json')
cases = read(D / 'reset-cases.json')
reports = []
previous_anchor = None
worst_pose = worst_position = worst_feature = 0.
for rev, selected in enumerate(([0, 1, 2], [2], [1, 0])):
    s = np.load(D / f'state-reset-{rev}.npz', allow_pickle=False)
    t = np.load(D / f'tensor-reset-{rev}.npz', allow_pickle=False)
    c = read(D / f'contacts-reset-{rev}.json')
    other = np.setdiff1d(np.arange(3), selected)
    assert cases[rev]['selected'] == selected
    for key in ('qpos', 'qvel', 'ctrl', 'time', 'xfrc_applied'):
        np.testing.assert_array_equal(s['before_' + key][other], s['after_' + key][other])
    for key in ('ctrl', 'time', 'xfrc_applied'):
        np.testing.assert_array_equal(s['before_' + key], s['after_' + key])
    assert np.isfinite(s['after_qpos']).all() and np.isfinite(s['after_qvel']).all()
    assert np.all(s['before_qvel'] != 0) and not np.any(s['after_qvel'][selected])
    assert not np.any(s['after_time']) and not np.any(s['after_xfrc_applied'])
    np.testing.assert_array_equal(s['after_qpos'][selected][:, qadr], defaults[selected])
    expected = {
        'robot': origins[selected] + [0., 0., .368],
        'ball': origins[selected] + [0., 0., .121],
        'top_ball': s['reference_site'][selected].astype(float) + .0205 * s['reference_rotation'][selected, :, 2],
    }
    errors = []
    for name, value in expected.items():
        error = float(np.max(np.abs(s['after_' + name + '_position'][selected] - value)))
        errors.append(error)
        np.testing.assert_allclose(s['after_' + name + '_position'][selected], value, atol=2e-5, rtol=0)
        np.testing.assert_array_equal(s['after_' + name + '_quaternion'][selected], np.tile([1., 0, 0, 0], (len(selected), 1)))
    worst_pose = max(worst_pose, *errors)
    np.testing.assert_allclose(s['anchor'][selected], expected['ball'], atol=2e-5, rtol=0)
    if previous_anchor is not None:
        np.testing.assert_array_equal(s['anchor'][other], previous_anchor[other])
    previous_anchor = s['anchor'].copy()
    np.testing.assert_array_equal(t['ball_position'], s['after_top_ball_position'])
    np.testing.assert_array_equal(t['origin'], s['reference_site'])
    np.testing.assert_array_equal(t['rotation'], s['reference_rotation'])
    position = np.einsum('nji,nj->ni', s['reference_rotation'].astype(float),
                         s['after_top_ball_position'].astype(float) - s['reference_site'].astype(float))
    pos_error = float(np.max(np.abs(position - t['position_material'])))
    worst_position = max(worst_position, pos_error)
    np.testing.assert_allclose(position, t['position_material'], atol=2e-6, rtol=0)
    for key in ('rate_material', 'ball_velocity', 'ball_omega', 'head_omega'):
        np.testing.assert_array_equal(t[key][selected], np.zeros((len(selected), 3)))
    assert t['valid_environment'].all() and t['contact_capacity_ok'] and t['invalid_world_contacts'] == 0
    assert not t['data_time'].any()
    # This return has no contacts, including in the artificial nonselected states.
    assert len(c['worldid']) == 0
    for key in ('head_mask', 'floor_mask', 'head_active_mask', 'floor_active_mask',
                'head_count', 'floor_count', 'head_active_count', 'floor_active_count',
                'head_force_on_ball', 'floor_force_on_ball'):
        assert not np.any(t[key]), key
    p = position.copy(); p[:, 2] -= .02
    feature = np.concatenate((p * [20., 25., 50.], t['rate_material'].astype(float) * 2.), axis=-1)
    spin = np.einsum('nji,nj->ni', t['rotation'].astype(float),
                     t['ball_omega'].astype(float) - t['head_omega'].astype(float))
    feature_errors = []
    for name, value in [('actor', feature), ('critic', np.concatenate((feature, spin * .2), axis=-1))]:
        actual = np.load(D / f'{name}-features-{rev}.npy', allow_pickle=False)
        err = float(np.max(np.abs(actual - value))); feature_errors.append(err)
        assert np.isfinite(actual).all()
        np.testing.assert_allclose(actual, value, atol=2e-5, rtol=0)
    worst_feature = max(worst_feature, *feature_errors)
    assert cases[rev]['basketball_hold_bookkeeping'] == [1., 1., 1.]
    assert not cases[rev]['assistance_applied'] and not cases[rev]['full_manager_execution']
    reports.append({'revision': rev, 'selected': selected, 'nonselected': other.tolist(),
                    'selected_velocity_zero': True, 'nonselected_primary_state_exact': True,
                    'max_pose_residual_m': max(errors), 'max_position_recomputation_error_m': pos_error,
                    'max_feature_error': max(feature_errors), 'raw_contacts': len(c['worldid'])})

run = read(A / 'run-summary.json'); review = read(D / 'reset-review.json')
assert run['physics_integration_steps'] == run['physics_attempted_steps'] == run['new_ppo_updates'] == run['cloud_hours'] == 0
assert run['canonical_total_known_completed_steps'] == 7895
assert run['execution_invariants_unchanged'] and run['installed_source_files_unchanged'] and run['previous_stage11_mdp_unchanged']
assert run['head_after'] == m['baseline'] and not run['staged_changes']
assert run['reset_exit_code'] == 0 and review['status'] == 'NATIVE_RESET_IO_REVIEW_REQUIRED'
progress = read(D / 'execution-progress.json')
assert progress == {'phase': 'all_reset_IO_checks_completed', 'forward_calls': 9, 'reset_calls': 3, 'new_integration_steps': 0}
result = {
    'result': 'NATIVE_RESET_V2_SAVED_RETURN_RECONCILED',
    'branch': 'stage11-head-reset-v2-transfer-20261004t080631z',
    'commit': 'e0184a7eaede583d3a0a5845a14e8c12e643655b',
    'archive_sha256': '031344e1e157f8ff462b059c66d87af58865e57cadbd8c07b2be3dd79b15930d',
    'archive_inventory_verified': 73, 'manifest_files_verified': len(m['files']),
    'dependency_sources_verified': dependencies, 'actuator_source_modules_verified': 5,
    'unchanged_device_array_hashes': len(device_before), 'unchanged_cpu_physical_array_hashes': len(physical),
    'device': run['native_reset_scope']['device'], 'execution_progress': progress,
    'tests': {'passed': 12, 'reported_seconds': .036},
    'batches': reports, 'max_pose_residual_m': worst_pose,
    'max_material_position_independent_error_m': worst_position,
    'max_feature_recomputation_error': worst_feature,
    'geometry_clearance': {'native_report_range_m': [.000499972939762526, .0004999757523053358],
                           'basis': 'Preserved native exact-mesh-distance result. Mesh and per-world geom transforms are not saved in reset-v2; no independent mesh-distance rerun is claimed.'},
    'derivative_limit': 'Selected zero-rate states verified directly. Nonselected rates reused from saved tensor output for feature checks; head site velocity is absent from this archive, so complete nonselected kinematic derivative is not independently reconstructed.',
    'full_manager_execution': False,
    'hold_bookkeeping': [1., 1., 1.],
    'hold_source_clarification': 'BallHoldAction.__init__ sets hold to cfg.levels[0]; BallHoldAction.reset is a no-op. Action manager was not constructed in this audit. Zero applied wrench is not a complete unassisted-policy proof.',
    'no_new_contact_force_validation': True,
    'new_integration_steps': 0, 'canonical_total_steps': 7895, 'new_PPO': 0, 'cloud_hours': 0,
    'stage11_status': 'MATERIAL_BLOCKED_REVIEW_REQUIRED', 'stage11_complete': False,
    'formal_task_migration': False, 'policy_success': None, 'v1_failure_preserved': True,
}
(R / 'local-reset-v2-review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
