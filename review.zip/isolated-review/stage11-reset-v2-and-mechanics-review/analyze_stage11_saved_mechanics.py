"""Saved Stage11 evidence only: read a compiled model and arrays; no forward/step.

Run in the review workspace with PYTHONPATH=stage11-deps. This is not a task,
acceptance gate, material calibration, or policy evaluation.
"""
from pathlib import Path
import collections
import csv
import gzip
import hashlib
import json
import numpy as np
import mujoco

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'stage11-reset-v2-and-mechanics-review'
OUT.mkdir(exist_ok=True)
FR = ROOT / 'stage11-local-friction-review-20261003T183812Z/archive/diagnostic'
PR = ROOT / 'stage11-local-prototype-review-20261003T205659Z/archive/prototype'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
inputs = {}
def record(p):
    inputs[str(p.relative_to(ROOT))] = {'sha256': sha(p), 'bytes': p.stat().st_size}
    return p

model_path = record(FR / 'material-fixture.mjb')
assert sha(model_path) == 'e6cd330bddc3a29abf9ce4eca4f308a2680e4910405725e5ce054cb0a19d2da0'
# Deserializes existing immutable model only; no MjData, forward or integration.
m = mujoco.MjModel.from_binary_path(str(model_path))
sphere = m.geom('sphere').id
body = int(m.geom_bodyid[sphere])
mass = float(m.body_mass[body]); radius = float(m.geom_size[sphere, 0])
inertia = np.array(m.body_inertia[body]); gravity = np.array(m.opt.gravity)
assert mass == .01 and radius == .02 and m.geom_condim[sphere] == 4
assert int(m.geom_priority[sphere]) == 1 and int(m.geom_priority[m.geom('head').id]) == 0
assert int(m.opt.cone) == 0  # Saved model uses the pyramidal contact cone.
np.testing.assert_allclose(inertia, np.full(3, .4 * mass * radius**2), atol=1e-20, rtol=0)
assert not np.any(m.body_ipos[body]) and not np.any(m.dof_damping) and not np.any(m.dof_frictionloss)
assert not np.any(m.body_gravcomp) and m.nu == 0 and m.neq == 0

case_stats = []; total_rows = total_contacts = 0
for case in sorted((FR / 'cases').iterdir()):
    if not case.is_dir():
        continue
    path = record(case / 'raw-contacts.jsonl.gz')
    histogram = collections.Counter(); rows = contacts = positive = 0
    max_rolling_torque = 0.
    with gzip.open(path, 'rt') as stream:
        for line in stream:
            row = json.loads(line)
            assert row['phase'] == 'pre_integration_contacts_and_solver_force'
            assert row['step'] == rows
            rows += 1
            head = [c for c in row['contacts'] if set(c['geom']) == {1, 2}]
            histogram[len(head)] += 1
            assert len(head) <= 1
            for c in head:
                contacts += 1
                assert c['dim'] == 4
                np.testing.assert_array_equal(c['friction'], [.6, .6, .005, .0001, .0001])
                positive += int(c['dist'] <= 0 and c['efc_address'] >= 0 and c['force'][0] > 0)
                max_rolling_torque = max(max_rolling_torque, abs(c['force'][4]), abs(c['force'][5]))
                assert c['force'][4] == c['force'][5] == 0
    total_rows += rows; total_contacts += contacts
    case_stats.append({'case': case.name, 'saved_pre_step_records': rows,
                       'head_contact_count_histogram': dict(histogram), 'head_contacts': contacts,
                       'positive_normal_head_contacts': positive,
                       'max_local_rolling_couple_Nm': max_rolling_torque})
assert total_rows == 1684 and total_contacts == 1150

def cross_matrix(v):
    x, y, z = v
    return np.array([[0., -z, y], [z, 0., -x], [-y, x, 0.]])

pose_path = record(PR / 'prototype-static-configurations.json')
poses = json.loads(pose_path.read_text()); rows = []; max_linear_residual = 0.
for pose in poses:
    n = np.array(pose['geometry']['expected_normal'], dtype=float)
    np.testing.assert_allclose(n @ n, 1., atol=3e-14, rtol=0)
    n /= np.linalg.norm(n)
    R = np.array(pose['rotation'])
    np.testing.assert_allclose(n, R[:, 2], atol=2e-14, rtol=0)
    gmag = float(np.linalg.norm(gravity)); up = -gravity / gmag
    cosine = float(n @ up); sine = float(np.linalg.norm(np.cross(n, up)))
    assert cosine > 0
    angle = float(np.degrees(np.arctan2(sine, cosine)))
    # Hypothetical closed contact at the saved witness, not the .5mm clear spawn.
    arm = -radius * n
    static_force = -mass * gravity
    static_torque = np.cross(arm, static_force)
    # Allowed condim4 pure couple lies along n and cannot cancel tangent torque.
    best_normal_couple = -float(static_torque @ n) * n
    uncancelled = static_torque + best_normal_couple
    np.testing.assert_allclose(np.linalg.norm(uncancelled), mass*gmag*radius*sine, atol=1e-17, rtol=0)
    assert abs(static_torque @ n) < 1e-18

    # Independent Newton/Euler + zero contact acceleration linear system for an
    # ideal rigid sphere on a stationary local plane at rest (omega=0).
    # Scale unknowns as [a, radius*alpha, force/mass] to avoid mixing entries
    # of order 1 and 1.6e-6 in the verification matrix.
    z = np.zeros((3, 3)); eye = np.eye(3)
    unit_arm = arm/radius
    mat = np.block([[eye, z, -eye],
                    [z, np.diag(inertia)/(mass*radius**2), -cross_matrix(unit_arm)],
                    [eye, -cross_matrix(unit_arm), z]])
    rhs = np.concatenate((gravity, np.zeros(6)))
    solution = np.linalg.solve(mat, rhs)
    acc, alpha, force = solution[:3], solution[3:6]/radius, solution[6:]*mass
    residual = float(np.max(np.abs(mat @ solution - rhs)))
    max_linear_residual = max(max_linear_residual, residual)
    tangent_gravity = gravity - (gravity @ n)*n
    analytical = tangent_gravity / (1 + inertia[0]/(mass*radius**2))
    np.testing.assert_allclose(acc, analytical, atol=1e-13, rtol=0)
    force_n = float(force @ n); force_t = force - force_n*n
    mu_norm = float(np.linalg.norm(force_t)/force_n)
    np.testing.assert_allclose(mu_norm, 2/7*sine/cosine, atol=1e-15, rtol=0)
    # sqrt(2)*norm ratio is a conservative bound for either tangent-frame
    # orientation of the saved pyramidal cone, with zero torsional torque.
    mu_pyramid_bound = np.sqrt(2)*mu_norm
    assert mu_pyramid_bound < float(m.geom_friction[sphere, 0])
    rows.append({'pose': pose['pose'], 'world_normal': n.tolist(), 'normal_tilt_deg': angle,
                 'hypothetical_static_required_force_N': static_force.tolist(),
                 'uncancellable_tangent_torque_Nm': uncancelled.tolist(),
                 'uncancellable_torque_norm_Nm': float(np.linalg.norm(uncancelled)),
                 'ideal_local_plane_initial_acceleration_m_s2': acc.tolist(),
                 'ideal_acceleration_norm_m_s2': float(np.linalg.norm(acc)),
                 'ideal_no_slip_friction_norm_ratio': mu_norm,
                 'ideal_pyramidal_any_tangent_orientation_sufficient_mu': float(mu_pyramid_bound),
                 'native_saved_spawn_clearance_m': pose['geometry']['original_sphere_gap_m']})
assert len(rows) == 7
for yaw in rows[1:3]:
    np.testing.assert_allclose(yaw['normal_tilt_deg'], rows[0]['normal_tilt_deg'], atol=1e-11, rtol=0)

report = {
    'result': 'SAVED_SINGLE_CONTACT_WRENCH_REVIEW_COMPLETE',
    'stage11_status': 'MATERIAL_BLOCKED_REVIEW_REQUIRED', 'stage11_complete': False,
    'analysis_kind': 'Deserialization and algebra on already returned evidence; no model compile, MjData, forward, reset, step or rollout',
    'inputs': inputs,
    'archived_source_zips': {
        'friction': 'f692ff89cfdd0b1036570a2eb5cc4a7f679eb49bc407af37e5e3410478dd343d',
        'prototype': 'c22ab08e67979c33f397ee099e68d816eb2877663d4d3cae2419176dfa017e4d'},
    'model': {'mass_kg': mass, 'radius_m': radius, 'principal_inertia_kg_m2': inertia.tolist(),
              'gravity_m_s2': gravity.tolist(), 'condim': 4, 'cone': 'pyramidal',
              'effective_contact_friction': [.6, .6, .005, .0001, .0001],
              'sliding_mu': .6, 'torsional_length_m': .005,
              'stored_rolling_length_m': .0001, 'rolling_components_active': False,
              'damping_gravcomp_actuators_equalities': 'absent/zero in saved free-ball material fixture'},
    'raw_contact_cases': case_stats,
    'raw_contact_totals': {'saved_pre_step_records': total_rows, 'single_head_contacts': total_contacts,
                           'all_condim4': True, 'all_local_rolling_couples_exact_zero': True},
    'poses': rows,
    'independent_checks': {'Newton_Euler_and_no_slip_linear_system_max_residual': max_linear_residual,
                            'closed_form_vs_linear_solve': 'all seven configurations passed',
                            'yaw_rotations_preserve_tilt': True},
    'development_note': 'First dimensional linear solve exceeded its 1e-15 algebra-only friction-ratio comparison by 1.536965e-15. Unknowns/equations were nondimensionalized to remove mass/inertia conditioning; comparison tolerance retained. No model, physics threshold or evidence was changed.',
    'conclusions': [
        'The saved .5mm clear reset is a geometric spawn, not an equilibrium or contact-support test.',
        'For a stationary sphere with one contact and gravity only, force balance fixes F=-mg. On a tilted normal, (-R*n) cross F is a nonzero tangent torque. A condim4 normal torsional couple cannot cancel it.',
        'Non-slip rolling remains possible. Friction cone membership, small point slip or positive normal force alone cannot establish stationary balance.',
        'Normal verticality is a necessary condition for this ideal single-contact static equilibrium, not a sufficient stability or control-feasibility condition.',
        'All seven inspected material-point configurations are tilted; this does not rule out another freely articulated head configuration or dynamic balancing.',
        'Increasing sliding friction does not supply a missing rolling couple. No friction, condim, damping, head joint or target is changed.',
    ],
    'limits': [
        'Ideal local rigid-plane acceleration assumes rest, a closed single contact, fixed head, isotropic sphere and adequate sticking friction; it is not a MuJoCo trajectory forecast, soft-contact calibration or real-material measurement.',
        'Saved model uses a pyramidal cone. Reported Euclidean force ratios are not substituted for the actual pyramid constraint; a separate conservative tangent-basis bound is reported only for the ideal illustration.',
        'Do not use this analysis to excuse floor penetration/convergence failures, declare a crown/recovery region, or identify a sole cause of all six endpoints.',
        'No new contact samples or full-robot/policy dynamics; no success-rate contribution or acceptance release.',
    ],
    'official_contact_semantics': {
        'url': 'https://mujoco.readthedocs.io/en/3.3.7/computation/index.html#contact',
        'use': 'Published condim4/6 semantics only; actual returned model/source/raw forces determine this review.',
        'version_note': '3.10.0 documentation URL unavailable to retrieval; no claim of a 3.10.0 documentation review.',
        'native_source': 'reset-v2 installed-source/mujoco_warp/_src/support.py::_decode_pyramid/contact_force_fn confirms only force components 0..3 for condim4'},
    'new_forward_calls': 0, 'new_reset_calls': 0, 'new_integration_steps': 0,
    'canonical_total_steps': 7895, 'new_PPO': 0, 'cloud_hours': 0,
    'formal_task_migration': False, 'policy_success': None,
}
(OUT / 'support-wrench-review.json').write_text(json.dumps(report, indent=2) + '\n')
with (OUT / 'pose-summary.csv').open('w', newline='') as f:
    keys = ['pose', 'normal_tilt_deg', 'uncancellable_torque_norm_Nm',
            'ideal_acceleration_norm_m_s2', 'ideal_no_slip_friction_norm_ratio']
    w = csv.DictWriter(f, fieldnames=keys); w.writeheader()
    for row in rows:
        w.writerow({k: row[k] for k in keys})
print(json.dumps({'result': report['result'], 'raw_records': total_rows, 'contacts': total_contacts,
                  'home': rows[0], 'checks': report['independent_checks'], 'new_steps': 0}, indent=2))
