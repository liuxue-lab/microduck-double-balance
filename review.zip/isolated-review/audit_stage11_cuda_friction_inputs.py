from pathlib import Path
import json,hashlib,importlib.util
from unittest.mock import patch
import mujoco,numpy as np
root=Path('stage11-local-friction-review-20261003T183812Z/archive/diagnostic');latest=Path('stage11-local-cuda-center-v2-review-20261004T101459Z/archive/diagnostic')
sp=importlib.util.spec_from_file_location('inputaudit','stage11-build/scripts/diagnose_head_contact_cuda_friction.py');d=importlib.util.module_from_spec(sp);sp.loader.exec_module(d)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(root/'material-fixture.mjb')==sha(latest/'material-fixture.mjb')=='e6cd330bddc3a29abf9ce4eca4f308a2680e4910405725e5ce054cb0a19d2da0'
assert sha(root/'material-geometry.npz')==sha(latest/'material-geometry.npz')
with np.load(root/'material-geometry.npz') as z:triangles=z['vertices'][z['faces']];xy=z['center_xy']
center=json.loads((latest/'archived-CPU-center/initial.json').read_text());cases=d.fr.selected_cases(triangles,xy,center)
model=mujoco.MjModel.from_binary_path(str(root/'material-fixture.mjb'));sig=d.floor.model_signature(model);rows=[]
with patch.object(mujoco,'mj_step',side_effect=AssertionError('No integration')):
 for case in cases:
  p=root/'cases'/case['name'];old=json.loads((p/'initial.json').read_text());summary=json.loads((p/'summary.json').read_text())
  for key in ('center','witness','normal','velocity','omega'):np.testing.assert_array_equal(case[key],old[key])
  data=d.v2.set_ball(model,case['center'],case['velocity'],case['omega'])
  for key in ('qpos','qvel','qacc_warmstart'):np.testing.assert_array_equal(getattr(data,key),old[key])
  assert data.time==0 and all(c.dist>=-1e-8 for c in data.contact)
  rows.append({'name':case['name'],'historical_CPU_steps':summary['steps'],'historical_CPU_status':summary['status'],'initial_state_and_warmstart_exact':True,'initial_ball_surface_gap_m':float(d.v2.nearest_surface(data.qpos[:3],triangles)[1]-.02)})
assert d.floor.model_signature(model)==sig
r={'status':'SIX_ORIGINAL_CASES_MATCH_ARCHIVED_CPU_INITIALIZATION','cases':rows,'same_original_MJB_and_triangles_as_latest_CUDA_center':True,'model_arrays_options_unchanged':True,'new_integration_steps':0,'static_forward_calls':6,'PPO':0,'CUDA_execution_here':False,'CPU_history_replayed':False}
Path('stage11-cuda-friction-static-input-review.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
