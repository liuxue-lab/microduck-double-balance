"""Independent saved-state review of C4/C5/C6, without importing a simulator."""
from pathlib import Path
import gzip,hashlib,json
import numpy as np
ROOT=Path(__file__).resolve().parent
R=ROOT/'stage11-local-floor-reference-review-20261004T092507Z';A=R/'archive';D=A/'diagnostic'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
run=read(A/'run-summary.json');report=read(D/'diagnostic-review.json');manifest=read(A/'package-manifest.json')
assert manifest==read(ROOT/'stage11-floor-reference-package-manifest.json')
assert sha(A/'microduck-stage11-floor-reference.bundle')==manifest['bundle_sha256']
assert read(D/'source-snapshot.json')==manifest['files']
for n,m in manifest['files'].items():assert sha(ROOT/'stage11-build'/n)==m['sha256'],n
assert report['diagnostic_source_sha256']==manifest['files']['scripts/diagnose_head_contact_floor_reference.py']['sha256']
assert run['head']==run['head_after']=='056eaf2b0c78261f34e3fa581858c8573cab981e'
assert run['old_stage10_tag']==run['stage10_tag_after']=='1a11f30cc7264d00dec7bce8f11449ded9164169'
assert run['execution_invariants_unchanged'] and run['installed_source_files_unchanged']
assert run['baseline_tracked_changes']=='M\tsrc/mjlab_microduck/tasks/mdp.py' and not run['staged_changes']
assert run['previous_stage11_mdp_unchanged'] and not run['stage11_complete'] and not run['formal_task_migration']
assert run['new_ppo_updates']==report['new_ppo_updates']==run['cloud_hours']==report['full_robot_steps']==0
assert run['physics_integration_steps']==run['physics_attempted_steps']==report['diagnostic_completed_steps']==report['diagnostic_attempted_steps']==4800
assert run['step_count_exact'] and run['canonical_total_known_completed_steps']==run['canonical_total_attempted_upper_bound']==12695
assert report['wall_seconds']<300 and report['status']=='FLOOR_REFERENCE_SENSITIVITY_BLOCKED_REVIEW_REQUIRED'
assert 'Ran 22 tests' in (A/'tests.log').read_text() and '\nOK\n' in (A/'tests.log').read_text()
previous=ROOT/'stage11-local-refinement-review-20261003T173938Z/archive/diagnostic'
for n in ('initialization.json','summary.json','states.npz'):
 assert (D/'archived-C4'/n).read_bytes()==(previous/'cases/C4'/n).read_bytes()
assert (D/'archived-C4/historical-C3-C4-comparison.json').read_bytes()==(previous/'time-aligned-comparison.json').read_bytes()
result={'status':'RETURN_REVIEW_COMPLETE_SENSITIVITY_FAILURE_CONFIRMED','method':'Independent NumPy/JSON/gzip arithmetic only; no simulator import, forward, replay or integration.',
    'canonical_completed_steps':12695,'review_new_integration_steps':0,'new_ppo_updates':0,'stage11_complete':False,
    'stage11_status':'MATERIAL_BLOCKED_REVIEW_REQUIRED','archive':read(R/'retrieval-provenance.json'),
    'manifest_and_installed_source_sha_match':True,'old_head_tag_index_and_mdp_preserved_as_reported':True,'C4_copy_and_historical_failure_byte_identical':True,
    'cases':{},'comparisons':{},'limitations':['Runtime no-warning and model-copy invariants are supported by guarded source and returned assertions, not an independent rerun.','Numerical agreement of one fixture does not validate the whole robot or policy.']}
series={}
for name,dt,n,directory in [('C4',.0000625,800,previous/'cases/C4'),('C5',.00003125,1600,D/'cases/C5'),('C6',.000015625,3200,D/'cases/C6')]:
 with np.load(directory/'states.npz',allow_pickle=False) as z:
  q,v,t=[z[k].copy() for k in ('qpos','qvel','time')];assert float(z['dt'])==dt
 assert q.shape==(n+1,7) and v.shape==(n+1,6) and t.shape==(n+1,)
 assert all(np.isfinite(x).all() for x in (q,v,t)) and np.max(abs(t-(.39+dt*np.arange(n+1))))<1e-11
 assert np.max(abs(np.linalg.norm(q[:,3:],axis=1)-1))<1e-12
 init=read(directory/'initialization.json')
 assert init['initial_contacts']==0 and init['time_s']==.39
 for k,x in [('qpos',q[0]),('qvel',v[0])]:np.testing.assert_array_equal(init[k],x)
 if name!='C4':
  for k in ('qpos','qvel','qacc_warmstart'):np.testing.assert_array_equal(init[k],read(D/'archived-C4/initialization.json')[k])
  partial=[json.loads(l) for l in (directory/'states.partial.jsonl').read_text().splitlines()]
  assert len(partial)==n+1
  for j,r in enumerate(partial):
   assert r['returned_steps']==j and r['time_s']==t[j]
   np.testing.assert_array_equal(r['qpos'],q[j]);np.testing.assert_array_equal(r['qvel'],v[j])
 logs=[json.loads(l) for l in gzip.open(directory/'contacts.jsonl.gz','rt')];assert len(logs)==n
 f=np.zeros((n,3));active=np.zeros(n,dtype=bool);pre_peak=post_peak=0.
 for j,r in enumerate(logs):
  assert r['step']==j and abs(r['time_s']-t[j])<1e-11
  for k,x in [('qpos_before',q[j]),('qpos_after',q[j+1]),('qvel_before',v[j]),('qvel_after',v[j+1])]:np.testing.assert_array_equal(r[k],x)
  assert len(r['contacts'])==len(r['raw_contacts'])<=1
  for c,raw in zip(r['contacts'],r['raw_contacts']):
   for k,value in raw.items():assert c[k]==value
   assert c['geom']==[0,2] and c['other']=='floor' and c['allowed'] and c['dim']==4
   assert c['friction']==[.6,.6,.005,.0001,.0001] and c['solref']==[.001,1.] and c['solimp']==[.95,.99,.001,.5,2.]
   assert c['normal_toward_ball']==[0.,0.,1.] and c['phase']=='pre_integration_contacts_and_solver_force'
   assert abs(c['dist']-(q[j,2]-.02))<1e-14 and abs(c['time_s']-t[j])<1e-11
   assert np.isfinite(np.r_[c['dist'],c['pos'],c['frame'],c['force']]).all()
   f[j]+=np.asarray(c['frame']).reshape(3,3).T@np.asarray(c['force'][:3]);pre_peak=max(pre_peak,-c['dist'])
  active[j]=bool(r['contacts']);post=r['post_state_geometry'];overlap=max(0.,.02-q[j+1,2])
  assert abs(post['floor_overlap_m']-overlap)<1e-14 and abs(post['time_s']-t[j+1])<1e-11
  assert all(c['geom']==[0,2] for c in post['contacts']);post_peak=max(post_peak,overlap)
 vel_res=float(np.max(abs(v[1:,:3]-(v[:-1,:3]+dt*(f/.01+[0,0,-9.81])))))
 pos_res=float(np.max(abs(q[1:,:3]-(q[:-1,:3]+dt*v[1:,:3]))))
 assert vel_res<1e-12 and pos_res<1e-14
 events=[]
 for i,j in np.flatnonzero(np.diff(np.r_[False,active,False])).reshape(-1,2):
  events.append({'first_step':int(i),'end_step_exclusive':int(j),'onset_time_s':float(t[i]),'end_time_s':float(t[j]),
   'right_censored':bool(j==n),'entry_vz_m_s':float(v[i,2]),'exit_vz_m_s':float(v[j,2]),'normal_impulse_Ns':float(np.sum(f[i:j,2])*dt),
   'peak_overlap_m':float(max(0.,np.max(.02-q[i:j+1,2]))),'normal_impulse_all_axes_Ns':(np.sum(f[i:j],axis=0)*dt).tolist()})
 s=read(directory/'summary.json');values={'max_pre_step_penetration_m':pre_peak,'max_post_step_overlap_m':post_peak,'normal_impulse_Ns':float(np.sum(f[:,2])*dt),'max_normal_force_N':float(np.max(f[:,2])),'max_upward_velocity_m_s':max(0.,float(np.max(v[:,2])))}
 for k,value in values.items():assert abs(value-s[k])<1e-14,(name,k)
 assert s['steps']==s['attempted_steps']==n and s['horizon_completed'] and pre_peak<=.001 and post_peak<=.001
 result['cases'][name]={**values,'steps':n,'dt_s':dt,'events':events,'velocity_update_residual_m_s':vel_res,'position_update_residual_m':pos_res,'all_logged_pairs_materials_normals_and_pre_post_phases_match':True,'states_sha256':sha(directory/'states.npz')}
 series[name]={'q':q,'v':v,'t':t,'dt':dt,'f':f,'active':active,'summary':s,'logs':logs}

for an,bn in [('C4','C5'),('C5','C6')]:
 a,b=series[an],series[bn];assert np.array_equal(a['q'][0],b['q'][0]) and np.array_equal(a['v'][0],b['v'][0]);stride=round(a['dt']/b['dt']);assert stride==2
 assert np.max(abs(a['t']-b['t'][::stride]))<1e-11
 pd=np.linalg.norm(a['q'][:,:3]-b['q'][::stride,:3],axis=1);vd=np.linalg.norm(a['v'][:,:3]-b['v'][::stride,:3],axis=1)
 ca,cb=result['cases'][an],result['cases'][bn]
 observed={'abs_difference_peak_sampled_overlap_m':abs(ca['max_post_step_overlap_m']-cb['max_post_step_overlap_m']),
 'max_common_time_position_difference_m':float(pd.max()),'max_common_time_linear_velocity_difference_m_s':float(vd.max()),
 'abs_difference_peak_upward_velocity_m_s':abs(ca['max_upward_velocity_m_s']-cb['max_upward_velocity_m_s'])}
 original=report['comparison'][an+'_'+bn];checks=original['sensitivity']['checks']
 for k,val in observed.items():assert val==checks[k]['value'] and bool(val<=checks[k]['limit'])==checks[k]['pass']
 assert original['common_saved_samples']==len(pd)
 # At saved time t[k], only intervals strictly before k contribute impulse.
 ia=np.vstack((np.zeros(3),np.cumsum(a['f'],axis=0)*a['dt']))
 ib=np.vstack((np.zeros(3),np.cumsum(b['f'],axis=0)*b['dt']))
 residual=a['v'][:,:3]-b['v'][::2,:3]-(ia-ib[::2])/.01
 assert np.max(abs(residual))<1e-11
 points=[]
 for index in sorted(set([int(np.argmax(pd)),int(np.argmax(vd)),len(pd)-1])):
  point={'common_time_s':float(a['t'][index]),'position_difference_m':float(pd[index]),'velocity_difference_m_s':float(vd[index]),'velocity_difference_from_cumulative_force_impulse_m_s':((ia[index]-ib[2*index])/.01).tolist()}
  for name,x,j in [(an,a,index),(bn,b,2*index)]:
   point[name]={'index':j,'gap_m':float(x['q'][j,2]-.02),'velocity_m_s':x['v'][j,:3].tolist(),'force_at_pre_state_N':x['f'][j].tolist() if j<len(x['f']) else None}
  points.append(point)
 windows=[]
 for lo,hi in [(.39,.395),(.395,.43),(.43,.44)]:
  mask=(a['t']>=lo-1e-11)&(a['t']<=hi+1e-11)
  windows.append({'begin_s':lo,'end_s':hi,'max_position_difference_m':float(pd[mask].max()),'max_velocity_difference_m_s':float(vd[mask].max())})
 result['comparisons'][an+'_'+bn]={'checks':checks,'common_samples':len(pd),'max_position_difference_time_s':float(a['t'][np.argmax(pd)]),'max_velocity_difference_time_s':float(a['t'][np.argmax(vd)]),
 'impulse_difference_explains_saved_velocity_difference_max_residual_m_s':float(np.max(abs(residual))),'key_states':points,'time_windows':windows,'time_shift_applied_s':0}
result['conclusion']={'finest_pair_passed_metrics':2,'finest_pair_total_metrics':4,'first_contact_same_explicit_step_grid_time_C5_C6':result['cases']['C5']['events'][0]['first_step']*.00003125==result['cases']['C6']['events'][0]['first_step']*.000015625,
 'first_contact_saved_clock_difference_s':result['cases']['C5']['events'][0]['onset_time_s']-result['cases']['C6']['events'][0]['onset_time_s'],
 'second_contact_time_C5_minus_C6_s':result['cases']['C5']['events'][1]['onset_time_s']-result['cases']['C6']['events'][1]['onset_time_s'],
 'no_C7_or_parameter_search_executed':True,'interpretation':'Complete exact-time comparison still fails. Saved impulse differences account for velocity differences; differing rebound/second-contact timing amplifies a small first-impact difference. This is a saved-trajectory explanation, not a proof of the numerical cause or a reason to waive the original gates.'}
(R/'local-floor-reference-review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k in ('status','canonical_completed_steps','cases','comparisons','conclusion')},indent=2))
