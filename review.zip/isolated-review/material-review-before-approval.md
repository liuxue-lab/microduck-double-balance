# Stage 11 本机 v2 材料复核与落地诊断提案

状态：**MATERIAL_BLOCKED_REVIEW_REQUIRED，阶段未完成**。本机有界验证已完成并由用户 SSH 推送，当前停止于第四个材料案例。此次审查仅读取已有证据，新增积分步、PPO、云计算均为 0。以下新诊断尚未实施，需用户确认参数对照范围。

## 本机结果

| 项目 | 结果 |
|---|---|
| 针对性测试 | 13 passed，0 skipped；保留 2 条 actuator/site 匹配警告 |
| 去除托盘后的质量、质心、完整 3×3 惯量 | PASS；机器人质量 0.75524318 → 0.73724318 kg |
| v2 静态几何 | 49/49 PASS |
| 旧 v1 几何判据 | 42/49 PASS，原 7 项 BLOCKED 保留 |
| 最大静态点到原曲面距离 | 0.006047513 mm |
| 最大静态球壳间隙差 | 0.001521044 mm |
| 最大静态法线差 | 0.697878608° |
| CPU release-center | 1500 步，材料门槛 PASS；最大穿透 0.620347 mm |
| CPU release-x-minus12 | 1500 步，材料门槛 PASS；最大穿透 0.556655 mm |
| CPU release-x-plus12 | 1500 步，材料门槛 PASS；最大穿透 0.420664 mm |
| CPU release-y-minus12 | 197 步，首次落地穿透 2.667188 mm，BLOCKED |
| 未执行 | 9 个 CPU 案例、全部 13 个 CUDA 案例；专项滑移/滚动/自旋矩阵尚未完成 |
| 本机累计材料积分 | 4697 步 |
| 本机整机积分、PPO、云计算 | 0、0、0 |

这里的材料 PASS 只表示该段记录满足已列物理门槛，允许球滚落；它不表示球持续留在头上，更不表示无辅助双球策略成功。固定头只存在于材料夹具，整机头颈自由度未锁。

第四例最后接触对象明确为 `floor`，采样索引 196、时间 0.392 s，法线 (0,0,1)，法向力 10.117700749 N，滑移速度 0.115657255 m/s。有效摩擦仍为 [0.6,0.6,0.005,0.0001,0.0001]，condim=4，solref=[0.003,1]；没有提高摩擦或修改参数来放行。

四个本机案例的全部摘要字段（除墙钟时长外）均与先前隔离 CPU 结果一致，最后接触记录逐字段一致。可以确认该阻塞在完整本机环境复现；不能从摘要相等推导整条原始轨迹逐字节相等，也不能推广为 CUDA 确定性结论。

先前隔离原始状态的代数复核表明：t=0.390 s 球底仍距地面 0.640381 mm，竖直速度约 -1.634165 m/s；经过原定 2 ms 积分，下一接触采样已深入地面 2.667188 mm。该解释与本机最终接触记录一致；本机相邻原始状态仍需在本机读取后独立复核。先前隔离数据中的头壳最大穿透为 0.084472 mm，本次不将它冒充已从本机完整接触日志重新计算的数值。

## 证据出处与尚未读取的材料

归档分支 `stage11-physics-v2-transfer-20261003t094423z`，固定提交 `51df1774385fec998b8a8e7f7dcfcde5f5a10a27`。本机目录：

`/home/lx/microduck-double-balance/artifacts/double-balance-stage11/physics/20261003T094423Z`

本次通过连接的 GitHub 读取 12 份文本，并逐份校验 Git blob 哈希。接受用户正常 push 输出；读取固定提交仅用于证据审查，没有重做代码分支、标签、CI 的完整远端核验。

归档声明的 ZIP SHA256 为 `d2c6cb2c788ee3b7020f6557dac1e0646940bebd43b290dc4b3f5c6e8110278d`。这里尚未下载该 ZIP 字节，不能声称已完成 ZIP SHA256 回传核验。也未读取本机 `.npz`/压缩接触日志或观看本机 MP4。

报告显示本机视频包含 12 帧，末两帧为 0.392 s、0.394 s，MP4 SHA256 为 `c55a11f706dc097e3103d6529d8601f010603d98505a2257313e186bef4b9335`。这只是已读元数据，视频人工检查仍 PENDING，不能用先前隔离视频代替本机视频验收。

需要本机进一步读取的准确文件，以以上目录为根：

- `evidence-inventory.json`
- `local-v2/material-fixture.mjb`
- `local-v2/cpu/release-y-minus12/states.npz`
- `local-v2/cpu/release-y-minus12/raw-contacts.jsonl.gz`
- `local-v2/cpu/release-y-minus12/contacts.jsonl.gz`
- `local-v2/material-cpu-release-y-minus12-BLOCKED.mp4`

## 建议下一步：仅对这一次落地做受控诊断

不推荐直接改正式任务时间步，也不推荐提高 1 mm 门槛、忽略地面，或继续原矩阵。现有证据已经排除了“只在隔离环境发生”的解释；下一步应辨别离散采样跨越与接触柔顺性各自的作用。

MuJoCo 的 refsafe 规则使约束使用 `max(solref[0], 2×dt)`。因此当前 dt=2 ms、solref[0]=3 ms 时，法向有效时间常数为 4 ms；直接把 dt 减半会同时使其变为 3 ms，不能把所有变化都归因于时间分辨率。该规则已核对官方文档与固定 mujoco-warp 3.8.1 的 `constraint.py`；它不代表 CUDA 已执行。

拟在本机读取上面的原 MJB 和状态索引 195（t=0.390 s），创建各自独立的内存模型副本，从同一保存状态初始化。仅用本机 CPU MuJoCo：

| 组 | 时间步 dt | 输入 solref[0] | 预期法向有效时间常数 | 目的 |
|---|---:|---:|---:|---|
| A0 | 2 ms | 3 ms | 4 ms | 局部重建对照，核对已知落地事件 |
| A1 | 1 ms | 3 ms | 3 ms | 保留原参数的细步诊断 |
| A2 | 0.5 ms | 3 ms | 3 ms | 保留原参数的更细步诊断 |
| B1 | 1 ms | 4 ms | 4 ms | 固定法向时间常数，分离步长影响 |
| B2 | 0.5 ms | 4 ms | 4 ms | 固定法向时间常数的更细步诊断 |

**这是拟议的诊断参数变更，尚未获批。** B1/B2 显式改变副本球体的 solref[0]，不是暗中更改正式物理。材料、摩擦、质量/惯量、头壳网格、碰撞掩码、重力、condim、solimp、阻尼比、margin/gap、求解器及迭代数、refsafe 开关均保持原值。所有组的 1 mm 穿透分类不变。

每组最多 50 ms，五组最多 325 个积分步，总墙钟不超过 5 分钟。PPO、云 GPU、整机积分均为 0；无随机种子组和训练预算。

执行前先检查输入清单、哈希、源版本和旧运行；读取本机相邻状态并重复代数后处理，不额外积分。初始化仅从已保存 qpos/qvel 重建派生量与 warm-start，明确记录初始化方法，不能称作完整历史状态恢复。A0 的判别目标是核对首次地面接触时刻和数值：距离误差≤1e-9 m，力/力矩分量使用 rtol=1e-5、atol=1e-7 对照已归档值。若 A0 无法复现，整个新矩阵停止，不运行后四组。

每一组在首次穿透>1 mm、非有限值、非预期接触、时长/墙钟上限时停止，保存原始记录。A0 预期仍会得到 BLOCKED；只有用户批准这个独立对照矩阵后，才允许从新的相同初态进入下一预定组。原 v2 验证器的“首次失败停止全矩阵”逻辑不变，旧失败不改为 PASS。

输出第一接触时刻、接触前间隙/速度、穿透、法向力、实际参数与法向有效时间常数、保存状态、日志及源码哈希。对照 A0/B1/B2 看固定柔顺性时的步长效应，再比较 A1/A2 与 B1/B2。触碰采样相位可能使逐样本最大值不严格单调，不能预先承诺细步一定通过。

本小试只提供物理诊断证据：任何组通过都不解除原材料矩阵阻塞，不授权正式使用新步长或新 solref。若仍不通过或解释不充分，停止并报告，不自动增加参数搜索；若证据清楚，再单独审查是否迁移候选数值设置及完整 CPU/CUDA 矩阵。

## 拟改文件与影响

| 文件 | 拟变更 |
|---|---|
| `scripts/diagnose_head_contact_floor_impact.py` | 新增显式启用的诊断入口，只读旧证据、只修改独立内存副本 |
| `tests/test_head_contact_floor_impact.py` | 检查参数差异范围、源模型保留、计步/计时、初始化与停止逻辑 |
| `docs/audits/stage-11-floor-impact-diagnostic-plan.json` | 保存五组矩阵、批准范围、预算与停止条件 |
| `docs/audits/stage-11-local-material-review.json` | 记录本机结果、来源、尚未读取的证据 |
| `docs/handoffs/microduck-stage-11-head-contact-physics-handoff.md` | 追加本次阻塞与获批后的准确命令，保留历史快照 |

当前仅完成审查与提案文档，没有实施或执行该诊断，也没有修改用户本机文件。

## 持续保留的项目边界

本机 HEAD 仍为 `056eaf2b0c78261f34e3fa581858c8573cab981e`；基线跟踪文件、暂存区无变化。旧注释标签 `stage-10-complete` 仍指向 `1a11f30cc7264d00dec7bce8f11449ded9164169`；不创建 `stage-11-complete`。Stage 11 的八个源/文档文件目前仍为本机未跟踪新增文件，归档提交不等于代码分支提交。

主模型仍为 Stage 08 E/20260929/update_004000.pt，SHA256 `86d55c3703c18fcf4817db49c6e4dcf839b3f5195d68ae2c559db7e222bded97`；历史独立严格成功 652/768（84.90%）保持。Stage 10 B1/C1 缺口与未证明的完整因果链不倒填。正式观测、初态、奖励和验收参考系迁移另行审查。

10 s 回合、终局连续稳定≥5 s、无辅助、下球速度≤0.15 m/s 和原计时边界不变。暂停头部纠偏；允许调整时转头、稳定后回正，不添加全程朝前约束。固定头材料测试不计策略成功。

本机仓库 `/home/lx/microduck-double-balance/workspace`，下载 `/home/lx/下载`。继续遵守 `docs/handoffs/microduck-local-ssh-push-protocol.md` 和 `docs/handoffs/microduck-cloud-gpu-and-transfer-protocol.md`。上传/必要回传默认 Git SSH，代码与模型/证据归档分支分开，不合并归档分支；本机创建提交和标签，由用户推送，正常 push 输出足够。

RTX 5060 仅代码、仿真、推理和视频；云 RTX 5090 保持用户确认关闭状态，没有新云会话或关机操作。Stage 09 全量云原始轨迹未全部回传，禁止删除。未来计算与必要回传 SHA256 完成后立即提醒手动关机，提醒和确认分开记录。不得运行旧自动关机守护或 Stage 06 smoke，不重跑旧收尾/CI 修复。

常见错误继续按原规范处理：HEAD、输入哈希、版本或目标文件不符就保留现场并停止；不 reset/force、不覆盖未知修改、不自动安装/同步依赖。当前下一步是确认上述五组诊断范围，无新的运行命令。

## 来源

- [本机运行摘要](https://github.com/liuxue-lab/microduck-double-balance/blob/51df1774385fec998b8a8e7f7dcfcde5f5a10a27/run-summary.json)
- [本机物理报告](https://github.com/liuxue-lab/microduck-double-balance/blob/51df1774385fec998b8a8e7f7dcfcde5f5a10a27/local-physics-review.json)
- [首次落地接触记录](https://github.com/liuxue-lab/microduck-double-balance/blob/51df1774385fec998b8a8e7f7dcfcde5f5a10a27/cpu-release-y-minus12-last-contact.json)
- [本机静态几何](https://github.com/liuxue-lab/microduck-double-balance/blob/51df1774385fec998b8a8e7f7dcfcde5f5a10a27/local-static-geometry.json)
- [本机测试日志](https://github.com/liuxue-lab/microduck-double-balance/blob/51df1774385fec998b8a8e7f7dcfcde5f5a10a27/tests.log)
- [MuJoCo 官方 refsafe 说明](https://mujoco.readthedocs.io/en/stable/XMLreference.html#option-flag-refsafe)
