"""Review all saved static CUDA probes without integration or new CUDA calls."""
from pathlib import Path
import importlib.util,json,hashlib,numpy as np,mujoco
from unittest.mock import patch
root=Path('stage11-local-cuda-normal-review-20261004T112308Z');p=root/'archive/diagnostic'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sp=importlib.util.spec_from_file_location('normal_review','stage11-build/scripts/probe_head_contact_cuda_normal.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
run,report=read(root/'run-summary.json'),read(p/'diagnostic-review.json')
assert run['physics_integration_steps']==run['physics_attempted_steps']==report['diagnostic_completed_steps']==report['diagnostic_attempted_steps']==0
assert run['canonical_total_known_completed_steps']==report['canonical_total_known_completed_steps']==13354
assert report['query_attempts']==report['queries_completed']==8 and not report['not_completed_queries']
assert run['execution_invariants_unchanged'] and report['CPU_model_unchanged'] and report['GPU_model_unchanged'] and report['source_files_unchanged']
manifest=read(root/'archive/package-manifest.json');assert manifest==read(Path('stage11-cuda-normal-package-manifest.json'))
assert read(p/'source-snapshot.json')==manifest['files']
assert report['diagnostic_source_sha256']==sha(Path('stage11-build/scripts/probe_head_contact_cuda_normal.py'))
for prefix in ('model-signature','device-model'):assert (p/(prefix+'-before.json')).read_bytes()==(p/(prefix+'-after.json')).read_bytes()
model=mujoco.MjModel.from_binary_path(str(p/'material-fixture.mjb'))
assert sha(p/'material-fixture.mjb')=='e6cd330bddc3a29abf9ce4eca4f308a2680e4910405725e5ce054cb0a19d2da0'
with np.load(p/'material-geometry.npz') as z:triangles=z['vertices'][z['faces']]
states=read(p/'selected-states.json');records=[]
with patch.object(mujoco,'mj_step',side_effect=AssertionError('Review prohibits integration')):
 for result in report['results']:
  dest=p/'cases'/result['case']/result['route'];initial,raw=read(dest/'input.json'),read(dest/'raw-result.json')
  assert result==read(dest/'result.json')
  s=next(s for s in states if s['name']==result['case']);assert initial['case']==s
  for k,v in initial['primary_before'].items():np.testing.assert_array_equal(v,raw['primary_after'][k])
  np.testing.assert_array_equal(initial['primary_before']['qpos'][0],s['qpos']);np.testing.assert_array_equal(initial['primary_before']['qvel'][0],s['qvel'])
  assert initial['primary_before']['time'][0]==s['time'] and not raw['warnings']
  assert np.count_nonzero(initial['warmstart_before'])==0 and np.isfinite(raw['qacc']).all()
  native=[{**c,**{k:np.asarray(c[k],dtype=np.float32) for k in ('pos','frame','force','friction','solref','solimp')},'dist':np.float32(c['dist'])} for c in raw['records']]
  rows,gate=m.assess(model,{**s,'qpos':np.asarray(s['qpos'],np.float32),'qvel':np.asarray(s['qvel'],np.float32)},native,triangles)
  assert gate==result['gate'] and len(rows)==len(result['contacts'])
  for a,b in zip(rows,result['contacts']):
   for k in ('normal_toward_ball','frame','slip_world_m_s','slip_speed_m_s'):
    np.testing.assert_allclose(a[k],b[k],rtol=1e-10,atol=1e-12)
   for k in ('normal_error_deg','surface_distance_m','sphere_gap_error_m'):np.testing.assert_allclose(a['geometry'][k],b['geometry'][k],rtol=1e-10,atol=1e-12)
   if result['route']=='collision':assert b['force'] is None and b['normal_force_N'] is None
   else:
    for k in ('normal_force_N','force','tangential_power_W','torsional_power_W'):np.testing.assert_allclose(a[k],b[k],rtol=1e-10,atol=1e-12)
  records.append({'case':result['case'],'route':result['route'],'gate':gate['status'],'contact_count':len(rows),'normal_error_deg':rows[0]['geometry']['normal_error_deg'] if rows else None,'dist_m':rows[0]['dist'] if rows else None,'normal_toward_ball':rows[0]['normal_toward_ball'] if rows else None})
for name in m.CASES:
 a=read(p/'cases'/name/'collision/raw-result.json')['records'];b=read(p/'cases'/name/'forward/raw-result.json')['records']
 for x,y in zip(a,b):
  for k in ('geom','dist','pos','frame','dim','friction','solref','solimp'):assert x[k]==y[k]
old=Path('stage11-local-cuda-friction-review-20261004T104109Z/archive/diagnostic/cases/slide-x-minus')
import gzip
historic=[json.loads(l) for l in gzip.open(old/'raw-contacts.jsonl.gz','rt')][50]['contacts'][0]
fresh=read(p/'cases/GPU50/collision/raw-result.json')['records'][0]
for k in ('geom','dist','pos','frame','dim','friction','solref','solimp'):assert fresh[k]==historic[k]
result={'status':'CUDA_STATIC_NORMAL_FAILURE_LOCALIZED_TO_COLLISION','stage11_status':'MATERIAL_BLOCKED_REVIEW_REQUIRED','stage11_complete':False,'retrieval':read(root/'retrieval-provenance.json'),'source77_files_and_both_model_hashes_unchanged':True,'queries_reviewed':8,'native_contact_rows_reconstructed':6,'new_review_integration_steps':0,'new_PPO':0,'canonical_total_steps':13354,'cases':records,
 'finding':'GPU50 native collision-only and native forward produce bit-identical geometry/material fields, matching the historical failing contact. GPU49/GPU51 pass original geometric gates, CPU50-rounded32 has no contact. An integrator launch, prior solver warmstart and CUDA graph launch are not necessary to reproduce this contact geometry failure at this state.',
 'limits':['This proves sufficiency of fresh collision computation for the saved state, not why historical integration reached it','Native CCD intermediate witnesses not yet recorded; float32 inflated-witness subtraction cancellation still requires direct evidence','Fresh forward zero warmstart does not assert bit-identical historic forces','No new video necessary: primary state/time unchanged, previous55frames reviewed','No material acceptance, policy success, formal migration or training approval'],
 'next_scope':'Read-only original native CCD/GJK/inflate witness diagnostic on the same four saved kinematic states, with exact output comparison against saved CUDA contacts; no installed-engine patch, parameter change or integration.',
 'progress_estimate':{'percent':70,'meaning':'subjective engineering work estimate unchanged; no acceptance metric'}}
(root/'local-cuda-normal-review.json').write_text(json.dumps(result,indent=2,default=m.v2.serial)+'\n')
print(json.dumps({'status':result['status'],'records':records,'new_integration':0},indent=2,default=m.v2.serial))
