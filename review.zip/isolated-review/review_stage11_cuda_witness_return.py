"""Read-only reconstruction of returned CUDA witness arithmetic; no GPU calls."""
from pathlib import Path
import importlib.util,json,hashlib,numpy as np
root=Path('stage11-local-cuda-witness-review-20261004T114251Z');p=root/'archive/diagnostic'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sp=importlib.util.spec_from_file_location('witness_review','stage11-build/scripts/probe_head_contact_cuda_witness.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
run,report=read(root/'run-summary.json'),read(p/'diagnostic-review.json')
assert run['physics_integration_steps']==run['physics_attempted_steps']==report['diagnostic_completed_steps']==report['diagnostic_attempted_steps']==0
assert run['canonical_total_known_completed_steps']==report['canonical_total_known_completed_steps']==13354
assert run['query_attempts']==run['queries_completed']==report['query_attempts']==report['queries_completed']==4
assert run['execution_invariants_unchanged'] and report['CPU_model_unchanged'] and report['GPU_model_unchanged'] and report['source_files_unchanged']
assert not report['not_completed_cases'] and not report['collision_normal_replacement'] and not report['installed_dependency_patch']
manifest=read(root/'archive/package-manifest.json');assert manifest==read(Path('stage11-cuda-witness-package-manifest.json'))
assert read(p/'source-snapshot.json')==manifest['files']
assert report['diagnostic_source_sha256']==sha(Path('stage11-build/scripts/probe_head_contact_cuda_witness.py'))
for prefix in ('model-signature','device-model'):assert (p/(prefix+'-before.json')).read_bytes()==(p/(prefix+'-after.json')).read_bytes()
results=[]
for item in report['results']:
 c=item['case'];w=read(p/'cases'/c/'witness.json');raw=read(p/'saved-inputs'/c/'raw-result.json');reference=read(p/'saved-inputs'/c/'result.json')
 w={**w,'scalars':np.asarray(w['scalars'],np.float32),'vectors':np.asarray(w['vectors'],np.float32),'frame':np.asarray(w['frame'],np.float32)}
 a=m.analyze(w,raw,reference)
 assert json.loads(json.dumps(a,default=m.v2.serial))==read(p/'cases'/c/'analysis.json')
 assert {'case':c,**json.loads(json.dumps(a,default=m.v2.serial))}==item
 assert a['all_native_contact_fields_match']
 if a['shallow_finite_branch']:
  assert a['separate_shrink_inflate_matches_native_CCD_witnesses']
  np.testing.assert_array_equal(w['vectors'][4]-w['vectors'][5],w['vectors'][10])
  # Float64 norm avoids underflow while reconstructing the stored float32 axis.
  normal=w['vectors'][10].astype(float);normal/=np.linalg.norm(normal)
  np.testing.assert_allclose(normal,w['frame'][0],rtol=2e-7,atol=1e-12)
 results.append(item)
w=read(p/'cases/GPU50/witness.json');s=np.asarray(w['scalars'],np.float32);v=np.asarray(w['vectors'],np.float32)
assert np.array_equal(v[10],np.array([0.,-2.228038111435672e-16,0.],np.float32))
assert np.array_equal(v[4][[0,2]],v[5][[0,2]])
assert np.array_equal(np.asarray(w['frame'])[0],[0,-1,0])
ideal=-float(s[6])*v[6].astype(float)
spacing=np.spacing(v[5]).astype(float)
result={'status':'SAVED_CUDA_CONTACT_CANCELLATION_MECHANISM_REVIEWED','stage11_status':'MATERIAL_BLOCKED_REVIEW_REQUIRED','stage11_complete':False,'retrieval':read(root/'retrieval-provenance.json'),'queries_reviewed':4,'canonical_integration_total':13354,'new_review_integration_steps':0,'new_PPO':0,'source82_files_and_CPU_GPU_models_unchanged':True,'results':results,
 'GPU50_arithmetic':{'radius_float32_m':float(s[8]),'shrunk_GJK_distance_m':float(s[3]),'inflated_distance_m':float(s[6]),'preinflate_direction':v[6],'inflated_witness1':v[4],'inflated_witness2':v[5],'inflated_witness_difference':v[10],'native_frame_normal':w['frame'][0],'ideal_distance_times_preinflate_direction':ideal,'witness2_float32_spacing_m':spacing,'curve_direction_candidate_only':-v[6]},
 'established':'On RTX5060 the independent original-function CCD exactly matches all saved native contact fields; its witnesses equal the separately called original sphere shrink/inflate branch. GPU50 loses both X and Z witness differences in float32, leaving only a tiny Y residual. Normalization produces the saved90degree wrong normal. Previous saved impulse review links that normal/force to the actual lateral/angular jump.',
 'limits':['Case-specific collision arithmetic mechanism, not a proof of all Stage10initialization/nondeterminism causes','Returned pre-inflation directions are candidate data only, not a deployed engine fix','No patched-backend dynamic trajectory or completed material acceptance','Original floor2ms/sensitivity issues and missing cases remain; policy objective unmet'],
 'next_decision':'Stop repeating the bad-state diagnosis. Prepare a narrowly scoped candidate that preserves the pre-inflation normal through shallow sphere-mesh CCD, with original distance/witness/no-contact/deep-path guards and isolated static validation before any formal adoption.',
 'progress_estimate':{'percent':70,'basis':'Engineering-work estimate retained. Root cause of one blocking contact is now established; physical repair validation and stage closure remain incomplete.','not_acceptance_or_policy_rate':True}}
(root/'local-cuda-witness-review.json').write_text(json.dumps(result,indent=2,default=m.v2.serial)+'\n')
print(json.dumps({'status':result['status'],'queries':4,'GPU50_arithmetic':result['GPU50_arithmetic'],'integration_total':13354},indent=2,default=m.v2.serial))
