"""Independent constrained optimization of the blocked closest-point result."""
from pathlib import Path
import json,numpy as np
from scipy.optimize import minimize
from scipy.spatial import ConvexHull
from mjlab_microduck.robot.head_contact import nearest_surface
out=Path('stage11-cpu-review'); d=json.loads((out/'static-geometry.json').read_text())
r=next(x for x in d['rows'] if x['pose']=='home' and x['point']=='y-plus12')
z=np.load(out/'material-geometry.npz'); tri=z['vertices'][z['faces']]; p=np.array(r['center'])
# Bounding-box lower bound safely includes every triangle able to improve on
# the saved candidate. Optimize barycentric coordinates independently.
upper=np.linalg.norm(p-r['mesh_witness']); low=np.maximum(np.maximum(tri.min(1)-p,p-tri.max(1)),0)
ids=np.flatnonzero(np.linalg.norm(low,axis=1)<=upper+1e-10)
best=(1e99,None,None);fails=0
for i in ids:
 a,b,c=tri[i];u=b-a;v=c-a
 fun=lambda x: float(np.sum((a+x[0]*u+x[1]*v-p)**2))*1e6
 jac=lambda x: 2e6*np.array([u@(a+x[0]*u+x[1]*v-p),v@(a+x[0]*u+x[1]*v-p)])
 opt=minimize(fun,[1/3,1/3],jac=jac,method='SLSQP',bounds=[(0,1),(0,1)],constraints=[{'type':'ineq','fun':lambda x:1-x.sum(),'jac':lambda x:np.array([-1.,-1.])}],options={'ftol':1e-12,'maxiter':100})
 fails+=not opt.success
 q=a+opt.x[0]*u+opt.x[1]*v;dist=np.linalg.norm(p-q)
 if dist<best[0]:best=(dist,q,int(i))
hull=ConvexHull(z['vertices']);hw,hd,_=nearest_surface(p,z['vertices'][hull.simplices])
engine=np.array(r['engine_witness']);ew,ed,_=nearest_surface(engine,tri)
result={'input_scope':'Previously saved static geometry only; zero new physics steps','candidate_triangles':len(ids),'optimizer_failures':int(fails),'independent_distance_m':best[0],'independent_witness_m':best[1].tolist(),'independent_face':best[2],'difference_from_vectorized_witness_m':float(np.linalg.norm(best[1]-r['mesh_witness'])),'engine_to_independent_witness_m':float(np.linalg.norm(engine-best[1])),'engine_point_to_original_triangles_m':ed,'convex_hull_witness_m':hw.tolist(),'convex_hull_distance_m':hd,'engine_to_hull_witness_m':float(np.linalg.norm(engine-hw)),'inference':'CPU compiled-mesh collision agrees with convex hull; the saved original-triangle nearest point differs tangentially. This does not prove Warp contact behavior.'}
(out/'independent-distance-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
