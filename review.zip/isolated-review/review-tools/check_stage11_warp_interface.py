"""One analytic fixture API check on Warp CPU; never RTX evidence."""
import importlib.util,json
from pathlib import Path
import mujoco,numpy as np
sp=importlib.util.spec_from_file_location('v','stage11-build/scripts/validate_head_contact_physics.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
m=mujoco.MjModel.from_xml_string('''<mujoco><option timestep=".002" integrator="implicitfast" iterations="10" ls_iterations="20"/><worldbody>
<geom name="head" type="plane" size="1 1 .1" condim="4"/>
<geom name="floor" type="plane" size="1 1 .1" pos="0 0 -1"/>
<body name="ball" pos="0 0 .02001"><freejoint/><geom name="sphere" type="sphere" size=".02" mass=".01" condim="4" friction=".6 .005 .0001" priority="1" solref=".003 1" solimp=".95 .99 .001 .5 2"/></body>
</worldbody></mujoco>''')
d=mujoco.MjData(m);mujoco.mj_forward(m,d);stepper=v.WarpStepper(m,d,'cpu');summary={'scope':'Analytic plane/sphere API validation only','device':'cpu','is_cuda':False,'steps':0,'contacts':0,'finite':True,'status':'RUNNING'}
for i in range(4):
 q,vel,records=stepper.step();summary['steps']+=1;summary['contacts']+=len(records);summary['finite']&=bool(np.isfinite(np.r_[q,vel]).all())
 if records:summary['last_force']=records[-1]['force'];summary['last_dist']=records[-1]['dist']
assert summary['contacts']>0 and summary['finite']
summary['status']='PASS';v.save(Path('stage11-warp-interface-review.json'),summary);print(json.dumps(summary,default=v.serial,indent=2))
