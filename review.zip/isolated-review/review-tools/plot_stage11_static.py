from pathlib import Path
import json,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
out=Path('stage11-cpu-review');r=next(r for r in json.loads((out/'static-geometry.json').read_text())['rows'] if r['pose']=='home' and r['point']=='y-plus12');z=np.load(out/'material-geometry.npz');vertices=z['vertices']*1000;triangles=vertices[z['faces']];a=np.array(r['mesh_witness'])*1000;b=np.array(r['engine_witness'])*1000
fig=plt.figure(figsize=(11,5),layout='constrained');ax=fig.add_subplot(121,projection='3d');mesh=Poly3DCollection(triangles,facecolor='#cad5e2',edgecolor='none',alpha=.75);ax.add_collection3d(mesh)
ax.scatter(*a,s=50,c='#e17918',label='Original triangles');ax.scatter(*b,s=40,c='#1768ae',marker='x',label='CPU collision');ax.set_xlim(vertices[:,0].min(),vertices[:,0].max());ax.set_ylim(vertices[:,1].min(),vertices[:,1].max());ax.set_zlim(vertices[:,2].min(),vertices[:,2].max());ax.set_box_aspect(np.ptp(vertices,axis=0));ax.view_init(elev=55,azim=-110);ax.set_xlabel('x / mm');ax.set_ylabel('y / mm');ax.set_zlabel('z / mm');ax.set_title('Original head shell, HOME');ax.legend(loc='upper left',fontsize=8)
bx=fig.add_subplot(122);relative=(b-a);bx.plot([0,relative[0]],[0,relative[1]],color='#87939d',lw=1.5);bx.scatter(0,0,s=80,c='#e17918',label='Original-triangle witness');bx.scatter(relative[0],relative[1],s=90,c='#1768ae',marker='x',label='CPU collision witness');bx.set_xlim(-.08,.12);bx.set_ylim(-.05,.3);bx.set_aspect('equal');bx.set_xlabel('x offset from original witness / mm');bx.set_ylabel('y offset from original witness / mm');bx.grid(alpha=.25);bx.legend(loc='upper left',fontsize=8);bx.set_title(f'Witness separation = {np.linalg.norm(b-a):.6f} mm\nGate = 0.200000 mm: BLOCKED',fontsize=11)
fig.suptitle('Stage 11 static distance query: y +12 mm | sphere clearance 0.5 mm',fontsize=13)
fig.savefig(out/'static-witness-review.png',dpi=160);plt.close(fig)
