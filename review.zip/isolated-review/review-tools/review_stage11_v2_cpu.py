"""Isolated CPU material review, not the user's complete mjlab/CUDA run."""
import ast,importlib.util,json,sys
from pathlib import Path
from dataclasses import dataclass
from typing import Literal
import mujoco
from review_stage11_cpu import scene
base=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('stage11_v2_validator',base/'stage11-build/scripts/validate_head_contact_physics.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
# Read the pinned installed configuration class rather than guessing defaults.
source=base/'stage11-deps/mjlab/sim/sim.py';tree=ast.parse(source.read_text());nodes=[]
for n in tree.body:
 if isinstance(n,ast.ClassDef) and n.name=='MujocoCfg':nodes.append(n)
 if isinstance(n,ast.Assign) and any(getattr(t,'id','').endswith('_MAP') for t in n.targets):nodes.append(n)
 if isinstance(n,ast.AnnAssign) and getattr(n.target,'id','').endswith('_MAP'):nodes.append(n)
namespace={'__name__':__name__,'dataclass':dataclass,'Literal':Literal,'mujoco':mujoco}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),namespace)
options=namespace['MujocoCfg'](timestep=.002,iterations=10,ls_iterations=20)
models=[scene(False),scene(True)]
for m in models:
 # The prior saved full local Scene data proves this pure translation relative
 # to the extracted factory adapter. Use its canonical material height.
 root=v.bid(m,'trunk_base');joint=int(m.body_jntadr[root]);adr=int(m.jnt_qposadr[joint])
 assert m.jnt_type[joint]==mujoco.mjtJoint.mjJNT_FREE
 m.key_qpos[0,adr+2]-=.12
 options.apply(m)
out=base/'stage11-v2-cpu-review-20261003';out.mkdir(exist_ok=False)
v.save(out/'execution-scope.json',{'full_mjlab_scene':False,'user_rtx5060':False,
 'description':'Isolated exact factory extraction; HOME height aligned to saved canonical local static evidence; pinned MujocoCfg.apply options used',
 'new_ppo_updates':0,'cloud_hours':0,'gate_version':'v2','canonical_source':'0ecdb2959ca649349ad52e7609f91dc4329a9b90',
 'source_sha256':{str(p.relative_to(base)):v.sha256(p) for p in [source,base/'stage11-build/scripts/validate_head_contact_physics.py',base/'stage11-build/src/mjlab_microduck/robot/head_contact.py']}})
result=v.run_physics(*models,out,cpu_only=True,geometry_gate='v2',render=True)
print(json.dumps(result,default=v.serial,indent=2))
