from pathlib import Path
import importlib.util,json,hashlib
import mujoco,numpy as np
sp=importlib.util.spec_from_file_location('v','stage11-build/scripts/validate_head_contact_physics.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
p=Path('stage11-v2-cpu-review-20261003');m=mujoco.MjModel.from_binary_path(str(p/'material-fixture.mjb'));videos=[]
for case in ('release-center','release-y-minus12'):
 videos.append(v.render_case(m,p/'cpu'/case,p/f'review-{case}-final.mp4'))
v.save(p/'video-final-followup.json',{'new_physics_steps':0,'original_blocked_video_limitation':'Original 20-step frame subsampling ended at step180 and omitted blocking contact at196. Original file preserved. Replacement review videos include final pre/post states and exact timestamp captions.','render_source_sha256':v.sha256(Path('stage11-build/scripts/validate_head_contact_physics.py')),'videos':videos})
print(json.dumps(videos,indent=2))
