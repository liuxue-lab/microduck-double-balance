"""Isolated assistant CPU review adapter, NOT part of the user execution pack.

Run the exact three frozen factory AST bodies without importing the unrelated
task registry and training dependencies. Add a diagnostic floor/lower ball and
the source HOME joint pose. Full mjlab Scene integration remains a laptop gate.
"""
import ast,importlib.util,json,math,os,re,sys
from pathlib import Path
from typing import Callable
import mujoco,numpy as np

base=Path('/workspace/scratch/5f13e3d252f6')
repo=base/'review-stage11'
sys.path.insert(0,str(base/'stage11-build/src'))
from mjlab_microduck.robot.head_contact import make_head_contact_robot_spec, make_head_contact_top_ball_spec
source=repo/'src/mjlab_microduck/tasks/microduck_double_balance_env_cfg.py'
tree=ast.parse(source.read_text());nodes=[]
for n in tree.body:
    if isinstance(n,ast.Assign) and all(isinstance(t,ast.Name) and t.id.isupper() for t in n.targets):nodes.append(n)
    if isinstance(n,ast.FunctionDef) and n.name in ('_remap_robot_collision_masks','_double_balance_robot_spec','_top_ball_spec'):nodes.append(n)
namespace={'mujoco':mujoco,'math':math,'os':os,'Callable':Callable,
           'get_standup_spec':lambda:mujoco.MjSpec.from_file(str(repo/'src/mjlab_microduck/robot/microduck/robot_allcollisions.xml'))}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),namespace)
home_tree=ast.parse((repo/'src/mjlab_microduck/robot/microduck_constants.py').read_text())
home=next(n.value for n in home_tree.body if isinstance(n,ast.Assign) and any(getattr(t,'id','')=='HOME_FRAME' for t in n.targets))
home_values=ast.literal_eval(next(k.value for k in home.keywords if k.arg=='joint_pos'))

def scene(new):
    old_robot=namespace['_double_balance_robot_spec'];old_top=namespace['_top_ball_spec']
    robot=make_head_contact_robot_spec(old_robot) if new else old_robot()
    top=make_head_contact_top_ball_spec(old_top) if new else old_top()
    s=mujoco.MjSpec();s.modelname='ISOLATED_REVIEW_NOT_CANONICAL_MJLAB_SCENE'
    s.attach(robot,prefix='robot/',frame=s.worldbody.add_frame())
    s.attach(top,prefix='top_ball/',frame=s.worldbody.add_frame())
    lower=s.worldbody.add_body(name='ball/ball',pos=[0,0,.12]);lower.add_freejoint(name='ball/floating_base_joint')
    lower.add_geom(name='ball/ball_sphere',type=mujoco.mjtGeom.mjGEOM_SPHERE,size=[.12],mass=.62,contype=4,conaffinity=5)
    s.worldbody.add_geom(name='terrain',type=mujoco.mjtGeom.mjGEOM_PLANE,size=[0,0,1],contype=1,conaffinity=1)
    m=s.compile();q=m.qpos0.copy()
    for i in range(m.njnt):
        name=m.joint(i).name.split('/')[-1]
        for pat,value in home_values.items():
            if re.fullmatch(pat,name):q[m.jnt_qposadr[i]]=value
    # Match the standalone HOME frame used in the Stage 10 shell geometry audit.
    key=s.add_key(name='home',qpos=q);m=s.compile()
    m.opt.timestep=.002;m.opt.integrator=mujoco.mjtIntegrator.mjINT_IMPLICITFAST
    m.opt.iterations=10;m.opt.ls_iterations=20
    return m

if __name__=='__main__':
    sp=importlib.util.spec_from_file_location('stage11_validator',base/'stage11-build/scripts/validate_head_contact_physics.py')
    val=importlib.util.module_from_spec(sp);sp.loader.exec_module(val)
    out=base/'stage11-cpu-review';out.mkdir(exist_ok=False)
    result=val.run_physics(scene(False),scene(True),out,cpu_only=True,render=True)
    result['execution_scope']='Isolated exact-factory extraction and material CPU review; full mjlab Scene and laptop GPU not tested'
    val.save(out/'physics-review.json',result)
    print(json.dumps(result,default=val.serial,indent=2))
