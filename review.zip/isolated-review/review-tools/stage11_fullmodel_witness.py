from pathlib import Path
import json,numpy as np,mujoco
from review_stage11_cpu import scene
from mjlab_microduck.robot.head_contact import HEAD_GEOM_NAME,TOP_GEOM
p=Path('stage11-cpu-review');s=json.loads((p/'static-geometry.json').read_text());r=next(r for r in s['rows'] if r['pose']=='home' and r['point']=='y-plus12')
m=scene(True);d=mujoco.MjData(m);mujoco.mj_resetDataKeyframe(m,d,0)
top=m.geom('top_ball/'+TOP_GEOM).id;head=m.geom('robot/'+HEAD_GEOM_NAME).id
body=m.geom_bodyid[top];joint=m.body_jntadr[body];adr=m.jnt_qposadr[joint];d.qpos[adr:adr+3]=r['center'];d.qpos[adr+3:adr+7]=[1,0,0,0];mujoco.mj_forward(m,d)
ft=np.zeros(6);dist=mujoco.mj_geomDistance(m,d,head,top,1.,ft)
review={'method':'One discriminating distance-only check on the complete extracted robot model; not mjlab Scene','new_physics_steps':0,'engine_witness_m':ft[:3].tolist(),'distance_m':dist,'distance_from_original_triangle_witness_m':float(np.linalg.norm(ft[:3]-r['mesh_witness'])),'difference_from_recompiled_material_witness_m':float(np.linalg.norm(ft[:3]-r['engine_witness']))}
(p/'fullmodel-distance-review.json').write_text(json.dumps(review,indent=2)+'\n');print(review)
