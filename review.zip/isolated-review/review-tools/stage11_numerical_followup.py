from pathlib import Path
import json,numpy as np
from mjlab_microduck.robot.head_contact import nearest_surface
out=Path('stage11-cpu-review');d=json.loads((out/'static-geometry.json').read_text());r=next(x for x in d['rows'] if x['pose']=='home' and x['point']=='y-plus12')
z=np.load(out/'material-geometry.npz');t=z['vertices'][z['faces']];p=np.array(r['center'])
# Independent scalar closest-point algorithm, using region tests (Ericson).
def closest(p,a,b,c):
 ab=b-a;ac=c-a;ap=p-a;d1=ab@ap;d2=ac@ap
 if d1<=0 and d2<=0:return a
 bp=p-b;d3=ab@bp;d4=ac@bp
 if d3>=0 and d4<=d3:return b
 vc=d1*d4-d3*d2
 if vc<=0 and d1>=0 and d3<=0:return a+d1/(d1-d3)*ab
 cp=p-c;d5=ab@cp;d6=ac@cp
 if d6>=0 and d5<=d6:return c
 vb=d5*d2-d1*d6
 if vb<=0 and d2>=0 and d6<=0:return a+d2/(d2-d6)*ac
 va=d3*d6-d5*d4
 if va<=0 and d4-d3>=0 and d5-d6>=0:return b+(d4-d3)/((d4-d3)+(d5-d6))*(c-b)
 denom=va+vb+vc
 if denom==0:raise RuntimeError('Degenerate triangle in independent region check')
 return a+(vb*ab+vc*ac)/denom
q=np.array([closest(p,*triangle) for triangle in t]);k=int(np.sum((q-p)**2,axis=1).argmin())
result={'method':'Independent scalar Voronoi-region point/triangle algorithm over every original face','faces_checked':len(t),'witness_m':q[k].tolist(),'distance_m':float(np.linalg.norm(q[k]-p)),'face':k,'difference_from_vectorized_witness_m':float(np.linalg.norm(q[k]-r['mesh_witness'])),'new_physics_steps':0}
(out/'independent-region-review.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
# Preserve the initial failed run; save the repaired model-export check separately.
import importlib.util
from review_stage11_cpu import scene
sp=importlib.util.spec_from_file_location('validator','stage11-build/scripts/validate_head_contact_physics.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
m=scene(True); material,_,_,_=v.fixture_from_model(m,v.initial_data(m));v.mujoco.mj_saveModel(material,str(out/'material-fixture.mjb'))
reloaded=v.mujoco.MjModel.from_binary_path(str(out/'material-fixture.mjb'))
post={'original_run_error_preserved':'error.txt','original_run_review_preserved':'physics-review.json','corrected_export':'material-fixture.mjb','export_reload_ok':reloaded.ngeom==material.ngeom,'static_gate_status':'BLOCKED','new_physics_steps':0,'dynamic_cases_executed':0,'gpu_cases_executed':0,'note':'No full static or dynamics rerun. Export fix and failure-gate control flow validated separately.'}
(out/'postprocessing-review.json').write_text(json.dumps(post,indent=2)+'\n')
