"""Isolated Warp CPU API/record-format check, zero integration, not CUDA evidence."""
from pathlib import Path
import importlib.util,json,time
import mujoco,numpy as np,warp as wp,mujoco_warp as mw
from mujoco_warp._src import forward as fw
sp=importlib.util.spec_from_file_location('probe','stage11-build/scripts/probe_head_contact_cuda_normal.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
source=Path('stage11-local-cuda-friction-review-20261004T104109Z/archive');out=Path('stage11-cuda-normal-api-check');out.mkdir(exist_ok=False)
model=mujoco.MjModel.from_binary_path(str(source/'diagnostic/material-fixture.mjb'))
with np.load(source/'diagnostic/material-geometry.npz') as z:triangles=z['vertices'][z['faces']]
state=m.selected_states(source)[1];report={'query_attempts':0,'queries_completed':0,'results':[]}
with wp.ScopedDevice('cpu'),m.forbid_integration(mw,fw):
 wm=mw.put_model(model);wm.opt.ls_parallel=True;before=m.model_fingerprint(wm)
 for route in m.ROUTES:
  result=m.run_query(model,wm,triangles,state,route,wp,mw,time.monotonic()+300,out,report);report['results'].append(result)
 assert before==m.model_fingerprint(wm)
report.update({'scope':'Warp CPU API sanity only; not a CUDA result, no canonical run','new_integration_steps':0,'PPO':0,'primary_and_model_unchanged':True})
m.save(out/'api-review.json',report)
print(json.dumps({'status':'API_OK_ZERO_INTEGRATION','results':[(r['route'],r['gate']) for r in report['results']]}))
