from pathlib import Path
import importlib.util,json,numpy as np,mujoco,warp as wp,mujoco_warp as mw
from mujoco_warp._src import forward as fw
sp=importlib.util.spec_from_file_location('normal','stage11-build/scripts/probe_head_contact_cuda_normal.py');n=importlib.util.module_from_spec(sp);sp.loader.exec_module(n)
sp=importlib.util.spec_from_file_location('witness','stage11-build/scripts/head_contact_witness_kernel.py');w=importlib.util.module_from_spec(sp);sp.loader.exec_module(w)
p=Path('stage11-local-cuda-normal-review-20261004T112308Z/archive/diagnostic');out=Path('stage11-witness-isolated-check');out.mkdir(exist_ok=False)
model=mujoco.MjModel.from_binary_path(str(p/'material-fixture.mjb'));results=[]
with wp.ScopedDevice('cpu'),n.forbid_integration(mw,fw):
 wm=mw.put_model(model);before=n.model_fingerprint(wm);kernel=w.make_kernel(wm.opt.ccd_iterations)
 for case in n.CASES:
  r=json.loads((p/'cases'/case/'collision/raw-result.json').read_text());result=w.query(wm,r['geom_xpos'],r['geom_xmat'],kernel)
  n.save(out/(case+'.json'),result);results.append({'case':case,**result})
 assert before==n.model_fingerprint(wm)
n.save(out/'review.json',{'scope':'Isolated WarpCPU original-function witness instrumentation; not canonical CUDA evidence','new_integration_steps':0,'PPO':0,'model_unchanged':True,'results':results})
for r in results:print(r['case'],r['scalars'],'pre',r['vectors'][6],'post',r['vectors'][7],'diff',r['vectors'][10])
