# Stage11 单场景传感器生命周期诊断

本交付承接 20261007T191145Z-182ca1 源码回传。原 SOURCE_DIFFERENCE_REVIEW_REQUIRED 的唯一错误是采集脚本将 EntityData 路径写为 entity/entity_data.py；实际为 entity/data.py。13 份有效源码、7 项已有源码哈希、版本及 Git 状态检查均通过。正确 EntityData 已从旧固定证据包找回，并与上一轮 contact-macro 的实际安装来源哈希吻合；新程序将在执行前再次核验此文件，不要求重跑旧采集。

本程序只回答：现有 Scene 初始化、射线感知、缓存、零时间更新和 reset 会改变哪些状态。单 world，14 个 sensor 对象，2 个接触传感器、1 个地形高度传感器、11 个内置包装器。现有射线图样为 2 个足部 frame，每个 frame 包含中心射线与两条圆环射线，共 6 条。

上限：模型编译 1；CPU forward 2（Simulation 和 RenderContext 各 1）；CPU 运动学 3（Simulation/put_data 初始化 1，名义姿态 2，分阶段限额）、距离查询 1；GPU forward 1；SensorContext 1；sense/BVH refit/射线批次各 2；Scene.update(dt=0) 2；Scene.reset 2。积分、策略、BAM.compute、delay.apply、Manager、CUDA 图捕获、图像渲染、PPO、云机使用均为 0。外层超时 600 秒（含首次 kernel 编译），超时或错误保留实际证据，不自动重试。

名义几何沿用原已复核初始化，不更改正式 reset、材料或积分设置。所有运行时对象位于新建私有子进程，进程退出即释放。记录物理主状态和所选材料字段是否始终保持；这不是对既有任务对象执行完整回滚，也不声称 BVH/mesh 原生句柄已经具备快照恢复能力。

有意在首次 sense 前读取一次传感器，以记录缓存未失效时与直接重算之间的差异。该控制性见证不能直接判定正式 Manager 的实际调用频率或奖励/观测受影响程度。新程序只记录，不修补传感器逻辑。两次合法刷新在同一物理状态下的输出应逐项相同。零时间更新不能验证长期时钟、实际飞行/接触时长递推或多 world 部分 reset。

执行前核对 52 项项目/实际安装来源，包括正确的 mjlab/entity/data.py。项目不写入新源码。所有新脚本、日志与回传包写入 Stage11 artifacts 下的新目录。已有正式源码分支、索引、标签和未提交修改保持。

程序使用一次性启动记录防止重复运行。只在子进程已退出且 execution-finished.json 存在时，使用本次打印的 --package-only 命令恢复打包。不得手动删除启动记录以重置预算。

脚本会自动打印不带变量前缀的完整 SSH 推送命令，由用户用既有身份执行。归档分支独立且不合并，不建立 PR，不移动标签，不改 HTTPS/PAT。源文件与旧证据保留。云机状态承接 OFF_CONFIRMED_BY_USER；本次无需开云机。

累计完成 34543、尝试 34544、PPO=0 保持，工程估计仍约 85%。上球撞地、长期数值敏感性、完整动态事务、批处理与训练放行仍未关闭。完整 Scene 生命周期/回滚以及 Stage11 完成标记仍为 false，待回传独立审查。

本交付已在助手环境完成标准库控制层、所有者/别名记录及模拟子进程回传验证。助手环境没有 Torch、MuJoCo 或 Warp，未运行本机 GPU 版本；本机执行结果仍待回传独立审查。

## R2 修正

首次生命周期回传 ce49796bed091a65abc20021814d91d8bf32489d 已完成 SHA256、ZIP CRC 和 27 项内容清单核验。原脚本遗漏 put_data 内的一次 CPU 运动学调用，第二次名义姿态运动学在闸门处被拒绝。实际 CPU forward=2、CPU 运动学 native=2；GPU forward=0、sense=0、传感器读取=0、积分=0。不是传感器通过，也不是传感器失败。

R2 只修正这一预算遗漏，并新增两份已回传原生源文件的哈希钉住。运行前核验旧目录、旧退出证据及旧 ZIP 精确哈希；保留 started-v1.json，使用独立 started-v2.json 记录一次新尝试。初始化调用 1 次后关闭该阶段，名义姿态阶段允许 2 次，之后关闭 CPU 运动学入口。总上限 3。旧归档作为 previous/sensor-lifecycle-r1-return.zip 完整保留。本程序仍不自动重试，GPU forward/sense 及所有其他预算未增加。
